--varchar转varbinary
create function HexStringToBin(@hexstring varchar(500)) 
returns varbinary(500) 
as
begin
   return (
	select cast('' as xml).value('xs:hexBinary(substring(sql:variable("@hexstring"), sql:column("t.pos")) )', 'varbinary(500)')
	from (select case substring(@hexstring, 1, 2) when '0x' then 3 else 0 end) as t(pos)
	)
end
go

