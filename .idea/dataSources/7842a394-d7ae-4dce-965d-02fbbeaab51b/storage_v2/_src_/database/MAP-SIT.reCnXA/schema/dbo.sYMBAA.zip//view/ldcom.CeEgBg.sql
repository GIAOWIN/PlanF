
CREATE view [dbo].[ldcom]
as
select comcode,name,shortname,'' branchtype from mcom
union all
select branchattr,name,name,branchtype from labranchgroup where len(branchattr)<=8 and branchtype='1'
and BRANCHATTR not in (select distinct  substring(branchattr,0,7) from mbranch);    --Ôö¼ÓÂß¼­ÅÅ³ý6Î»±àÂë
go

