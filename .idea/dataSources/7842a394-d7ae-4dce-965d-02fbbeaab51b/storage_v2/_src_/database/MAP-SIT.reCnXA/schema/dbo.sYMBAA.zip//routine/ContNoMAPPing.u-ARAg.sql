CREATE FUNCTION [dbo].[ContNoMAPPing]( @CONTNO VARCHAR(20))
    RETURNS VARCHAR(100)

as
begin 
declare @RETURNS varchar(50)
declare @RETURNS1 varchar(50)
	
	set @RETURNS1 = ( select OLDCONTNO from MAPPING_CONTNO where CONTNO = @CONTNO)

    if @RETURNS1 is not null 
		set @RETURNS = @RETURNS1
	else
		set @RETURNS = @CONTNO
return @RETURNS
end
go

