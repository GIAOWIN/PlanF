create view LAAGENTV as Select a.AgentCode,a.Name,b.AgentGroup, c.ManageCom,c.BranchAttr,b.AgentGrade,b.AgentProperty,a.SaleQuaf,  a.IndueFormDate,a.EmployDate, a.OutWorkDate,a.BranchType,c.state   From LAAgent a,LATree b,LABranchGroup c   Where a.AgentCode = b.AgentCode    and b.AgentGroup = c.AgentGroup
go

