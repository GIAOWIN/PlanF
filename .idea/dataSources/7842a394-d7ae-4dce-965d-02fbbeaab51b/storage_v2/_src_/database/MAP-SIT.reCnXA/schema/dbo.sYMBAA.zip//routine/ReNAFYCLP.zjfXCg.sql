
CREATE FUNCTION [dbo].[ReNAFYCLP](
       @CACODE VARCHAR(20), --代理人编码
       @MonthBegin datetime,
       @MonthEnd datetime,
       @servermonths int,
       @QuaBGNMark int
       )
    RETURNS DECIMAL(12,4)
------------------------------------------------------------------------
-- LP P&P奖金 相关项
-- @author wengf
-- Create date:  2009-7-14
------------------------------------------------------------------------
as
BEGIN 


    DECLARE @SUMAFYCReinstate DECIMAL(12,4) ;			--总的复效AFYC
    DECLARE @tMonthBegin   VARCHAR(20);

    if @servermonths=1 and @QuaBGNMark=0 
		begin
        set @SUMAFYCReinstate=0;
		end
    else
		begin
		   if @servermonths=2 and @QuaBGNMark=1
	          begin
				set @tMonthBegin=(select employdate from laagent where agentcode=@CACODE);
				end
		   else
				begin
			   set @tMonthBegin= @MonthBegin;
				end

   		   set @SUMAFYCReinstate=(select sum(case when agentcode=agentcode1 then fyc*(12/payintv-maxno) else fyc*0.5*

(12/payintv-maxno) end ) from lcReinstateDateAcc where branchtype='1' and payintv<>0 and payyear=0 and (agentcode=@CACODE or 

agentcode1=@CACODE) and signdate>='2008-06-03' and reindate>=@MonthBegin and reindate<=@MonthEnd );
    end 
     if @SUMAFYCReinstate is null or @SUMAFYCReinstate < 0 
		begin
         set @SUMAFYCReinstate = 0;
     end 
   return @SUMAFYCReinstate;
 end
go

