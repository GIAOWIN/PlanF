CREATE FUNCTION [dbo].[REVERSEMAPPING]( @CCODETYPE VARCHAR(20),
                                          @CCODE VARCHAR(20) )
    RETURNS VARCHAR(100)
------------------------------------------------------------------------
-- SQL UDF (Scalar)
------------------------------------------------------------------------
as BEGIN 
    DECLARE @rtnCode VARCHAR(100);
    if upper(@CCODETYPE) = 'AGENT' 
        set @rtnCode = (select oagentcode from magent where agentcode=@CCODE);
    else
        if upper(@CCODETYPE) = 'BRANCH' 
            set @rtnCode = (select obranchattr from mbranch where branchattr=@CCODE);

    if @rtnCode is null or @rtnCode='' 
        set @rtnCode = @CCODE;

    return @rtnCode;

END
go

