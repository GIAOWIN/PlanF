
CREATE FUNCTION  [dbo].[ClientCountBe](@CAGENTCODE VARCHAR(10),
                                           @TEMPBEGIN datetime,
                                           @TEMPEND datetime )
RETURNS NUMERIC(12,2)
------------------------------------------------------------------------
-- SQL UDF (Scalar)
-- 计算客户数
-- @author wengf
-- Create date:  2009-7-14
------------------------------------------------------------------------
as
BEGIN --7
declare @tpolno varchar(30);            --保单号
declare @polstate varchar(2);           --保单状态 -- 1：有效
declare @count decimal(12,2) ;      --客户数累计
declare @num NUMERIC(12,2) ;--客户数
declare @triskcode varchar(6);          --险种
declare @criskcode varchar(6);          --险种(临时记忆变量)
declare @tidno varchar(100);            --身份证号
declare @cidno varchar(100);            --身份证号(临时记忆变量)
declare @tcvalidate datetime;               --投保日期
declare @ccvalidate datetime;               --投保日期(临时记忆变量)
declare @tnum integer ;        --判断180天内是否存在同一被保人同一险种的记录数
declare @tagentcode varchar(10);        --第一代理人
declare @tagentcode1 varchar(10);       --第二代理人
declare @tflag integer ;       --当前保单是否参与客户数统计的标志，1位参加统计，0为不参加统计

declare @polno varchar(30); 
declare @riskcode varchar(30); 
declare @cvalidate varchar(30); 
declare @idno varchar(30); 
declare @agentcode varchar(30); 
declare @agentcode1 varchar(30); 



    set @criskcode='';
    set @ccvalidate=null;
    set @cidno='';
    set @count=0.00;
    set @num=0.00;
    set @tnum=0;
    set @tflag=0;


    
	declare cur cursor for
      select polno,riskcode,cvalidate,
        (select idno from lcinsured where polno = lacommision.polno) idno,
        agentcode,agentcode1 from lacommision where
        tmakedate<=@tempend and
        tmakedate>=@tempbegin and
        (agentcode=@cagentcode or agentcode1=@cagentcode)
        and paycount=1
        and flag='0'
        and riskcode <> 'AB0010'
        and riskmark='Y'
        and branchtype='1'
        order by riskcode,idno,cvalidate
    
	open cur
      fetch next from cur into @polno,@riskcode,@cvalidate,@idno ,@agentcode,@agentcode1
	while(@@Fetch_Status=0 )
	begin--6

        set @tflag=0;
        set @tpolno = @polno;
        set @triskcode = @riskcode;
        set @tcvalidate = @cvalidate;
        set @tidno = @idno;
        set @tagentcode = @agentcode;
        set @tagentcode1 = @agentcode1;
        set @polstate = (select polstate from lcpol where polno = @tpolno);
        set @num=0.00;
        if @polstate='1' 
         begin--5
			  --给临时变量赋值criskcode
			  if @criskcode='' 
				begin--4
				set @criskcode=@triskcode;
				set @tflag=1; --第一条保单是确定统计的保单

			  --给临时变量赋值ccvalidate

				set @ccvalidate=@tcvalidate;

			  --给临时变量赋值ccvalidate

				set @cidno=@tidno;
				end--4
				if @tflag=0 
                    begin--4
						 if @criskcode=@triskcode 
                            begin--3
								if @cidno=@tidno  --同一被保险人的同一险种的保单，则查看其生效日期
									begin--2
										set @tflag=(select case when DateAdd(dd,180,@ccvalidate)<=@tcvalidate then 1 else 0 end from msysvar where vartype='onerow');
										if @tflag=1 
                                            begin --1
                    						set @ccvalidate=@tcvalidate;
                                            end	  --1
									end --2

								else   --不同被保险人的保单，则需要参与客户数统计
									begin--2
										set @cidno=@tidno;
										set @ccvalidate=@tcvalidate;
										set @tflag=1;
								    end--2
                            end--3
						  else
							begin--2
								set @criskcode=@triskcode;
								set @cidno=@tidno;
								set @ccvalidate=@tcvalidate;
								set @tflag=1;
						    end--2
                     end--4
				if @tflag=1 
					begin--4
					if @tagentcode=@tagentcode1 
					  set @num = 1;
					else
					  set @num = 0.5;
                   end--4
            end--5
      set @count=@count+@num;
     fetch next from cur into @polno,@riskcode,@cvalidate,@idno ,@agentcode,@agentcode1 ;
     end --6
	--//关闭游标
	CLOSE cur;
	--//撤销游标
	DEALLOCATE cur;   
  return @count;
end--7
go

