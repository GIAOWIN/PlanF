CREATE FUNCTION [dbo].[MAP_DICODETONAME]( @CCODETYPE VARCHAR(20),
                                          @CCODE VARCHAR(20) )
    RETURNS VARCHAR(100)

as
begin 
declare @RETURNS varchar(50)
declare @RETURNS1 varchar(50)

      set @RETURNS1 = ( case when (select codename from MAP_DICode where codetype = @cCodeType and Code = @cCode)<>'' 
						then (select codename from MAP_DICode where codetype = @cCodeType and Code = @cCode) 
						else @cCode end)

        if @RETURNS1 is not null 
			set @RETURNS = @RETURNS1
		else
			
			set @RETURNS = @RETURNS1
return @RETURNS
end
go

