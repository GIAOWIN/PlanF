
CREATE FUNCTION HERITATIONDATENEW
------------------------声明传入参数
(
     @CMANAGECOM	VARCHAR(4),
     @CGETPOLDATE	datetime
		)
------------------------声明返回结果
	RETURNS datetime

as begin
------------------------声明内部变量
	DECLARE @tHDate datetime;
	
	if (@CGETPOLDATE is null) 
        return null;
   
    set @tHDate = (select coalesce((select Dateadd(day,1,enddate) from laholiday where startdate<=Dateadd(day,7,@CGETPOLDATE) and enddate>=Dateadd(day,7,@CGETPOLDATE) and managecom=@CMANAGECOM),Dateadd(day,7,@CGETPOLDATE)) from ldsysvar where sysvar='onerow');

    return @tHDate;
 end;
go

