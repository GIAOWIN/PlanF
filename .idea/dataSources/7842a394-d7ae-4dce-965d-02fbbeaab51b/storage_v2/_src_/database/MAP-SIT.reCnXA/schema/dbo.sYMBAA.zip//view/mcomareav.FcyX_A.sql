
CREATE view [dbo].[mcomareav]
as
select a.comcode,a.name,b.areaflag
from mcom a
left join mcomarea b on a.comcode=b.managecom
left join mbrancharea c on b.areaflag=c.areaflag
union select areacode,name,areaflag from mbrancharea;
go

