
CREATE FUNCTION [dbo].[B_GETMONTHDATE](@CMANAGECOM VARCHAR(4),
                                       @CYEARMONTH VARCHAR(6),
                                       @CFLAG1 VARCHAR(2),
                                       @CFLAG2 VARCHAR(2) )
                                         RETURNS DATE
------------------------------------------------------------------------
-- SQL UDF (Scalar)
-- 计算起止时间(持续率查询)S:起期 E:止期
-- @author xiaodi
-- Create date:  2017-01-05
------------------------------------------------------------------------
AS BEGIN 

	DECLARE @tResult DATE; -- 计算结果
 	
 	set @tResult=(select (case when @CFLAG1='S' then startdate else enddate end) from lastatsegment where managecom=@CMANAGECOM and yearmonth=@CYEARMONTH 
 	and stattype=@CFLAG2 );
 	
	return @tResult;--
	
end
go

