



-- =============================================
-- Author:		dongjuan
-- Create date: 2016-08-30
-- Description:	拆分lacommision表，用于方便达成计算
-- =============================================
CREATE PROCEDURE [dbo].[Flush_Lacommision] 
AS
BEGIN
	
update laagent set DATASOURCES='' where DATASOURCES is null
;

truncate table  lacommision_temp
print 'truncate end'
-- insert into  lacommision_temp   select * from(
--select  sum(COMMCHARGE) anp ,sum(fyc) fyc,mainpolno,tmakedate,managecom,agentcode,signdate,appntno,1 as rate ,
-- SMbranchattr,  SMbranchmanager, AMbranchattr,  AMbranchmanager, DMbranchattr, DMbranchmanager 
-- from lacommision a where     (fyc <>0 or COMMCHARGE <> 0 ) and agentcode=agentcode1
--  group by mainpolno,appntno,tmakedate,managecom,agentcode,signdate,appntno,
-- SMbranchattr,  SMbranchmanager, AMbranchattr,  AMbranchmanager, DMbranchattr, DMbranchmanager
--union 
--select  sum(COMMCHARGE) anp ,sum(fyc) fyc,mainpolno,tmakedate,managecom,agentcode1 as agentcode,signdate,appntno,0.5 as rate
--,SMbranchattr1 as SMbranchattr,  SMbranchmanager1 as SMbranchmanager , AMbranchattr1 as AMbranchattr,  AMbranchmanager1 as AMbranchmanager, 
--DMbranchattr1 as DMbranchattr, DMbranchmanager1 as DMbranchmanager
--from lacommision a where      (fyc <>0 or COMMCHARGE <> 0 ) and agentcode<>agentcode1 
--group by mainpolno,tmakedate,managecom,
--agentcode1,signdate,appntno, SMbranchattr1,  SMbranchmanager1  , 
--AMbranchattr1,  AMbranchmanager1, DMbranchattr1, DMbranchmanager1
--union 
--select  sum(COMMCHARGE) anp ,sum(fyc) fyc,mainpolno,tmakedate,managecom,agentcode as agentcode,signdate,appntno,0.5 as rate ,
-- SMbranchattr,  SMbranchmanager, AMbranchattr,  AMbranchmanager, DMbranchattr, DMbranchmanager
-- from lacommision a where     (fyc <>0 or COMMCHARGE <> 0 ) and agentcode<>agentcode1 
-- group by mainpolno,tmakedate,managecom,agentcode,signdate,appntno,SMbranchattr,  
--SMbranchmanager, AMbranchattr,  AMbranchmanager, DMbranchattr, DMbranchmanager
--)s

--print 'insert end';
select *from lacommision_temp
 insert into  lacommision_temp   select * from(
select  sum(COMMCHARGE) anp ,sum(fyc) fyc,mainpolno,tmakedate,managecom,agentcode,signdate,appntno,1 as rate ,
 SMbranchattr,  SMbranchmanager, AMbranchattr,  AMbranchmanager, DMbranchattr, DMbranchmanager ,paycount,flag
 from lacommision a where     (fyc <>0 or COMMCHARGE <> 0 ) and agentcode=agentcode1
  group by mainpolno,appntno,tmakedate,managecom,agentcode,signdate,appntno,paycount,flag,
 SMbranchattr,  SMbranchmanager, AMbranchattr,  AMbranchmanager, DMbranchattr, DMbranchmanager
union 
select  sum(COMMCHARGE) anp ,sum(fyc) fyc,mainpolno,tmakedate,managecom,agentcode1 as agentcode,signdate,appntno,0.5 as rate,
SMbranchattr1 as SMbranchattr,  SMbranchmanager1 as SMbranchmanager , AMbranchattr1 as AMbranchattr,  AMbranchmanager1 as AMbranchmanager, 
DMbranchattr1 as DMbranchattr, DMbranchmanager1 as DMbranchmanager,paycount,flag
from lacommision a where      (fyc <>0 or COMMCHARGE <> 0 ) and agentcode<>agentcode1 
group by mainpolno,tmakedate,managecom,paycount,flag,
agentcode1,signdate,appntno, SMbranchattr1,  SMbranchmanager1  , 
AMbranchattr1,  AMbranchmanager1, DMbranchattr1, DMbranchmanager1
union 
select  sum(COMMCHARGE) anp ,sum(fyc) fyc,mainpolno,tmakedate,managecom,agentcode as agentcode,signdate,appntno,0.5 as rate ,
 SMbranchattr,  SMbranchmanager, AMbranchattr,  AMbranchmanager, DMbranchattr, DMbranchmanager,paycount,flag
 from lacommision a where     (fyc <>0 or COMMCHARGE <> 0 ) and agentcode<>agentcode1 
 group by mainpolno,tmakedate,managecom,agentcode,signdate,appntno,SMbranchattr, paycount,flag, 
SMbranchmanager, AMbranchattr,  AMbranchmanager, DMbranchattr, DMbranchmanager
)s
;
-- =============================================
-- Author:		dongjuan
-- Create date: 2016-08-30
-- Description:	EZT达成计算详细逻辑
-- =============================================
--AB0010
--PA01A
--PA08AA
--PAL
--SPA01A

--保单数（新单数）
with aa as (
select mainpolno,rate,agentcode,tmakedate from lacommision_temp where tmakedate=convert(char(10),getdate()-2,120)
),bb as (select sum((l.anp*l.rate)) anp,l.mainpolno from aa a,lacommision_temp l where a.mainpolno= l.mainpolno 
and l.tmakedate<=convert(char(10),getdate()-2,120)
group by l.mainpolno 
)
,cc as (select anp,mainpolno,convert(char(10),getdate()-2,120) as tmakedate from bb where anp>0
)select * into #temp1 from (
select sum(lc.rate) policycount,agentcode,lc.tmakedate from lacommision_temp lc,cc c where lc.mainpolno = c.mainpolno
and c.tmakedate = lc.cvalidate and lc.tmakedate <= c.tmakedate and not exists(select 1 from map_lcpol lcpol 
where lcpol.contno=lc.mainpolno and lcpol.SUBRISKFLAG='Y'
and lcpol.riskcode in('AB0010','PA01A','PA08AA','PAL','SPA01A'))
group by agentcode,lc.tmakedate)c



--with aa as (
--select mainpolno,rate,agentcode,tmakedate,paycount,(case when paycount=0 then -1 else 1 end) as cont from lacommision_temp where
-- tmakedate=convert(char(10),getdate()-2,120)
--),bb as (select sum((l.anp*l.rate)) anp,l.mainpolno ,l.agentcode,a.cont from aa a,lacommision_temp l where a.mainpolno= l.mainpolno 
--and l.tmakedate<=convert(char(10),getdate()-2,120)
--group by l.mainpolno ,l.agentcode,a.cont
--)
--,cc as (
--select anp,mainpolno,convert(char(10),getdate()-2,120) as tmakedate,cont,agentcode
--,
--(case when anp>0 and cont=1 then 1 
--when anp=0 and cont = 1 then 0 
--when anp = 0 and cont = -1 then -1
--when anp <0  and cont = -1 then -1
--when anp >0 and cont=-1 then -1 
--end )policycountrate
-- from bb 
--where 1=1
--),dd as (
--select lc.rate*policycountrate policycount,lc.agentcode,lc.tmakedate from lacommision_temp lc,cc c where lc.mainpolno = c.mainpolno
--and lc.agentcode=c.agentcode
--and c.tmakedate = lc.cvalidate and lc.tmakedate <= c.tmakedate 
--and not exists(select 1 from map_lcpol lcpol 
--where lcpol.contno=lc.mainpolno and lcpol.SUBRISKFLAG='Y'
--and lcpol.riskcode in('AB0010','PA01A','PA08AA','PAL','SPA01A'))
--)
--select * into #temp1 from (
--select sum(policycount)policycount,agentcode,tmakedate from dd
--group by agentcode,tmakedate
--)b

print 'aa end';

---客户数
with af as (
select distinct appntno,agentcode from lacommision_temp where tmakedate = convert(char(10),getdate()-2,120)
),
am as(
select distinct l.appntno ,l.agentcode from lacommision_temp l,af where l.appntno =af.appntno 
and l.agentcode =af.agentcode
and l.tmakedate < convert(char(10),getdate()-2,120)
)select * into #temp2 from (
select count(appntno) cumcount,agentcode ,convert(char(10),getdate()-2,120) as tmakedate from af where not exists(select appntno from am where am.appntno =af.appntno)group by agentcode
)cc

print 'af end';

--sum anp ，fyc
with sumanp as (
select sum(anp*rate) anp ,sum(fyc*rate)fyc,agentcode,tmakedate from lacommision_temp la 
where  tmakedate = convert(char(10),getdate()-2,120) group by agentcode,tmakedate
)select * into #temp3 from sumanp

print 'sum anp fyc end'
--整合 客户数 保单数  sum  anp  fyc by agentcode
select * into #temp4 from(
select agentcode,anp,fyc,(select cumcount
 from #temp2 t2 where t2.agentcode = t3.agentcode and t2.tmakedate =t3.tmakedate) as cumcount ,
 (select policycount from  #temp1 t1 where t1.agentcode = t3.agentcode and t1.tmakedate =t3.tmakedate) as policycount,tmakedate
 from #temp3 t3
 )ss

print 'sum anp fyc end'
 --删除当天已经跑过的数据，避免重复新增
 delete from lacommision_ForEZT where DATEDIFF ( DAY, makedate,getdate()-1 )=0;
 
print 'delete sum anp fyc end'
 --新增当天数据 by agentcode
insert into  lacommision_ForEZT  select agentcode agent ,anp,fyc,
 (case when cumcount is null then '0' else cumcount end) as cnum ,
 (case when policycount is null then '0' else policycount end ) as pnum,convert(char(10),tmakedate,120) as busdate,convert(char(100),getdate()-1,20) makedate
  from #temp4
END


go

