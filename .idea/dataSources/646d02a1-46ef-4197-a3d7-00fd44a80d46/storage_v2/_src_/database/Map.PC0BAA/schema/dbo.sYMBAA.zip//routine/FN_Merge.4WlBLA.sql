
CREATE FUNCTION FN_Merge (@Student NVARCHAR(50))

RETURNS NVARCHAR(50)

 

AS

      BEGIN

            DECLARE @Course NVARCHAR(50)

            SELECT @Course = ISNULL(@Course + ',','') + @Course

            FROM SC

            WHERE Student = @Student

            RETURN @COURSE

     END
go

