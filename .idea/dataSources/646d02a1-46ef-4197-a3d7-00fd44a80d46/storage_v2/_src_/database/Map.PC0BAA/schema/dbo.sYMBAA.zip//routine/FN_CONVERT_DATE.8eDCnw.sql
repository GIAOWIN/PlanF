CREATE FUNCTION [dbo].[FN_CONVERT_DATE](
@dstr decimal(8,0)
)RETURNS datetime
AS
BEGIN
    DECLARE @str varchar(8),@d datetime
    IF(@dstr=0 or @dstr is null)
		return null;
		
    set  @str=cast(@dstr as varchar) ;
    
    IF(len(@str)=8 and @dstr<18000000)
		set @str = '18000101';
		
    IF len(@str)=8
		IF right(@str,4)='9999'
		set   @d = null;--'9999-12-31 00:00:00';
		else 
		set   @d = CONVERT(datetime,@str,112);
    ELSE IF len(@str)=6   
		IF right(@str,2)='99'
		set   @d = null;--'9999-12-31 00:00:00';
		else 
		set   @d = CONVERT(datetime,'20'+@str,112);
    ELSE IF len(@str)=5    
		set   @d = CONVERT(datetime,'200'+@str,112);
    ELSE
		set   @d = '00:00:00';
    RETURN(@d)
END
go

