
create view policy_for_EZT 
as 
 select 
   lcc.agentcode ,  
   lcc.appntno ,
   CONVERT(NVARCHAR, DECRYPTBYPASSPHRASE(N'METLIFE',lcc.APPNTNAME)) APPNTNAME,
   CONVERT(NVARCHAR,lcc.APPNTBIRTHDAY,23) as APPNTBIRTHDAY,
   lcc.mobilephone ,
   lcc.contno ,
   lcp.RISKCODE , 
   lcp.MAINRISKNAME , 
   dbo.MAP_DICODETONAME('T3590',lcc.PAYINTV)PAYINTV ,
   cast ( 
   (case when lcc.STATE='1' and (select count(0) from MAP_LJSPAY_V where contno=lcc.contno)>0 
   then (select max(ljs.DUEMONEY) from MAP_LJSPAY_V ljs where ljs.CONTNO=lcc.contno and ljs.DUEMONEY>0     
   and ljs.DUEDATE=(     select max(a.DUEDATE) from MAP_LJSPAY_V a where a.CONTNO=lcc.contno and a.DUEMONEY>0     )   
    )else (select max(a.GETMONEY) from MAP_LJAPAY_V a where a.CONTNO=lcc.contno and a.GETMONEY>0    
    and a.DUEDATE=(     select max(a.DUEDATE) from MAP_LJAPAY_V a  where a.CONTNO=lcc.contno 
    and (a.CANCELDATE is null or a.CANCELDATE='') and a.GETMONEY>0 and a.CONFDATE is not null    )
    and a.confdate=(select max(a.confdate) from MAP_LJAPAY_V a  where a.CONTNO=lcc.contno )    
    )end ) as decimal(12,2))as prem,
   (case when (lcp.AMNT is not null and lcp.AMNT>0.00) then cast(lcp.AMNT as nvarchar)   when (lcp.MULT is not null and lcp.MULT<>'')
    then cast (lcp.MULT as nvarchar ) +'份' else '' end) as AMNT, 
   dbo.MAP_DICODETONAME('T3620', lcc.NEWPAYMODE)as NEWPAYMODE, 
   dbo.MAP_DICODETONAME('T3620', lcc.PAYMODE) as PAYMODE, 
   (case  when lcc.APL_FLAG = 'Y' then '有自垫'  when lcc.APL_FLAG = 'N' then '无自垫' end) as APL_FLAG ,
   substring(CONVERT(varchar(24), lcc.SIGNDATE, 23),0,11) as SIGNDATE,
   ( case when lcc.STATE = '0' then '失效' when lcc.STATE = '1'   then '有效' when lcc.STATE = '3' then  '犹豫期撤单' 
    when lcc.STATE = '5' then '退保'  else  '' end) as STATE
   from  MAP_LCCONT lcc  
        ,MAP_LCPOL lcp  
   where 1=1 
        and lcc.CONTNO = lcp.CONTNO 
        and lcp.SUBRISKFLAG='Y'   
        --and lcc.CONTNO=@contno
        and lcc.SIGNDATE is not null ;
go

