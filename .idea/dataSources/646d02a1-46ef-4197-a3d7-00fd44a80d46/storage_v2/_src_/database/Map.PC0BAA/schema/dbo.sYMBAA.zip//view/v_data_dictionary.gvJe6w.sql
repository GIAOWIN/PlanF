
create view [dbo].[v_data_dictionary] as
select t1.[Table Name] as table_name,
       t1.[Column Name] as column_name,
       case when t1.[type] like '%char' 
            then t1.[type]+'('+cast(t1.[Length] as varchar)+')' 
            when t1.[type]='numeric'
            then t1.[type]+'('+cast(t1.[Length] as varchar)+','+cast(t1.[scale] as varchar)+')'
            else t1.[type] 
        end as [Type],
       isnull(t2.keys,'') as [PrimaryKey],
       t1.[Not Null] as [NotNull],
       t1.[Description] as [Comments],
       t1.column_id
  from (SELECT [Table Name]  = OBJECT_NAME(c.object_id), 
               [Column Name] = c.name, 
               [type]        =type_name(c.user_type_id),
               [Length]      =convert(int,c.max_length)/(case type_name(c.user_type_id) when 'nchar' then 2 when 'nvarchar' then 2 else 1 end),
               [scale]       =c.scale,
               [Not Null]    =case c.is_nullable when 0 then 'Y' else 'N' end,
               [Description] = isnull(ex.value ,''),
               c.object_id,
               c.column_id
          FROM sys.columns c 
          LEFT OUTER JOIN 
               sys.extended_properties ex 
            ON ex.major_id = c.object_id 
           AND ex.minor_id = c.column_id 
           AND ex.name = 'MS_Description' 
         WHERE OBJECTPROPERTY(c.object_id, 'IsMsShipped')=0 
       )t1
  left join
       (select OBJECT_NAME(a.id) as [Table Name], 
               a.name            as [Column Name],
               'PK'              as keys
          FROM syscolumns a   
          join sysobjects b   
            on a.id=b.id
           and b.xtype='U'   
           and b.name<>'dtproperties'   
         where exists(SELECT 1 FROM sysobjects   
                       where (xtype='PK')
                         and name in(SELECT name FROM sysindexes 
                                      WHERE indid in(SELECT indid FROM sysindexkeys
                                                      WHERE id=a.id
                                                        AND colid=a.colid)
                                    )
                      )
       )t2
    on t1.[Table Name]=t2.[Table Name]
   and t1.[Column Name]=t2.[Column Name]
go

