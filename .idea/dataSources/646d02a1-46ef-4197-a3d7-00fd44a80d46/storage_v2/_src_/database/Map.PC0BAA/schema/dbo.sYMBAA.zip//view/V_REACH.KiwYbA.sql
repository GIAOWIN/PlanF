
CREATE view [dbo].[V_REACH] as(
  select * from lacommision_ForEZT
  )
go

