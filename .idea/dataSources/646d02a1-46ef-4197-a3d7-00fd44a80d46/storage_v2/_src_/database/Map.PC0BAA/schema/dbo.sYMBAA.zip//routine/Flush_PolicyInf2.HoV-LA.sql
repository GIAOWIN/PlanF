
CREATE PROCEDURE [dbo].[Flush_PolicyInf2] 
AS

--MAP_LCCont_V NEW---start
--policy from LA

--update _ lccontnew
declare @iRecordCount_lccontnew int; 

declare @maxtime_lccont datetime;
set @maxtime_lccont=(select max(ETL_DATATIME) from MAP_LCCont_V);

declare my_cursor cursor for select distinct(substring(convert(char(25),SIGNDATE,0),8,4)) from MAP_LCCont group by SIGNDATE;
declare @SIGNDATE_TEMP char(25);
open my_cursor;

FETCH NEXT FROM my_cursor into @SIGNDATE_TEMP

while(@@fetch_status=0)
begin

truncate table MAP_LCCont_Temp;
insert into MAP_LCCont_Temp select * from (
select temp.* from (SELECT     dbo.ContNoMAPPing(CONTNO) AS CONTNO, PRTNO, EXECUTECOM, MANAGECOM, AGENTCOM, AGENTCODE, 
BXSCODE, BXSNAME, AGENTGROUP, ISNULL(CAGENTCODE,'') AS CAGENTCODE, CAGENTGROUP, SALECHNL, STATE, dbo.CliNoMAPPing(APPNTNO) AS APPNTNO, APPNTNAME,
 APPNTSEX, APPNTBIRTHDAY, IDTYPE, IDNO,RELATIONWITHINSURED, NATIVEPLACE,
 COUNTRY, ADDRESS1, ADDRESS2, ADDRESS3, ZIPCODE, PHONE, POSTADDRESS1, POSTADDRESS2, POSTADDRESS3,                        
 POSTADDRESS, POSTZIPCODE, CHARGEADDRESS, CHARGEPHONE, CUSTCOLLECTADDR, COMPANY, MARRIAGE, OCCUPATIONTYPE, OCCUPATIONCODE,                        OCCUPATIONNAME, COCCUPATIONTYPE, COMPANYADDRESS, CUSTOFFICEPOST, CUSTOFFICEPHONE, MOBILEPHONE, EMAIL, PAYINTV, NEWPAYMODE,                        NEWBANKCODE, NEWBANKACCNO, PAYMODE, BANKCODE, BANKACCNO, POLAPPLYDATE, ACCEPTDATE, SIGNDATE, CVALIDATE, MATDATE, CUSTOMGETPOLDATE,                        RECEIVEDATE, WITHDRAWDATE, LASTRVALIDATE, ETL_DATATIME, 
ENCRYPT_FLAG, MONTH(APPNTBIRTHDAY) AS month, DAY(APPNTBIRTHDAY) AS day,DUEDAY,APL_FLAG,APL_AMT
FROM  dbo.MAP_LCCONT where substring(convert(char(25),SIGNDATE,0),8,4)=@SIGNDATE_TEMP 
and ETL_DATATIME>@maxtime_lccont) temp where dbo.ContNoMAPPing(CONTNO) in (SELECT contno from MAP_LCCont_V) ) a;

update a set 
a.PRTNO = oldtable.prtno ,
a.EXECUTECOM = oldtable.executecom,
a.MANAGECOM = oldtable.managecom,
a.AGENTCOM = oldtable.agentcom,
a.AGENTCODE = oldtable.agentcode,
a.BXSCODE = oldtable.bxscode,
a.BXSNAME= oldtable.bxsname,
a.AGENTGROUP= oldtable.agentgroup,
a.CAGENTCODE= oldtable.cagentcode,
a.CAGENTGROUP= oldtable.cagentgroup,
a.SALECHNL= oldtable.salechnl,
a.STATE= oldtable.state,
a.APPNTNO= oldtable.appntno,
a.APPNTNAME= oldtable.appntname,
a.APPNTSEX= oldtable.appntsex,
a.APPNTBIRTHDAY= oldtable.appntbirthday,
a.IDTYPE= oldtable.idtype,
a.IDNO= oldtable.idno,
a.RELATIONWITHINSURED= oldtable.relationwithinsured,
a.NATIVEPLACE= oldtable.nativeplace,
a.COUNTRY= oldtable.country,
a.ADDRESS1= oldtable.address1,
a.ADDRESS2= oldtable.address2,
a.ADDRESS3= oldtable.address3,
a.ZIPCODE= oldtable.zipcode,
a.PHONE= oldtable.phone,
a.POSTADDRESS1= oldtable.postaddress1,
a.POSTADDRESS2= oldtable.postaddress2,
a.POSTADDRESS3= oldtable.postaddress3,
a.POSTADDRESS= oldtable.postaddress,
a.POSTZIPCODE= oldtable.postzipcode,
a.CHARGEADDRESS= oldtable.chargeaddress,
a.CHARGEPHONE= oldtable.chargephone,
a.CUSTCOLLECTADDR= oldtable.custcollectaddr,
a.COMPANY= oldtable.company,
a.MARRIAGE= oldtable.marriage,
a.OCCUPATIONTYPE= oldtable.occupationtype,
a.OCCUPATIONCODE= oldtable.occupationcode,
a.OCCUPATIONNAME= oldtable.occupationname,
a.COCCUPATIONTYPE= oldtable.coccupationtype,
a.COMPANYADDRESS= oldtable.companyaddress,
a.CUSTOFFICEPOST= oldtable.custofficepost,
a.CUSTOFFICEPHONE= oldtable.custofficephone,
a.MOBILEPHONE= oldtable.mobilephone,
a.EMAIL= oldtable.email,
a.PAYINTV= oldtable.payintv,
a.NEWPAYMODE= oldtable.newpaymode,
a.NEWBANKCODE= oldtable.newbankcode,
a.NEWBANKACCNO= oldtable.newbankaccno,
a.PAYMODE= oldtable.paymode,
a.BANKCODE= oldtable.bankcode,
a.BANKACCNO= oldtable.bankaccno,
a.POLAPPLYDATE= oldtable.polapplydate,
a.ACCEPTDATE= oldtable.acceptdate,
a.SIGNDATE= oldtable.signdate,
a.CVALIDATE= oldtable.cvalidate,
a.MATDATE= oldtable.matdate,
a.CUSTOMGETPOLDATE= oldtable.customgetpoldate,
a.RECEIVEDATE= oldtable.receivedate,
a.WITHDRAWDATE= oldtable.withdrawdate,
a.LASTRVALIDATE= oldtable.lastrvalidate,
a.ETL_DATATIME= oldtable.etl_datatime,
a.ENCRYPT_FLAG= oldtable.encrypt_flag,
a.month= oldtable.month,
a.day= oldtable.day,
a.DUEDAY = oldtable.DUEDAY,
a.APL_FLAG = oldtable.APL_FLAG,
a.APL_AMT = oldtable.APL_AMT
from  MAP_LCCont_V a ,MAP_LCCont_Temp oldtable
where a.contno = oldtable.contno and a.AGENTCODE = oldtable.agentcode and a.CAGENTCODE= oldtable.cagentcode and substring(convert(char(25),a.SIGNDATE,0),8,4)=@SIGNDATE_TEMP;
FETCH NEXT FROM my_cursor into @SIGNDATE_TEMP

insert into PolFlushLog values('MAP_LCCont_V_NEW','update',@SIGNDATE_TEMP,getdate())

end;
close my_cursor;
deallocate my_cursor;

 set @iRecordCount_lccontnew=@@rowcount  
insert into PolFlushLog values('MAP_LCCont_V_NEW','update',@iRecordCount_lccontnew,getdate())
go

