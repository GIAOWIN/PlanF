CREATE FUNCTION [dbo].[CalClientNAFYC]( @CAGENTCODE VARCHAR(20),
                                          @CSTARTDATE datetime,
														@CENDDATE datetime)
    RETURNS DECIMAL(12,2)
------------------------------------------------------------------------
-- SQL UDF (Scalar)
-- @author wengf
-- Create date:  2009-7-14
------------------------------------------------------------------------
as BEGIN 
declare @NAFYC DECIMAL(12,4);
declare @fyc DECIMAL(12,4);
declare @afyc DECIMAL(12,4);
declare @lapseFyc DECIMAL(12,4);
declare @reinstateFyc DECIMAL(12,4);

--计算FYC--
 set @fyc =(select coalesce(sum(case when agentcode<>agentcode1 then fyc*0.5 else fyc end),0)  
 from lacommision  where payyear=0 and tmakedate>=@cstartdate and tmakedate<=@cenddate and signdate<'2008-6-3' 
 	and (agentcode=@cagentcode or agentcode1=@cagentcode) 
 	and exists (select 1 from lcpol where lacommision.polno=lcpol.polno and polstate='1'));

---计算afyc--
 set @afyc =(select coalesce(sum(case when agentcode<>agentcode1 then (case when payintv=0 then fyc*0.5 when receiptno='1' then fyc*12*0.5/payintv end) else (case when payintv=0 then fyc when receiptno='1' then fyc*12/payintv end) end),0) 
 from lacommision where payyear=0 and paycount in (0,1) and tmakedate>=@cstartdate
	 and tmakedate<=@cenddate and signdate>='2008-6-3' 
	 and (agentcode=@cagentcode or agentcode1=@cagentcode) 
	 and exists (select 1 from lcpol where lacommision.polno=lcpol.polno and polstate='1'));

 --计算失效--
 set @lapseFyc = (select dbo.LPNAFYCDec(@cagentcode,@cstartdate,@cenddate,9,8) from msysvar where vartype='onerow');

 --计算复效---
 set @reinstateFyc = (select dbo.ReNAFYCLP(@cagentcode,@cstartdate,@cenddate,9,8) from msysvar where vartype='onerow');
 
 --计算nafyc--
 set @NAFYC = @fyc + @afyc + @reinstateFyc - @lapseFyc;

 RETURN round(@NAFYC,2);     
END


go

