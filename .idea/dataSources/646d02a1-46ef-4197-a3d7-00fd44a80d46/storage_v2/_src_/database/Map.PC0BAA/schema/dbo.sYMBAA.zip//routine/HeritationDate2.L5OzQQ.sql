

CREATE FUNCTION [dbo].[HeritationDate2](@CMANAGECOM VARCHAR(4),@CMAINPOLNO VARCHAR(20),@CGETPOLDATE DATETIME,@CSIGNDATE DATETIME)      
RETURNS DATETIME
 as   BEGIN         
DECLARE @tHDate DATETIME 
if @CGETPOLDATE is null   	
	begin          
	return null      
	end 
--modify by ZhouYang CR1500702
-- 承保日在2015/09/21之后的，犹豫期截止日的显示调整为在现有规则下延后5个自然日，即原先加10自然日的变量全部改为15个自然日
if  @CSIGNDATE > '2015-9-21'  
	begin     
	set @tHDate = (select coalesce((select DateAdd(dd,1,enddate)   from laholiday where startdate<=DateAdd(dd,15,@CGETPOLDATE)   and enddate>=DateAdd(dd,15,@CGETPOLDATE) and managecom=@CMANAGECOM),DateAdd(dd,15,@CGETPOLDATE))   from ldsysvar where sysvar='onerow')        
	end
--承保日在2015/09/21（含）之前的，使用现有规则不变
if  @CSIGNDATE <= '2015-9-21'
	begin
	set @tHDate = (select coalesce((select DateAdd(dd,1,enddate)   from laholiday where startdate<=DateAdd(dd,10,@CGETPOLDATE)   and enddate>=DateAdd(dd,10,@CGETPOLDATE) and managecom=@CMANAGECOM),DateAdd(dd,10,@CGETPOLDATE))   from ldsysvar where sysvar='onerow')        
	end
return @tHDate  
END



go

