CREATE FUNCTION [dbo].[dateCompare](
       @FirstDate datetime,
       @SecondDate datetime
       )
    RETURNS varchar(10)

AS BEGIN

    DECLARE @reda varchar(10);			
    DECLARE @yda varchar(10); 
    DECLARE @mda varchar(10);
    DECLARE @dda varchar(10);
    
    set @yda = Convert(varchar(10), DateDiff(year,@FirstDate,@SecondDate));
    set @mda = Convert(varchar(10), DateDiff(month,@FirstDate,@SecondDate)) ;
    set @dda = Convert(varchar(10),DateDiff(day,@FirstDate,@SecondDate));
    set @reda = 1;
       
    if @yda < 0
		set @reda = 0;
    if @yda = 0 and @mda < 0
        set @reda = 0;
    if @yda = 0 and @mda = 0 and @dda < 0
        set @reda = 0;
          	
   return @reda;

END
go

