CREATE FUNCTION [dbo].[ZNHBFUC](@RISKCODE VARCHAR(20),@STANDBYFLAG3 VARCHAR(20) )
    RETURNS VARCHAR(100)

as
begin 
declare @RETURNS varchar(50)
declare @RETURNS1 varchar(50)

      set @RETURNS1 = ( select CODE from LNPCODE where CODEALIAS = @RISKCODE and COMCODE = @STANDBYFLAG3 )

        if @RETURNS1 is not null 
			set @RETURNS = @RETURNS1
		else
			
			set @RETURNS = @RISKCODE
return @RETURNS
end
go

