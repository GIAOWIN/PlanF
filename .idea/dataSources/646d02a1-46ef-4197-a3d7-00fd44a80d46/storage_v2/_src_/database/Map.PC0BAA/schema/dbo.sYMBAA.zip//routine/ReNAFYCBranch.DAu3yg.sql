CREATE FUNCTION [dbo].[ReNAFYCBranch](
       @CBRANCHATTR VARCHAR(20), --代理人编码
       @MonthBegin datetime,
       @MonthEnd datetime
       )
    RETURNS DECIMAL(12,4)
------------------------------------------------------------------------
-- LP P&P奖金 相关项
------------------------------------------------------------------------
BEGIN 


    DECLARE @SUMAFYCReinstate DECIMAL(12,4) ;	
              set @SUMAFYCReinstate=0.00		--总的复效AFYC

    set @SUMAFYCReinstate=(select sum(case when substring(branchattr,1,len(@CBRANCHATTR))=substring(branchattr1,1,len(@CBRANCHATTR)) then fyc*(12/payintv-maxno) else fyc*0.5*(12/payintv-maxno) end ) from lcReinstateDateAcc where branchtype='1' and payintv<>0 and payyear=0 and (substring(branchattr,1,len(@CBRANCHATTR))=@CBRANCHATTR or substring(branchattr1,1,len(@CBRANCHATTR))=@CBRANCHATTR) and signdate>='2008-06-03' and reindate>=@MonthBegin and reindate<=@MonthEnd );
     if @SUMAFYCReinstate is null or @SUMAFYCReinstate < 0 
        begin
         set @SUMAFYCReinstate = 0;
		end
   return @SUMAFYCReinstate;
 end
go

