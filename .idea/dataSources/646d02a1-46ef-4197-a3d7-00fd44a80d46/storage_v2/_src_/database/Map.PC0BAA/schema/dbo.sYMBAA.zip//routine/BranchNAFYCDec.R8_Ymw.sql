CREATE FUNCTION [dbo].[BranchNAFYCDec](
       @CBRANCHATTR VARCHAR(20), --机构编码
       @MonthBegin datetime,
       @MonthEnd datetime
       )
    RETURNS DECIMAL(12,4) 
------------------------------------------------------------------------
-- LP P&P奖金 相关项
------------------------------------------------------------------------
as BEGIN


    DECLARE @SUMAFYCdec DECIMAL(12,4);			--总的应扣除AFYC

    set @SUMAFYCdec=(select sum(case when substring(branchattr,1,len(@CBRANCHATTR))=substring(branchattr1,1,len(@CBRANCHATTR)) then fyc*(12/payintv-maxno) else fyc*0.5*(12/payintv-maxno) end ) from lcfaildateacc where branchtype='1' and payintv<>0 and payyear=0 and (substring(branchattr,1,len(@CBRANCHATTR))=@CBRANCHATTR or substring(branchattr1,1,len(@CBRANCHATTR))=@CBRANCHATTR) and signdate>='2008-06-03' and faildate>=@MonthBegin and faildate<=@MonthEnd );
     if @SUMAFYCdec is null or @SUMAFYCdec < 0 
         set @SUMAFYCdec = 0;
      	
   return @SUMAFYCdec;

END
go

