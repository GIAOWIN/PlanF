CREATE FUNCTION [dbo].[CODETONAME]( @CCODETYPE VARCHAR(20),
                                          @CCODE VARCHAR(20) )
    RETURNS VARCHAR(100)

as

begin 
declare @RETURNS varchar(50)
declare @RETURNS1 varchar(50)

      set @RETURNS1 = ( select codename from ldcode where codetype = @cCodeType and Code = @cCode )

        if @RETURNS1 is not null 
			set @RETURNS = @RETURNS1
		else
			
			set @RETURNS = ''
return @RETURNS
end
go

