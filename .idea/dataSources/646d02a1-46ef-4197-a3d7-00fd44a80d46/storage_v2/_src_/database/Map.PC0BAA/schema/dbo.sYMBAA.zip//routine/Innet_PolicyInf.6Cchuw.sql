
CREATE PROCEDURE [dbo].[Innet_PolicyInf] 
AS
--按年写入 (2005,2006,2007,2008,2009,2010,2011,2012,2013)
--2013
declare @iRecordCount_LCCont2013 int 
insert into MAP_lccont_V select * from ( 
SELECT DISTINCT   tb_app.CD_POLICY_COMPLEMENT, 
tb_app.CD_PREPRINTED_APPLICATION, 
'' AS Expr1, 
la.MANAGECOM, 
'' AS Expr2, 
la.AGENTCODE, 
'' AS Expr3, 
'' AS Expr4,
(SELECT BRANCHATTR FROM dbo.LABRANCHGROUP WHERE (AGENTGROUP = la.AGENTGROUP)) AS Expr24, 
'' AS Expr5, 
'' AS Expr6, 
la.BRANCHTYPE, 
CASE WHEN tb_app.de_status = 'Active' THEN '1' WHEN tb_app.de_status = 'Insolv. Canceled' THEN '0' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'SR' THEN '5' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'FL' THEN '3' ELSE '' END AS de_status,
CAST(tb_g.CD_GROUP_NUMBER AS nvarchar(10)) AS Expr7, 
tb_g.NM_GROUP_NUMBER, 
CASE WHEN tb_g.DE_SEX = 'Female' THEN '1' WHEN tb_g.DE_SEX = 'Male' THEN '0' ELSE '' END AS de_sex,
tb_g.DT_BIRTH, 
tb_g.DE_TYPE_DOCUMENT, 
tb_g.NR_DOCUMENT, 
'' AS Expr8, 
tb_g.CD_NATIONALITY, 
tb_g.NM_COUNTRY, 
tb_g.NM_ADDRESS, 
tb_g.NM_ADDRESS1, 
tb_g.NM_ADDRESS2, 
tb_g.NM_ZIP_CODE, 
tb_g.NM_PHONE, 
tb_g.NM_MAILING_ADDRESS, 
tb_g.NM_MAILING_ADDRESS1, 
tb_g.NM_MAILING_ADDRESS2, 
'' AS Expr9, 
tb_g.NM_MAILING_ZIP_CODE, 
tb_g.NM_COLLECTION_ADDRESS, 
tb_g.NM_COLLECTION_PHONE, 
tb_g.NM_COLLECTION_ZIP_CODE, 
tb_g.NM_EMPLOYER, tb_g.DE_MARITAL_STATUS, 
'' AS Expr10, 
CAST(tb_g.CD_OCCUPATION AS nvarchar(10)) AS Expr11, 
'' AS Expr12, 
'' AS Expr13, 
tb_g.NM_OFFICE_ADDRESS1, 
'' AS Expr14, 
tb_g.NM_PHONE_COM, 
'' AS Expr15, 
tb_g.NM_EMAIL, 
tb_app_co.DE_PERIODICITY_PAYMENT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_FIRST_PARCEL) AS Expr22, 
tb_app.NM_DEBIT_BANK, 
tb_app.NR_DEBIT_ACCOUNT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_PARCEL) AS Expr23,  
tb_app.NM_DEBIT_BANK AS Expr16, 
tb_app.NR_DEBIT_ACCOUNT AS Expr17, 
'' AS Expr18, 
tb_app.DT_INTRODUCTION, 
tb_app.DT_POLICY_ACTIVATION,                       
tb_app_co.DT_CONTRACTING, 
'' AS Expr19, 
tb_app.DT_RECEIVING_APPLICATION, 
'' AS Expr20, 
tb_app.DT_CANCELLING, 
tb_app.DT_REACTIVATION,                       
tb_g.DT_DATATIME AS Expr21, 
tb_g.ENCRYPT_FLAG, 
MONTH(tb_g.DT_BIRTH) AS month, 
DAY(tb_g.DT_BIRTH) AS day 
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_GROUP_NUMBER_Encrypt AS tb_g ON tb_app.CD_ADMINISTRATOR = tb_g.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_g.CD_BRANCH AND tb_app.CD_ADMINISTRATOR_GROUP_NUMBER = tb_g.CD_GROUP_NUMBER AND tb_g.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
INNER JOIN  dbo.TB_COVERAGE AS tb_co ON tb_co.CD_COVERAGE = tb_app_co.CD_COVERAGE 
WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2013' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
AND tb_co.FL_BASIC = 'Y' AND tb_co.nm_coverage_reduced<>'DE0001'
)oldtable
set @iRecordCount_LCCont2013=@@rowcount 
insert into PolFlushLog values('MAP_LCcont_old-2013','innet',@iRecordCount_LCCont2013,getdate())

--2012
declare @iRecordCount_LCCont2012 int 
insert into MAP_lccont_V select * from ( 
SELECT DISTINCT   tb_app.CD_POLICY_COMPLEMENT, 
tb_app.CD_PREPRINTED_APPLICATION, 
'' AS Expr1, 
la.MANAGECOM, 
'' AS Expr2, 
la.AGENTCODE, 
'' AS Expr3, 
'' AS Expr4,
(SELECT BRANCHATTR FROM dbo.LABRANCHGROUP WHERE (AGENTGROUP = la.AGENTGROUP)) AS Expr24, 
'' AS Expr5, 
'' AS Expr6, 
la.BRANCHTYPE, 
CASE WHEN tb_app.de_status = 'Active' THEN '1' WHEN tb_app.de_status = 'Insolv. Canceled' THEN '0' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'SR' THEN '5' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'FL' THEN '3' ELSE '' END AS de_status,
CAST(tb_g.CD_GROUP_NUMBER AS nvarchar(10)) AS Expr7, 
tb_g.NM_GROUP_NUMBER, 
CASE WHEN tb_g.DE_SEX = 'Female' THEN '1' WHEN tb_g.DE_SEX = 'Male' THEN '0' ELSE '' END AS de_sex,
tb_g.DT_BIRTH, 
tb_g.DE_TYPE_DOCUMENT, 
tb_g.NR_DOCUMENT, 
'' AS Expr8, 
tb_g.CD_NATIONALITY, 
tb_g.NM_COUNTRY, 
tb_g.NM_ADDRESS, 
tb_g.NM_ADDRESS1, 
tb_g.NM_ADDRESS2, 
tb_g.NM_ZIP_CODE, 
tb_g.NM_PHONE, 
tb_g.NM_MAILING_ADDRESS, 
tb_g.NM_MAILING_ADDRESS1, 
tb_g.NM_MAILING_ADDRESS2, 
'' AS Expr9, 
tb_g.NM_MAILING_ZIP_CODE, 
tb_g.NM_COLLECTION_ADDRESS, 
tb_g.NM_COLLECTION_PHONE, 
tb_g.NM_COLLECTION_ZIP_CODE, 
tb_g.NM_EMPLOYER, tb_g.DE_MARITAL_STATUS, 
'' AS Expr10, 
CAST(tb_g.CD_OCCUPATION AS nvarchar(10)) AS Expr11, 
'' AS Expr12, 
'' AS Expr13, 
tb_g.NM_OFFICE_ADDRESS1, 
'' AS Expr14, 
tb_g.NM_PHONE_COM, 
'' AS Expr15, 
tb_g.NM_EMAIL, 
tb_app_co.DE_PERIODICITY_PAYMENT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_FIRST_PARCEL) AS Expr22, 
tb_app.NM_DEBIT_BANK, 
tb_app.NR_DEBIT_ACCOUNT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_PARCEL) AS Expr23,  
tb_app.NM_DEBIT_BANK AS Expr16, 
tb_app.NR_DEBIT_ACCOUNT AS Expr17, 
'' AS Expr18, 
tb_app.DT_INTRODUCTION, 
tb_app.DT_POLICY_ACTIVATION,                       
tb_app_co.DT_CONTRACTING, 
'' AS Expr19, 
tb_app.DT_RECEIVING_APPLICATION, 
'' AS Expr20, 
tb_app.DT_CANCELLING, 
tb_app.DT_REACTIVATION,                       
tb_g.DT_DATATIME AS Expr21, 
tb_g.ENCRYPT_FLAG, 
MONTH(tb_g.DT_BIRTH) AS month, 
DAY(tb_g.DT_BIRTH) AS day 
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_GROUP_NUMBER_Encrypt AS tb_g ON tb_app.CD_ADMINISTRATOR = tb_g.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_g.CD_BRANCH AND tb_app.CD_ADMINISTRATOR_GROUP_NUMBER = tb_g.CD_GROUP_NUMBER AND tb_g.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
INNER JOIN  dbo.TB_COVERAGE AS tb_co ON tb_co.CD_COVERAGE = tb_app_co.CD_COVERAGE 
WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2012' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
AND tb_co.FL_BASIC = 'Y' AND tb_co.nm_coverage_reduced<>'DE0001'
)oldtable
 set @iRecordCount_LCCont2012=@@rowcount  
insert into PolFlushLog values('MAP_LCcont_old-2012','innet',@iRecordCount_LCCont2012,getdate())

--2011
declare @iRecordCount_LCCont2011 int 
insert into MAP_lccont_V select * from ( 
SELECT DISTINCT   tb_app.CD_POLICY_COMPLEMENT, 
tb_app.CD_PREPRINTED_APPLICATION, 
'' AS Expr1, 
la.MANAGECOM, 
'' AS Expr2, 
la.AGENTCODE, 
'' AS Expr3, 
'' AS Expr4,
(SELECT BRANCHATTR FROM dbo.LABRANCHGROUP WHERE (AGENTGROUP = la.AGENTGROUP)) AS Expr24, 
'' AS Expr5, 
'' AS Expr6, 
la.BRANCHTYPE, 
CASE WHEN tb_app.de_status = 'Active' THEN '1' WHEN tb_app.de_status = 'Insolv. Canceled' THEN '0' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'SR' THEN '5' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'FL' THEN '3' ELSE '' END AS de_status,
CAST(tb_g.CD_GROUP_NUMBER AS nvarchar(10)) AS Expr7, 
tb_g.NM_GROUP_NUMBER, 
CASE WHEN tb_g.DE_SEX = 'Female' THEN '1' WHEN tb_g.DE_SEX = 'Male' THEN '0' ELSE '' END AS de_sex,
tb_g.DT_BIRTH, 
tb_g.DE_TYPE_DOCUMENT, 
tb_g.NR_DOCUMENT, 
'' AS Expr8, 
tb_g.CD_NATIONALITY, 
tb_g.NM_COUNTRY, 
tb_g.NM_ADDRESS, 
tb_g.NM_ADDRESS1, 
tb_g.NM_ADDRESS2, 
tb_g.NM_ZIP_CODE, 
tb_g.NM_PHONE, 
tb_g.NM_MAILING_ADDRESS, 
tb_g.NM_MAILING_ADDRESS1, 
tb_g.NM_MAILING_ADDRESS2, 
'' AS Expr9, 
tb_g.NM_MAILING_ZIP_CODE, 
tb_g.NM_COLLECTION_ADDRESS, 
tb_g.NM_COLLECTION_PHONE, 
tb_g.NM_COLLECTION_ZIP_CODE, 
tb_g.NM_EMPLOYER, tb_g.DE_MARITAL_STATUS, 
'' AS Expr10, 
CAST(tb_g.CD_OCCUPATION AS nvarchar(10)) AS Expr11, 
'' AS Expr12, 
'' AS Expr13, 
tb_g.NM_OFFICE_ADDRESS1, 
'' AS Expr14, 
tb_g.NM_PHONE_COM, 
'' AS Expr15, 
tb_g.NM_EMAIL, 
tb_app_co.DE_PERIODICITY_PAYMENT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_FIRST_PARCEL) AS Expr22, 
tb_app.NM_DEBIT_BANK, 
tb_app.NR_DEBIT_ACCOUNT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_PARCEL) AS Expr23,  
tb_app.NM_DEBIT_BANK AS Expr16, 
tb_app.NR_DEBIT_ACCOUNT AS Expr17, 
'' AS Expr18, 
tb_app.DT_INTRODUCTION, 
tb_app.DT_POLICY_ACTIVATION,                       
tb_app_co.DT_CONTRACTING, 
'' AS Expr19, 
tb_app.DT_RECEIVING_APPLICATION, 
'' AS Expr20, 
tb_app.DT_CANCELLING, 
tb_app.DT_REACTIVATION,                       
tb_g.DT_DATATIME AS Expr21, 
tb_g.ENCRYPT_FLAG, 
MONTH(tb_g.DT_BIRTH) AS month, 
DAY(tb_g.DT_BIRTH) AS day 
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_GROUP_NUMBER_Encrypt AS tb_g ON tb_app.CD_ADMINISTRATOR = tb_g.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_g.CD_BRANCH AND tb_app.CD_ADMINISTRATOR_GROUP_NUMBER = tb_g.CD_GROUP_NUMBER AND tb_g.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
INNER JOIN  dbo.TB_COVERAGE AS tb_co ON tb_co.CD_COVERAGE = tb_app_co.CD_COVERAGE 
WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2011' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
AND tb_co.FL_BASIC = 'Y' AND tb_co.nm_coverage_reduced<>'DE0001'
)oldtable
set @iRecordCount_LCCont2011=@@rowcount 
insert into PolFlushLog values('MAP_LCcont_old-2011','innet',@iRecordCount_LCCont2011,getdate())

--2010
declare @iRecordCount_LCCont2010 int 
insert into MAP_lccont_V select * from ( 
SELECT DISTINCT   tb_app.CD_POLICY_COMPLEMENT, 
tb_app.CD_PREPRINTED_APPLICATION, 
'' AS Expr1, 
la.MANAGECOM, 
'' AS Expr2, 
la.AGENTCODE, 
'' AS Expr3, 
'' AS Expr4,
(SELECT BRANCHATTR FROM dbo.LABRANCHGROUP WHERE (AGENTGROUP = la.AGENTGROUP)) AS Expr24, 
'' AS Expr5, 
'' AS Expr6, 
la.BRANCHTYPE, 
CASE WHEN tb_app.de_status = 'Active' THEN '1' WHEN tb_app.de_status = 'Insolv. Canceled' THEN '0' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'SR' THEN '5' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'FL' THEN '3' ELSE '' END AS de_status,
CAST(tb_g.CD_GROUP_NUMBER AS nvarchar(10)) AS Expr7, 
tb_g.NM_GROUP_NUMBER, 
CASE WHEN tb_g.DE_SEX = 'Female' THEN '1' WHEN tb_g.DE_SEX = 'Male' THEN '0' ELSE '' END AS de_sex,
tb_g.DT_BIRTH, 
tb_g.DE_TYPE_DOCUMENT, 
tb_g.NR_DOCUMENT, 
'' AS Expr8, 
tb_g.CD_NATIONALITY, 
tb_g.NM_COUNTRY, 
tb_g.NM_ADDRESS, 
tb_g.NM_ADDRESS1, 
tb_g.NM_ADDRESS2, 
tb_g.NM_ZIP_CODE, 
tb_g.NM_PHONE, 
tb_g.NM_MAILING_ADDRESS, 
tb_g.NM_MAILING_ADDRESS1, 
tb_g.NM_MAILING_ADDRESS2, 
'' AS Expr9, 
tb_g.NM_MAILING_ZIP_CODE, 
tb_g.NM_COLLECTION_ADDRESS, 
tb_g.NM_COLLECTION_PHONE, 
tb_g.NM_COLLECTION_ZIP_CODE, 
tb_g.NM_EMPLOYER, tb_g.DE_MARITAL_STATUS, 
'' AS Expr10, 
CAST(tb_g.CD_OCCUPATION AS nvarchar(10)) AS Expr11, 
'' AS Expr12, 
'' AS Expr13, 
tb_g.NM_OFFICE_ADDRESS1, 
'' AS Expr14, 
tb_g.NM_PHONE_COM, 
'' AS Expr15, 
tb_g.NM_EMAIL, 
tb_app_co.DE_PERIODICITY_PAYMENT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_FIRST_PARCEL) AS Expr22, 
tb_app.NM_DEBIT_BANK, 
tb_app.NR_DEBIT_ACCOUNT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_PARCEL) AS Expr23,  
tb_app.NM_DEBIT_BANK AS Expr16, 
tb_app.NR_DEBIT_ACCOUNT AS Expr17, 
'' AS Expr18, 
tb_app.DT_INTRODUCTION, 
tb_app.DT_POLICY_ACTIVATION,                       
tb_app_co.DT_CONTRACTING, 
'' AS Expr19, 
tb_app.DT_RECEIVING_APPLICATION, 
'' AS Expr20, 
tb_app.DT_CANCELLING, 
tb_app.DT_REACTIVATION,                       
tb_g.DT_DATATIME AS Expr21, 
tb_g.ENCRYPT_FLAG, 
MONTH(tb_g.DT_BIRTH) AS month, 
DAY(tb_g.DT_BIRTH) AS day 
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_GROUP_NUMBER_Encrypt AS tb_g ON tb_app.CD_ADMINISTRATOR = tb_g.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_g.CD_BRANCH AND tb_app.CD_ADMINISTRATOR_GROUP_NUMBER = tb_g.CD_GROUP_NUMBER AND tb_g.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
INNER JOIN  dbo.TB_COVERAGE AS tb_co ON tb_co.CD_COVERAGE = tb_app_co.CD_COVERAGE 
WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2010' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
AND tb_co.FL_BASIC = 'Y' AND tb_co.nm_coverage_reduced<>'DE0001'
)oldtable
set @iRecordCount_LCCont2010=@@rowcount 
insert into PolFlushLog values('MAP_LCcont_old-2010','innet',@iRecordCount_LCCont2010,getdate())

--2009
declare @iRecordCount_LCCont2009 int 
insert into MAP_lccont_V select * from ( 
SELECT DISTINCT   tb_app.CD_POLICY_COMPLEMENT, 
tb_app.CD_PREPRINTED_APPLICATION, 
'' AS Expr1, 
la.MANAGECOM, 
'' AS Expr2, 
la.AGENTCODE, 
'' AS Expr3, 
'' AS Expr4,
(SELECT BRANCHATTR FROM dbo.LABRANCHGROUP WHERE (AGENTGROUP = la.AGENTGROUP)) AS Expr24, 
'' AS Expr5, 
'' AS Expr6, 
la.BRANCHTYPE, 
CASE WHEN tb_app.de_status = 'Active' THEN '1' WHEN tb_app.de_status = 'Insolv. Canceled' THEN '0' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'SR' THEN '5' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'FL' THEN '3' ELSE '' END AS de_status,
CAST(tb_g.CD_GROUP_NUMBER AS nvarchar(10)) AS Expr7, 
tb_g.NM_GROUP_NUMBER, 
CASE WHEN tb_g.DE_SEX = 'Female' THEN '1' WHEN tb_g.DE_SEX = 'Male' THEN '0' ELSE '' END AS de_sex,
tb_g.DT_BIRTH, 
tb_g.DE_TYPE_DOCUMENT, 
tb_g.NR_DOCUMENT, 
'' AS Expr8, 
tb_g.CD_NATIONALITY, 
tb_g.NM_COUNTRY, 
tb_g.NM_ADDRESS, 
tb_g.NM_ADDRESS1, 
tb_g.NM_ADDRESS2, 
tb_g.NM_ZIP_CODE, 
tb_g.NM_PHONE, 
tb_g.NM_MAILING_ADDRESS, 
tb_g.NM_MAILING_ADDRESS1, 
tb_g.NM_MAILING_ADDRESS2, 
'' AS Expr9, 
tb_g.NM_MAILING_ZIP_CODE, 
tb_g.NM_COLLECTION_ADDRESS, 
tb_g.NM_COLLECTION_PHONE, 
tb_g.NM_COLLECTION_ZIP_CODE, 
tb_g.NM_EMPLOYER, tb_g.DE_MARITAL_STATUS, 
'' AS Expr10, 
CAST(tb_g.CD_OCCUPATION AS nvarchar(10)) AS Expr11, 
'' AS Expr12, 
'' AS Expr13, 
tb_g.NM_OFFICE_ADDRESS1, 
'' AS Expr14, 
tb_g.NM_PHONE_COM, 
'' AS Expr15, 
tb_g.NM_EMAIL, 
tb_app_co.DE_PERIODICITY_PAYMENT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_FIRST_PARCEL) AS Expr22, 
tb_app.NM_DEBIT_BANK, 
tb_app.NR_DEBIT_ACCOUNT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_PARCEL) AS Expr23,  
tb_app.NM_DEBIT_BANK AS Expr16, 
tb_app.NR_DEBIT_ACCOUNT AS Expr17, 
'' AS Expr18, 
tb_app.DT_INTRODUCTION, 
tb_app.DT_POLICY_ACTIVATION,                       
tb_app_co.DT_CONTRACTING, 
'' AS Expr19, 
tb_app.DT_RECEIVING_APPLICATION, 
'' AS Expr20, 
tb_app.DT_CANCELLING, 
tb_app.DT_REACTIVATION,                       
tb_g.DT_DATATIME AS Expr21, 
tb_g.ENCRYPT_FLAG, 
MONTH(tb_g.DT_BIRTH) AS month, 
DAY(tb_g.DT_BIRTH) AS day 
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_GROUP_NUMBER_Encrypt AS tb_g ON tb_app.CD_ADMINISTRATOR = tb_g.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_g.CD_BRANCH AND tb_app.CD_ADMINISTRATOR_GROUP_NUMBER = tb_g.CD_GROUP_NUMBER AND tb_g.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
INNER JOIN  dbo.TB_COVERAGE AS tb_co ON tb_co.CD_COVERAGE = tb_app_co.CD_COVERAGE 
WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2009' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
AND tb_co.FL_BASIC = 'Y' AND tb_co.nm_coverage_reduced<>'DE0001'
)oldtable
set @iRecordCount_LCCont2009=@@rowcount 
insert into PolFlushLog values('MAP_LCcont_old-2009','innet',@iRecordCount_LCCont2009,getdate())

--2008
declare @iRecordCount_LCCont2008 int 
insert into MAP_lccont_V select * from ( 
SELECT DISTINCT   tb_app.CD_POLICY_COMPLEMENT, 
tb_app.CD_PREPRINTED_APPLICATION, 
'' AS Expr1, 
la.MANAGECOM, 
'' AS Expr2, 
la.AGENTCODE, 
'' AS Expr3, 
'' AS Expr4,
(SELECT BRANCHATTR FROM dbo.LABRANCHGROUP WHERE (AGENTGROUP = la.AGENTGROUP)) AS Expr24, 
'' AS Expr5, 
'' AS Expr6, 
la.BRANCHTYPE, 
CASE WHEN tb_app.de_status = 'Active' THEN '1' WHEN tb_app.de_status = 'Insolv. Canceled' THEN '0' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'SR' THEN '5' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'FL' THEN '3' ELSE '' END AS de_status,
CAST(tb_g.CD_GROUP_NUMBER AS nvarchar(10)) AS Expr7, 
tb_g.NM_GROUP_NUMBER, 
CASE WHEN tb_g.DE_SEX = 'Female' THEN '1' WHEN tb_g.DE_SEX = 'Male' THEN '0' ELSE '' END AS de_sex,
tb_g.DT_BIRTH, 
tb_g.DE_TYPE_DOCUMENT, 
tb_g.NR_DOCUMENT, 
'' AS Expr8, 
tb_g.CD_NATIONALITY, 
tb_g.NM_COUNTRY, 
tb_g.NM_ADDRESS, 
tb_g.NM_ADDRESS1, 
tb_g.NM_ADDRESS2, 
tb_g.NM_ZIP_CODE, 
tb_g.NM_PHONE, 
tb_g.NM_MAILING_ADDRESS, 
tb_g.NM_MAILING_ADDRESS1, 
tb_g.NM_MAILING_ADDRESS2, 
'' AS Expr9, 
tb_g.NM_MAILING_ZIP_CODE, 
tb_g.NM_COLLECTION_ADDRESS, 
tb_g.NM_COLLECTION_PHONE, 
tb_g.NM_COLLECTION_ZIP_CODE, 
tb_g.NM_EMPLOYER, tb_g.DE_MARITAL_STATUS, 
'' AS Expr10, 
CAST(tb_g.CD_OCCUPATION AS nvarchar(10)) AS Expr11, 
'' AS Expr12, 
'' AS Expr13, 
tb_g.NM_OFFICE_ADDRESS1, 
'' AS Expr14, 
tb_g.NM_PHONE_COM, 
'' AS Expr15, 
tb_g.NM_EMAIL, 
tb_app_co.DE_PERIODICITY_PAYMENT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_FIRST_PARCEL) AS Expr22, 
tb_app.NM_DEBIT_BANK, 
tb_app.NR_DEBIT_ACCOUNT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_PARCEL) AS Expr23,  
tb_app.NM_DEBIT_BANK AS Expr16, 
tb_app.NR_DEBIT_ACCOUNT AS Expr17, 
'' AS Expr18, 
tb_app.DT_INTRODUCTION, 
tb_app.DT_POLICY_ACTIVATION,                       
tb_app_co.DT_CONTRACTING, 
'' AS Expr19, 
tb_app.DT_RECEIVING_APPLICATION, 
'' AS Expr20, 
tb_app.DT_CANCELLING, 
tb_app.DT_REACTIVATION,                       
tb_g.DT_DATATIME AS Expr21, 
tb_g.ENCRYPT_FLAG, 
MONTH(tb_g.DT_BIRTH) AS month, 
DAY(tb_g.DT_BIRTH) AS day 
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_GROUP_NUMBER_Encrypt AS tb_g ON tb_app.CD_ADMINISTRATOR = tb_g.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_g.CD_BRANCH AND tb_app.CD_ADMINISTRATOR_GROUP_NUMBER = tb_g.CD_GROUP_NUMBER AND tb_g.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
INNER JOIN  dbo.TB_COVERAGE AS tb_co ON tb_co.CD_COVERAGE = tb_app_co.CD_COVERAGE 
WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2008' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
AND tb_co.FL_BASIC = 'Y' AND tb_co.nm_coverage_reduced<>'DE0001'
)oldtable
set @iRecordCount_LCCont2008=@@rowcount 
insert into PolFlushLog values('MAP_LCcont_old-2008','innet',@iRecordCount_LCCont2008,getdate())

--2007
declare @iRecordCount_LCCont2007 int 
insert into MAP_lccont_V select * from ( 
SELECT DISTINCT   tb_app.CD_POLICY_COMPLEMENT, 
tb_app.CD_PREPRINTED_APPLICATION, 
'' AS Expr1, 
la.MANAGECOM, 
'' AS Expr2, 
la.AGENTCODE, 
'' AS Expr3, 
'' AS Expr4,
(SELECT BRANCHATTR FROM dbo.LABRANCHGROUP WHERE (AGENTGROUP = la.AGENTGROUP)) AS Expr24, 
'' AS Expr5, 
'' AS Expr6, 
la.BRANCHTYPE, 
CASE WHEN tb_app.de_status = 'Active' THEN '1' WHEN tb_app.de_status = 'Insolv. Canceled' THEN '0' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'SR' THEN '5' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'FL' THEN '3' ELSE '' END AS de_status,
CAST(tb_g.CD_GROUP_NUMBER AS nvarchar(10)) AS Expr7, 
tb_g.NM_GROUP_NUMBER, 
CASE WHEN tb_g.DE_SEX = 'Female' THEN '1' WHEN tb_g.DE_SEX = 'Male' THEN '0' ELSE '' END AS de_sex,
tb_g.DT_BIRTH, 
tb_g.DE_TYPE_DOCUMENT, 
tb_g.NR_DOCUMENT, 
'' AS Expr8, 
tb_g.CD_NATIONALITY, 
tb_g.NM_COUNTRY, 
tb_g.NM_ADDRESS, 
tb_g.NM_ADDRESS1, 
tb_g.NM_ADDRESS2, 
tb_g.NM_ZIP_CODE, 
tb_g.NM_PHONE, 
tb_g.NM_MAILING_ADDRESS, 
tb_g.NM_MAILING_ADDRESS1, 
tb_g.NM_MAILING_ADDRESS2, 
'' AS Expr9, 
tb_g.NM_MAILING_ZIP_CODE, 
tb_g.NM_COLLECTION_ADDRESS, 
tb_g.NM_COLLECTION_PHONE, 
tb_g.NM_COLLECTION_ZIP_CODE, 
tb_g.NM_EMPLOYER, tb_g.DE_MARITAL_STATUS, 
'' AS Expr10, 
CAST(tb_g.CD_OCCUPATION AS nvarchar(10)) AS Expr11, 
'' AS Expr12, 
'' AS Expr13, 
tb_g.NM_OFFICE_ADDRESS1, 
'' AS Expr14, 
tb_g.NM_PHONE_COM, 
'' AS Expr15, 
tb_g.NM_EMAIL, 
tb_app_co.DE_PERIODICITY_PAYMENT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_FIRST_PARCEL) AS Expr22, 
tb_app.NM_DEBIT_BANK, 
tb_app.NR_DEBIT_ACCOUNT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_PARCEL) AS Expr23,  
tb_app.NM_DEBIT_BANK AS Expr16, 
tb_app.NR_DEBIT_ACCOUNT AS Expr17, 
'' AS Expr18, 
tb_app.DT_INTRODUCTION, 
tb_app.DT_POLICY_ACTIVATION,                       
tb_app_co.DT_CONTRACTING, 
'' AS Expr19, 
tb_app.DT_RECEIVING_APPLICATION, 
'' AS Expr20, 
tb_app.DT_CANCELLING, 
tb_app.DT_REACTIVATION,                       
tb_g.DT_DATATIME AS Expr21, 
tb_g.ENCRYPT_FLAG, 
MONTH(tb_g.DT_BIRTH) AS month, 
DAY(tb_g.DT_BIRTH) AS day 
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_GROUP_NUMBER_Encrypt AS tb_g ON tb_app.CD_ADMINISTRATOR = tb_g.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_g.CD_BRANCH AND tb_app.CD_ADMINISTRATOR_GROUP_NUMBER = tb_g.CD_GROUP_NUMBER AND tb_g.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
INNER JOIN  dbo.TB_COVERAGE AS tb_co ON tb_co.CD_COVERAGE = tb_app_co.CD_COVERAGE 
WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2007' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
AND tb_co.FL_BASIC = 'Y' AND tb_co.nm_coverage_reduced<>'DE0001'
)oldtable
set @iRecordCount_LCCont2007=@@rowcount 
insert into PolFlushLog values('MAP_LCcont_old-2007','innet',@iRecordCount_LCCont2007,getdate())

--2006
declare @iRecordCount_LCCont2006 int 
insert into MAP_lccont_V select * from ( 
SELECT DISTINCT   tb_app.CD_POLICY_COMPLEMENT, 
tb_app.CD_PREPRINTED_APPLICATION, 
'' AS Expr1, 
la.MANAGECOM, 
'' AS Expr2, 
la.AGENTCODE, 
'' AS Expr3, 
'' AS Expr4,
(SELECT BRANCHATTR FROM dbo.LABRANCHGROUP WHERE (AGENTGROUP = la.AGENTGROUP)) AS Expr24, 
'' AS Expr5, 
'' AS Expr6, 
la.BRANCHTYPE, 
CASE WHEN tb_app.de_status = 'Active' THEN '1' WHEN tb_app.de_status = 'Insolv. Canceled' THEN '0' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'SR' THEN '5' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'FL' THEN '3' ELSE '' END AS de_status,
CAST(tb_g.CD_GROUP_NUMBER AS nvarchar(10)) AS Expr7, 
tb_g.NM_GROUP_NUMBER, 
CASE WHEN tb_g.DE_SEX = 'Female' THEN '1' WHEN tb_g.DE_SEX = 'Male' THEN '0' ELSE '' END AS de_sex,
tb_g.DT_BIRTH, 
tb_g.DE_TYPE_DOCUMENT, 
tb_g.NR_DOCUMENT, 
'' AS Expr8, 
tb_g.CD_NATIONALITY, 
tb_g.NM_COUNTRY, 
tb_g.NM_ADDRESS, 
tb_g.NM_ADDRESS1, 
tb_g.NM_ADDRESS2, 
tb_g.NM_ZIP_CODE, 
tb_g.NM_PHONE, 
tb_g.NM_MAILING_ADDRESS, 
tb_g.NM_MAILING_ADDRESS1, 
tb_g.NM_MAILING_ADDRESS2, 
'' AS Expr9, 
tb_g.NM_MAILING_ZIP_CODE, 
tb_g.NM_COLLECTION_ADDRESS, 
tb_g.NM_COLLECTION_PHONE, 
tb_g.NM_COLLECTION_ZIP_CODE, 
tb_g.NM_EMPLOYER, tb_g.DE_MARITAL_STATUS, 
'' AS Expr10, 
CAST(tb_g.CD_OCCUPATION AS nvarchar(10)) AS Expr11, 
'' AS Expr12, 
'' AS Expr13, 
tb_g.NM_OFFICE_ADDRESS1, 
'' AS Expr14, 
tb_g.NM_PHONE_COM, 
'' AS Expr15, 
tb_g.NM_EMAIL, 
tb_app_co.DE_PERIODICITY_PAYMENT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_FIRST_PARCEL) AS Expr22, 
tb_app.NM_DEBIT_BANK, 
tb_app.NR_DEBIT_ACCOUNT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_PARCEL) AS Expr23,  
tb_app.NM_DEBIT_BANK AS Expr16, 
tb_app.NR_DEBIT_ACCOUNT AS Expr17, 
'' AS Expr18, 
tb_app.DT_INTRODUCTION, 
tb_app.DT_POLICY_ACTIVATION,                       
tb_app_co.DT_CONTRACTING, 
'' AS Expr19, 
tb_app.DT_RECEIVING_APPLICATION, 
'' AS Expr20, 
tb_app.DT_CANCELLING, 
tb_app.DT_REACTIVATION,                       
tb_g.DT_DATATIME AS Expr21, 
tb_g.ENCRYPT_FLAG, 
MONTH(tb_g.DT_BIRTH) AS month, 
DAY(tb_g.DT_BIRTH) AS day 
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_GROUP_NUMBER_Encrypt AS tb_g ON tb_app.CD_ADMINISTRATOR = tb_g.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_g.CD_BRANCH AND tb_app.CD_ADMINISTRATOR_GROUP_NUMBER = tb_g.CD_GROUP_NUMBER AND tb_g.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
INNER JOIN  dbo.TB_COVERAGE AS tb_co ON tb_co.CD_COVERAGE = tb_app_co.CD_COVERAGE 
WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2006' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
AND tb_co.FL_BASIC = 'Y' AND tb_co.nm_coverage_reduced<>'DE0001'
)oldtable
set @iRecordCount_LCCont2006=@@rowcount 
insert into PolFlushLog values('MAP_LCcont_old-2006','innet',@iRecordCount_LCCont2006,getdate())

--2005
declare @iRecordCount_LCCont2005 int 
insert into MAP_lccont_V select * from ( 
SELECT DISTINCT   tb_app.CD_POLICY_COMPLEMENT, 
tb_app.CD_PREPRINTED_APPLICATION, 
'' AS Expr1, 
la.MANAGECOM, 
'' AS Expr2, 
la.AGENTCODE, 
'' AS Expr3, 
'' AS Expr4,
(SELECT BRANCHATTR FROM dbo.LABRANCHGROUP WHERE (AGENTGROUP = la.AGENTGROUP)) AS Expr24, 
'' AS Expr5, 
'' AS Expr6, 
la.BRANCHTYPE, 
CASE WHEN tb_app.de_status = 'Active' THEN '1' WHEN tb_app.de_status = 'Insolv. Canceled' THEN '0' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'SR' THEN '5' WHEN tb_app.de_status = 'Cancelled' AND tb_app.cd_reason = 'FL' THEN '3' ELSE '' END AS de_status,
CAST(tb_g.CD_GROUP_NUMBER AS nvarchar(10)) AS Expr7, 
tb_g.NM_GROUP_NUMBER, 
CASE WHEN tb_g.DE_SEX = 'Female' THEN '1' WHEN tb_g.DE_SEX = 'Male' THEN '0' ELSE '' END AS de_sex,
tb_g.DT_BIRTH, 
tb_g.DE_TYPE_DOCUMENT, 
tb_g.NR_DOCUMENT, 
'' AS Expr8, 
tb_g.CD_NATIONALITY, 
tb_g.NM_COUNTRY, 
tb_g.NM_ADDRESS, 
tb_g.NM_ADDRESS1, 
tb_g.NM_ADDRESS2, 
tb_g.NM_ZIP_CODE, 
tb_g.NM_PHONE, 
tb_g.NM_MAILING_ADDRESS, 
tb_g.NM_MAILING_ADDRESS1, 
tb_g.NM_MAILING_ADDRESS2, 
'' AS Expr9, 
tb_g.NM_MAILING_ZIP_CODE, 
tb_g.NM_COLLECTION_ADDRESS, 
tb_g.NM_COLLECTION_PHONE, 
tb_g.NM_COLLECTION_ZIP_CODE, 
tb_g.NM_EMPLOYER, tb_g.DE_MARITAL_STATUS, 
'' AS Expr10, 
CAST(tb_g.CD_OCCUPATION AS nvarchar(10)) AS Expr11, 
'' AS Expr12, 
'' AS Expr13, 
tb_g.NM_OFFICE_ADDRESS1, 
'' AS Expr14, 
tb_g.NM_PHONE_COM, 
'' AS Expr15, 
tb_g.NM_EMAIL, 
tb_app_co.DE_PERIODICITY_PAYMENT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_FIRST_PARCEL) AS Expr22, 
tb_app.NM_DEBIT_BANK, 
tb_app.NR_DEBIT_ACCOUNT, 
dbo.MCODETONAME('paymenttype', tb_app.DE_PMT_PARCEL) AS Expr23,  
tb_app.NM_DEBIT_BANK AS Expr16, 
tb_app.NR_DEBIT_ACCOUNT AS Expr17, 
'' AS Expr18, 
tb_app.DT_INTRODUCTION, 
tb_app.DT_POLICY_ACTIVATION,                       
tb_app_co.DT_CONTRACTING, 
'' AS Expr19, 
tb_app.DT_RECEIVING_APPLICATION, 
'' AS Expr20, 
tb_app.DT_CANCELLING, 
tb_app.DT_REACTIVATION,                       
tb_g.DT_DATATIME AS Expr21, 
tb_g.ENCRYPT_FLAG, 
MONTH(tb_g.DT_BIRTH) AS month, 
DAY(tb_g.DT_BIRTH) AS day 
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_GROUP_NUMBER_Encrypt AS tb_g ON tb_app.CD_ADMINISTRATOR = tb_g.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_g.CD_BRANCH AND tb_app.CD_ADMINISTRATOR_GROUP_NUMBER = tb_g.CD_GROUP_NUMBER AND tb_g.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
INNER JOIN  dbo.TB_COVERAGE AS tb_co ON tb_co.CD_COVERAGE = tb_app_co.CD_COVERAGE 
WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2005' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
AND tb_co.FL_BASIC = 'Y' AND tb_co.nm_coverage_reduced<>'DE0001'
)oldtable
set @iRecordCount_LCCont2005=@@rowcount 
insert into PolFlushLog values('MAP_LCcont_old-2005','innet',@iRecordCount_LCCont2005,getdate())


--pol2013
declare @iRecordCount_LCPol2013 int 

insert into MAP_LCPOL_V select * from (  SELECT     tb_cov.FL_BASIC, tb_app.CD_PREPRINTED_APPLICATION, tb_app.CD_POLICY_COMPLEMENT,                           (SELECT     c.NM_COVERAGE                             FROM          dbo.TB_APPLICATION AS a INNER JOIN                                                    dbo.TB_APPLICATION_COVERAGE AS b ON b.CD_ADMINISTRATOR = a.CD_ADMINISTRATOR AND b.CD_BRANCH = a.CD_BRANCH AND                                                     b.CD_PRODUCT = a.CD_PRODUCT AND b.CD_APPLICATION = a.CD_APPLICATION 
INNER JOIN  dbo.TB_COVERAGE AS c ON c.CD_ADMINISTRATOR = b.CD_ADMINISTRATOR AND c.CD_COVERAGE = b.CD_COVERAGE                             WHERE      (c.NM_COVERAGE_REDUCED <> 'DE0001') AND (a.CD_POLICY_COMPLEMENT = tb_app.CD_POLICY_COMPLEMENT) AND (c.FL_BASIC = 'Y') AND                                                     (a.UNIQUE_CD = tb_app.UNIQUE_CD)) AS Expr1, CAST(tb_p.CD_PARTICIPANT AS nvarchar) AS Expr9, tb_cov.NM_COVERAGE_REDUCED,                        tb_cov.NM_COVERAGE, tb_app_co.DT_CONTRACTING, CASE WHEN (tb_app_co.de_type_year_contracting = 'Y' OR                       tb_app_co.de_type_year_contracting = '年') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr2,                        CASE WHEN (tb_app_co.de_type_year_contracting = 'A' OR                       tb_app_co.de_type_year_contracting = '年龄') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr3,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'Y' OR                       tb_app_co.de_type_validity_coverage = '年') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr4,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'A' OR                       tb_app_co.de_type_validity_coverage = '年龄') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr5, CASE WHEN tb_app_co.de_status IS NULL                        THEN '1' ELSE tb_app_co.de_status END AS Expr6, CASE WHEN vl_benefit > 12 THEN vl_benefit ELSE NULL END AS Expr7,                        CASE WHEN vl_benefit <= 12 THEN vl_benefit ELSE NULL END AS Expr8, la.AGENTCODE  
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_PARTICIPANT_Encrypt AS tb_p ON tb_app.CD_PARTICIPANT = tb_p.CD_PARTICIPANT AND tb_app.CD_ADMINISTRATOR = tb_p.CD_ADMINISTRATOR AND                        tb_app.CD_BRANCH = tb_p.CD_BRANCH AND tb_p.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND                        tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND                        tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_COVERAGE AS tb_cov ON tb_cov.CD_ADMINISTRATOR = tb_app_co.CD_ADMINISTRATOR AND tb_cov.CD_COVERAGE = tb_app_co.CD_COVERAGE 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND                        tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
 WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2013' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
and (tb_cov.NM_COVERAGE_REDUCED <> 'DE0001') 
--AND ((tb_app.CD_POLICY_COMPLEMENT + tb_cov.NM_COVERAGE_REDUCED)
 --NOT IN (SELECT     dbo.ContNoMAPPing(CONTNO) + RISKCODE AS Expr1 FROM   dbo.MAP_LCPOL AS MAP_LCPOL_1))
) oldtable

set @iRecordCount_LCPol2013=@@rowcount 
insert into PolFlushLog values('MAP_Lcpol_old-2013','innet',@iRecordCount_LCPol2013,getdate())

--pol2012
declare @iRecordCount_LCPol2012 int 

insert into MAP_LCPOL_V select * from (  SELECT     tb_cov.FL_BASIC, tb_app.CD_PREPRINTED_APPLICATION, tb_app.CD_POLICY_COMPLEMENT,                           (SELECT     c.NM_COVERAGE                             FROM          dbo.TB_APPLICATION AS a INNER JOIN                                                    dbo.TB_APPLICATION_COVERAGE AS b ON b.CD_ADMINISTRATOR = a.CD_ADMINISTRATOR AND b.CD_BRANCH = a.CD_BRANCH AND                                                     b.CD_PRODUCT = a.CD_PRODUCT AND b.CD_APPLICATION = a.CD_APPLICATION 
INNER JOIN  dbo.TB_COVERAGE AS c ON c.CD_ADMINISTRATOR = b.CD_ADMINISTRATOR AND c.CD_COVERAGE = b.CD_COVERAGE                             WHERE      (c.NM_COVERAGE_REDUCED <> 'DE0001') AND (a.CD_POLICY_COMPLEMENT = tb_app.CD_POLICY_COMPLEMENT) AND (c.FL_BASIC = 'Y') AND                                                     (a.UNIQUE_CD = tb_app.UNIQUE_CD)) AS Expr1, CAST(tb_p.CD_PARTICIPANT AS nvarchar) AS Expr9, tb_cov.NM_COVERAGE_REDUCED,                        tb_cov.NM_COVERAGE, tb_app_co.DT_CONTRACTING, CASE WHEN (tb_app_co.de_type_year_contracting = 'Y' OR                       tb_app_co.de_type_year_contracting = '年') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr2,                        CASE WHEN (tb_app_co.de_type_year_contracting = 'A' OR                       tb_app_co.de_type_year_contracting = '年龄') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr3,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'Y' OR                       tb_app_co.de_type_validity_coverage = '年') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr4,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'A' OR                       tb_app_co.de_type_validity_coverage = '年龄') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr5, CASE WHEN tb_app_co.de_status IS NULL                        THEN '1' ELSE tb_app_co.de_status END AS Expr6, CASE WHEN vl_benefit > 12 THEN vl_benefit ELSE NULL END AS Expr7,                        CASE WHEN vl_benefit <= 12 THEN vl_benefit ELSE NULL END AS Expr8, la.AGENTCODE  
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_PARTICIPANT_Encrypt AS tb_p ON tb_app.CD_PARTICIPANT = tb_p.CD_PARTICIPANT AND tb_app.CD_ADMINISTRATOR = tb_p.CD_ADMINISTRATOR AND                        tb_app.CD_BRANCH = tb_p.CD_BRANCH AND tb_p.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND                        tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND                        tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_COVERAGE AS tb_cov ON tb_cov.CD_ADMINISTRATOR = tb_app_co.CD_ADMINISTRATOR AND tb_cov.CD_COVERAGE = tb_app_co.CD_COVERAGE 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND                        tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
 WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2012' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
and (tb_cov.NM_COVERAGE_REDUCED <> 'DE0001') 
--AND ((tb_app.CD_POLICY_COMPLEMENT + tb_cov.NM_COVERAGE_REDUCED)
 --NOT IN (SELECT     dbo.ContNoMAPPing(CONTNO) + RISKCODE AS Expr1 FROM   dbo.MAP_LCPOL AS MAP_LCPOL_1))
) oldtable

set @iRecordCount_LCPol2012=@@rowcount 
insert into PolFlushLog values('MAP_Lcpol_old-2012','innet',@iRecordCount_LCPol2012,getdate())

--pol2011
declare @iRecordCount_LCPol2011 int 

insert into MAP_LCPOL_V select * from (  SELECT     tb_cov.FL_BASIC, tb_app.CD_PREPRINTED_APPLICATION, tb_app.CD_POLICY_COMPLEMENT,                           (SELECT     c.NM_COVERAGE                             FROM          dbo.TB_APPLICATION AS a INNER JOIN                                                    dbo.TB_APPLICATION_COVERAGE AS b ON b.CD_ADMINISTRATOR = a.CD_ADMINISTRATOR AND b.CD_BRANCH = a.CD_BRANCH AND                                                     b.CD_PRODUCT = a.CD_PRODUCT AND b.CD_APPLICATION = a.CD_APPLICATION 
INNER JOIN  dbo.TB_COVERAGE AS c ON c.CD_ADMINISTRATOR = b.CD_ADMINISTRATOR AND c.CD_COVERAGE = b.CD_COVERAGE                             WHERE      (c.NM_COVERAGE_REDUCED <> 'DE0001') AND (a.CD_POLICY_COMPLEMENT = tb_app.CD_POLICY_COMPLEMENT) AND (c.FL_BASIC = 'Y') AND                                                     (a.UNIQUE_CD = tb_app.UNIQUE_CD)) AS Expr1, CAST(tb_p.CD_PARTICIPANT AS nvarchar) AS Expr9, tb_cov.NM_COVERAGE_REDUCED,                        tb_cov.NM_COVERAGE, tb_app_co.DT_CONTRACTING, CASE WHEN (tb_app_co.de_type_year_contracting = 'Y' OR                       tb_app_co.de_type_year_contracting = '年') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr2,                        CASE WHEN (tb_app_co.de_type_year_contracting = 'A' OR                       tb_app_co.de_type_year_contracting = '年龄') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr3,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'Y' OR                       tb_app_co.de_type_validity_coverage = '年') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr4,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'A' OR                       tb_app_co.de_type_validity_coverage = '年龄') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr5, CASE WHEN tb_app_co.de_status IS NULL                        THEN '1' ELSE tb_app_co.de_status END AS Expr6, CASE WHEN vl_benefit > 12 THEN vl_benefit ELSE NULL END AS Expr7,                        CASE WHEN vl_benefit <= 12 THEN vl_benefit ELSE NULL END AS Expr8, la.AGENTCODE  
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_PARTICIPANT_Encrypt AS tb_p ON tb_app.CD_PARTICIPANT = tb_p.CD_PARTICIPANT AND tb_app.CD_ADMINISTRATOR = tb_p.CD_ADMINISTRATOR AND                        tb_app.CD_BRANCH = tb_p.CD_BRANCH AND tb_p.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND                        tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND                        tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_COVERAGE AS tb_cov ON tb_cov.CD_ADMINISTRATOR = tb_app_co.CD_ADMINISTRATOR AND tb_cov.CD_COVERAGE = tb_app_co.CD_COVERAGE 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND                        tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
 WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2011' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
and (tb_cov.NM_COVERAGE_REDUCED <> 'DE0001') 
--AND ((tb_app.CD_POLICY_COMPLEMENT + tb_cov.NM_COVERAGE_REDUCED)
 --NOT IN (SELECT     dbo.ContNoMAPPing(CONTNO) + RISKCODE AS Expr1 FROM   dbo.MAP_LCPOL AS MAP_LCPOL_1))
) oldtable

set @iRecordCount_LCPol2011=@@rowcount 
insert into PolFlushLog values('MAP_Lcpol_old-2011','innet',@iRecordCount_LCPol2011,getdate())

--pol2010
declare @iRecordCount_LCPol2010 int 

insert into MAP_LCPOL_V select * from (  SELECT     tb_cov.FL_BASIC, tb_app.CD_PREPRINTED_APPLICATION, tb_app.CD_POLICY_COMPLEMENT,                           (SELECT     c.NM_COVERAGE                             FROM          dbo.TB_APPLICATION AS a INNER JOIN                                                    dbo.TB_APPLICATION_COVERAGE AS b ON b.CD_ADMINISTRATOR = a.CD_ADMINISTRATOR AND b.CD_BRANCH = a.CD_BRANCH AND                                                     b.CD_PRODUCT = a.CD_PRODUCT AND b.CD_APPLICATION = a.CD_APPLICATION 
INNER JOIN  dbo.TB_COVERAGE AS c ON c.CD_ADMINISTRATOR = b.CD_ADMINISTRATOR AND c.CD_COVERAGE = b.CD_COVERAGE                             WHERE      (c.NM_COVERAGE_REDUCED <> 'DE0001') AND (a.CD_POLICY_COMPLEMENT = tb_app.CD_POLICY_COMPLEMENT) AND (c.FL_BASIC = 'Y') AND                                                     (a.UNIQUE_CD = tb_app.UNIQUE_CD)) AS Expr1, CAST(tb_p.CD_PARTICIPANT AS nvarchar) AS Expr9, tb_cov.NM_COVERAGE_REDUCED,                        tb_cov.NM_COVERAGE, tb_app_co.DT_CONTRACTING, CASE WHEN (tb_app_co.de_type_year_contracting = 'Y' OR                       tb_app_co.de_type_year_contracting = '年') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr2,                        CASE WHEN (tb_app_co.de_type_year_contracting = 'A' OR                       tb_app_co.de_type_year_contracting = '年龄') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr3,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'Y' OR                       tb_app_co.de_type_validity_coverage = '年') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr4,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'A' OR                       tb_app_co.de_type_validity_coverage = '年龄') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr5, CASE WHEN tb_app_co.de_status IS NULL                        THEN '1' ELSE tb_app_co.de_status END AS Expr6, CASE WHEN vl_benefit > 12 THEN vl_benefit ELSE NULL END AS Expr7,                        CASE WHEN vl_benefit <= 12 THEN vl_benefit ELSE NULL END AS Expr8, la.AGENTCODE  
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_PARTICIPANT_Encrypt AS tb_p ON tb_app.CD_PARTICIPANT = tb_p.CD_PARTICIPANT AND tb_app.CD_ADMINISTRATOR = tb_p.CD_ADMINISTRATOR AND                        tb_app.CD_BRANCH = tb_p.CD_BRANCH AND tb_p.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND                        tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND                        tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_COVERAGE AS tb_cov ON tb_cov.CD_ADMINISTRATOR = tb_app_co.CD_ADMINISTRATOR AND tb_cov.CD_COVERAGE = tb_app_co.CD_COVERAGE 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND                        tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
 WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2010' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
and (tb_cov.NM_COVERAGE_REDUCED <> 'DE0001') 
--AND ((tb_app.CD_POLICY_COMPLEMENT + tb_cov.NM_COVERAGE_REDUCED)
 --NOT IN (SELECT     dbo.ContNoMAPPing(CONTNO) + RISKCODE AS Expr1 FROM   dbo.MAP_LCPOL AS MAP_LCPOL_1))
) oldtable

set @iRecordCount_LCPol2010=@@rowcount 
insert into PolFlushLog values('MAP_Lcpol_old-2010','innet',@iRecordCount_LCPol2010,getdate())

--pol2009
declare @iRecordCount_LCPol2009 int 

insert into MAP_LCPOL_V select * from (  SELECT     tb_cov.FL_BASIC, tb_app.CD_PREPRINTED_APPLICATION, tb_app.CD_POLICY_COMPLEMENT,                           (SELECT     c.NM_COVERAGE                             FROM          dbo.TB_APPLICATION AS a INNER JOIN                                                    dbo.TB_APPLICATION_COVERAGE AS b ON b.CD_ADMINISTRATOR = a.CD_ADMINISTRATOR AND b.CD_BRANCH = a.CD_BRANCH AND                                                     b.CD_PRODUCT = a.CD_PRODUCT AND b.CD_APPLICATION = a.CD_APPLICATION 
INNER JOIN  dbo.TB_COVERAGE AS c ON c.CD_ADMINISTRATOR = b.CD_ADMINISTRATOR AND c.CD_COVERAGE = b.CD_COVERAGE                             WHERE      (c.NM_COVERAGE_REDUCED <> 'DE0001') AND (a.CD_POLICY_COMPLEMENT = tb_app.CD_POLICY_COMPLEMENT) AND (c.FL_BASIC = 'Y') AND                                                     (a.UNIQUE_CD = tb_app.UNIQUE_CD)) AS Expr1, CAST(tb_p.CD_PARTICIPANT AS nvarchar) AS Expr9, tb_cov.NM_COVERAGE_REDUCED,                        tb_cov.NM_COVERAGE, tb_app_co.DT_CONTRACTING, CASE WHEN (tb_app_co.de_type_year_contracting = 'Y' OR                       tb_app_co.de_type_year_contracting = '年') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr2,                        CASE WHEN (tb_app_co.de_type_year_contracting = 'A' OR                       tb_app_co.de_type_year_contracting = '年龄') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr3,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'Y' OR                       tb_app_co.de_type_validity_coverage = '年') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr4,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'A' OR                       tb_app_co.de_type_validity_coverage = '年龄') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr5, CASE WHEN tb_app_co.de_status IS NULL                        THEN '1' ELSE tb_app_co.de_status END AS Expr6, CASE WHEN vl_benefit > 12 THEN vl_benefit ELSE NULL END AS Expr7,                        CASE WHEN vl_benefit <= 12 THEN vl_benefit ELSE NULL END AS Expr8, la.AGENTCODE  
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_PARTICIPANT_Encrypt AS tb_p ON tb_app.CD_PARTICIPANT = tb_p.CD_PARTICIPANT AND tb_app.CD_ADMINISTRATOR = tb_p.CD_ADMINISTRATOR AND                        tb_app.CD_BRANCH = tb_p.CD_BRANCH AND tb_p.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND                        tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND                        tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_COVERAGE AS tb_cov ON tb_cov.CD_ADMINISTRATOR = tb_app_co.CD_ADMINISTRATOR AND tb_cov.CD_COVERAGE = tb_app_co.CD_COVERAGE 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND                        tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
 WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2009' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
and (tb_cov.NM_COVERAGE_REDUCED <> 'DE0001') 
--AND ((tb_app.CD_POLICY_COMPLEMENT + tb_cov.NM_COVERAGE_REDUCED)
 --NOT IN (SELECT     dbo.ContNoMAPPing(CONTNO) + RISKCODE AS Expr1 FROM   dbo.MAP_LCPOL AS MAP_LCPOL_1))
) oldtable

set @iRecordCount_LCPol2009=@@rowcount 
insert into PolFlushLog values('MAP_Lcpol_old-2009','innet',@iRecordCount_LCPol2009,getdate())

--pol2008
declare @iRecordCount_LCPol2008 int 

insert into MAP_LCPOL_V select * from (  SELECT     tb_cov.FL_BASIC, tb_app.CD_PREPRINTED_APPLICATION, tb_app.CD_POLICY_COMPLEMENT,                           (SELECT     c.NM_COVERAGE                             FROM          dbo.TB_APPLICATION AS a INNER JOIN                                                    dbo.TB_APPLICATION_COVERAGE AS b ON b.CD_ADMINISTRATOR = a.CD_ADMINISTRATOR AND b.CD_BRANCH = a.CD_BRANCH AND                                                     b.CD_PRODUCT = a.CD_PRODUCT AND b.CD_APPLICATION = a.CD_APPLICATION 
INNER JOIN  dbo.TB_COVERAGE AS c ON c.CD_ADMINISTRATOR = b.CD_ADMINISTRATOR AND c.CD_COVERAGE = b.CD_COVERAGE                             WHERE      (c.NM_COVERAGE_REDUCED <> 'DE0001') AND (a.CD_POLICY_COMPLEMENT = tb_app.CD_POLICY_COMPLEMENT) AND (c.FL_BASIC = 'Y') AND                                                     (a.UNIQUE_CD = tb_app.UNIQUE_CD)) AS Expr1, CAST(tb_p.CD_PARTICIPANT AS nvarchar) AS Expr9, tb_cov.NM_COVERAGE_REDUCED,                        tb_cov.NM_COVERAGE, tb_app_co.DT_CONTRACTING, CASE WHEN (tb_app_co.de_type_year_contracting = 'Y' OR                       tb_app_co.de_type_year_contracting = '年') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr2,                        CASE WHEN (tb_app_co.de_type_year_contracting = 'A' OR                       tb_app_co.de_type_year_contracting = '年龄') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr3,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'Y' OR                       tb_app_co.de_type_validity_coverage = '年') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr4,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'A' OR                       tb_app_co.de_type_validity_coverage = '年龄') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr5, CASE WHEN tb_app_co.de_status IS NULL                        THEN '1' ELSE tb_app_co.de_status END AS Expr6, CASE WHEN vl_benefit > 12 THEN vl_benefit ELSE NULL END AS Expr7,                        CASE WHEN vl_benefit <= 12 THEN vl_benefit ELSE NULL END AS Expr8, la.AGENTCODE  
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_PARTICIPANT_Encrypt AS tb_p ON tb_app.CD_PARTICIPANT = tb_p.CD_PARTICIPANT AND tb_app.CD_ADMINISTRATOR = tb_p.CD_ADMINISTRATOR AND                        tb_app.CD_BRANCH = tb_p.CD_BRANCH AND tb_p.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND                        tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND                        tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_COVERAGE AS tb_cov ON tb_cov.CD_ADMINISTRATOR = tb_app_co.CD_ADMINISTRATOR AND tb_cov.CD_COVERAGE = tb_app_co.CD_COVERAGE 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND                        tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
 WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2008' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
and (tb_cov.NM_COVERAGE_REDUCED <> 'DE0001') 
--AND ((tb_app.CD_POLICY_COMPLEMENT + tb_cov.NM_COVERAGE_REDUCED)
 --NOT IN (SELECT     dbo.ContNoMAPPing(CONTNO) + RISKCODE AS Expr1 FROM   dbo.MAP_LCPOL AS MAP_LCPOL_1))
) oldtable

set @iRecordCount_LCPol2008=@@rowcount 
insert into PolFlushLog values('MAP_Lcpol_old-2008','innet',@iRecordCount_LCPol2008,getdate())

--pol2007
declare @iRecordCount_LCPol2007 int 

insert into MAP_LCPOL_V select * from (  SELECT     tb_cov.FL_BASIC, tb_app.CD_PREPRINTED_APPLICATION, tb_app.CD_POLICY_COMPLEMENT,                           (SELECT     c.NM_COVERAGE                             FROM          dbo.TB_APPLICATION AS a INNER JOIN                                                    dbo.TB_APPLICATION_COVERAGE AS b ON b.CD_ADMINISTRATOR = a.CD_ADMINISTRATOR AND b.CD_BRANCH = a.CD_BRANCH AND                                                     b.CD_PRODUCT = a.CD_PRODUCT AND b.CD_APPLICATION = a.CD_APPLICATION 
INNER JOIN  dbo.TB_COVERAGE AS c ON c.CD_ADMINISTRATOR = b.CD_ADMINISTRATOR AND c.CD_COVERAGE = b.CD_COVERAGE                             WHERE      (c.NM_COVERAGE_REDUCED <> 'DE0001') AND (a.CD_POLICY_COMPLEMENT = tb_app.CD_POLICY_COMPLEMENT) AND (c.FL_BASIC = 'Y') AND                                                     (a.UNIQUE_CD = tb_app.UNIQUE_CD)) AS Expr1, CAST(tb_p.CD_PARTICIPANT AS nvarchar) AS Expr9, tb_cov.NM_COVERAGE_REDUCED,                        tb_cov.NM_COVERAGE, tb_app_co.DT_CONTRACTING, CASE WHEN (tb_app_co.de_type_year_contracting = 'Y' OR                       tb_app_co.de_type_year_contracting = '年') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr2,                        CASE WHEN (tb_app_co.de_type_year_contracting = 'A' OR                       tb_app_co.de_type_year_contracting = '年龄') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr3,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'Y' OR                       tb_app_co.de_type_validity_coverage = '年') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr4,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'A' OR                       tb_app_co.de_type_validity_coverage = '年龄') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr5, CASE WHEN tb_app_co.de_status IS NULL                        THEN '1' ELSE tb_app_co.de_status END AS Expr6, CASE WHEN vl_benefit > 12 THEN vl_benefit ELSE NULL END AS Expr7,                        CASE WHEN vl_benefit <= 12 THEN vl_benefit ELSE NULL END AS Expr8, la.AGENTCODE  
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_PARTICIPANT_Encrypt AS tb_p ON tb_app.CD_PARTICIPANT = tb_p.CD_PARTICIPANT AND tb_app.CD_ADMINISTRATOR = tb_p.CD_ADMINISTRATOR AND                        tb_app.CD_BRANCH = tb_p.CD_BRANCH AND tb_p.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND                        tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND                        tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_COVERAGE AS tb_cov ON tb_cov.CD_ADMINISTRATOR = tb_app_co.CD_ADMINISTRATOR AND tb_cov.CD_COVERAGE = tb_app_co.CD_COVERAGE 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND                        tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
 WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2007' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
and (tb_cov.NM_COVERAGE_REDUCED <> 'DE0001') 
--AND ((tb_app.CD_POLICY_COMPLEMENT + tb_cov.NM_COVERAGE_REDUCED)
 --NOT IN (SELECT     dbo.ContNoMAPPing(CONTNO) + RISKCODE AS Expr1 FROM   dbo.MAP_LCPOL AS MAP_LCPOL_1))
) oldtable

set @iRecordCount_LCPol2007=@@rowcount 
insert into PolFlushLog values('MAP_Lcpol_old-2007','innet',@iRecordCount_LCPol2007,getdate())

--pol2006
declare @iRecordCount_LCPol2006 int 

insert into MAP_LCPOL_V select * from (  SELECT     tb_cov.FL_BASIC, tb_app.CD_PREPRINTED_APPLICATION, tb_app.CD_POLICY_COMPLEMENT,                           (SELECT     c.NM_COVERAGE                             FROM          dbo.TB_APPLICATION AS a INNER JOIN                                                    dbo.TB_APPLICATION_COVERAGE AS b ON b.CD_ADMINISTRATOR = a.CD_ADMINISTRATOR AND b.CD_BRANCH = a.CD_BRANCH AND                                                     b.CD_PRODUCT = a.CD_PRODUCT AND b.CD_APPLICATION = a.CD_APPLICATION 
INNER JOIN  dbo.TB_COVERAGE AS c ON c.CD_ADMINISTRATOR = b.CD_ADMINISTRATOR AND c.CD_COVERAGE = b.CD_COVERAGE                             WHERE      (c.NM_COVERAGE_REDUCED <> 'DE0001') AND (a.CD_POLICY_COMPLEMENT = tb_app.CD_POLICY_COMPLEMENT) AND (c.FL_BASIC = 'Y') AND                                                     (a.UNIQUE_CD = tb_app.UNIQUE_CD)) AS Expr1, CAST(tb_p.CD_PARTICIPANT AS nvarchar) AS Expr9, tb_cov.NM_COVERAGE_REDUCED,                        tb_cov.NM_COVERAGE, tb_app_co.DT_CONTRACTING, CASE WHEN (tb_app_co.de_type_year_contracting = 'Y' OR                       tb_app_co.de_type_year_contracting = '年') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr2,                        CASE WHEN (tb_app_co.de_type_year_contracting = 'A' OR                       tb_app_co.de_type_year_contracting = '年龄') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr3,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'Y' OR                       tb_app_co.de_type_validity_coverage = '年') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr4,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'A' OR                       tb_app_co.de_type_validity_coverage = '年龄') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr5, CASE WHEN tb_app_co.de_status IS NULL                        THEN '1' ELSE tb_app_co.de_status END AS Expr6, CASE WHEN vl_benefit > 12 THEN vl_benefit ELSE NULL END AS Expr7,                        CASE WHEN vl_benefit <= 12 THEN vl_benefit ELSE NULL END AS Expr8, la.AGENTCODE  
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_PARTICIPANT_Encrypt AS tb_p ON tb_app.CD_PARTICIPANT = tb_p.CD_PARTICIPANT AND tb_app.CD_ADMINISTRATOR = tb_p.CD_ADMINISTRATOR AND                        tb_app.CD_BRANCH = tb_p.CD_BRANCH AND tb_p.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND                        tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND                        tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_COVERAGE AS tb_cov ON tb_cov.CD_ADMINISTRATOR = tb_app_co.CD_ADMINISTRATOR AND tb_cov.CD_COVERAGE = tb_app_co.CD_COVERAGE 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND                        tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
 WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2006' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
and (tb_cov.NM_COVERAGE_REDUCED <> 'DE0001') 
--AND ((tb_app.CD_POLICY_COMPLEMENT + tb_cov.NM_COVERAGE_REDUCED)
 --NOT IN (SELECT     dbo.ContNoMAPPing(CONTNO) + RISKCODE AS Expr1 FROM   dbo.MAP_LCPOL AS MAP_LCPOL_1))
) oldtable

set @iRecordCount_LCPol2006=@@rowcount 
insert into PolFlushLog values('MAP_Lcpol_old-2006','innet',@iRecordCount_LCPol2006,getdate())

--pol2005
declare @iRecordCount_LCPol2005 int 

insert into MAP_LCPOL_V select * from (  SELECT     tb_cov.FL_BASIC, tb_app.CD_PREPRINTED_APPLICATION, tb_app.CD_POLICY_COMPLEMENT,                           (SELECT     c.NM_COVERAGE                             FROM          dbo.TB_APPLICATION AS a INNER JOIN                                                    dbo.TB_APPLICATION_COVERAGE AS b ON b.CD_ADMINISTRATOR = a.CD_ADMINISTRATOR AND b.CD_BRANCH = a.CD_BRANCH AND                                                     b.CD_PRODUCT = a.CD_PRODUCT AND b.CD_APPLICATION = a.CD_APPLICATION 
INNER JOIN  dbo.TB_COVERAGE AS c ON c.CD_ADMINISTRATOR = b.CD_ADMINISTRATOR AND c.CD_COVERAGE = b.CD_COVERAGE                             WHERE      (c.NM_COVERAGE_REDUCED <> 'DE0001') AND (a.CD_POLICY_COMPLEMENT = tb_app.CD_POLICY_COMPLEMENT) AND (c.FL_BASIC = 'Y') AND                                                     (a.UNIQUE_CD = tb_app.UNIQUE_CD)) AS Expr1, CAST(tb_p.CD_PARTICIPANT AS nvarchar) AS Expr9, tb_cov.NM_COVERAGE_REDUCED,                        tb_cov.NM_COVERAGE, tb_app_co.DT_CONTRACTING, CASE WHEN (tb_app_co.de_type_year_contracting = 'Y' OR                       tb_app_co.de_type_year_contracting = '年') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr2,                        CASE WHEN (tb_app_co.de_type_year_contracting = 'A' OR                       tb_app_co.de_type_year_contracting = '年龄') THEN tb_app_co.nr_year_contracting ELSE NULL END AS Expr3,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'Y' OR                       tb_app_co.de_type_validity_coverage = '年') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr4,                        CASE WHEN (tb_app_co.de_type_validity_coverage = 'A' OR                       tb_app_co.de_type_validity_coverage = '年龄') THEN tb_app_co.nr_validity_coverage ELSE NULL END AS Expr5, CASE WHEN tb_app_co.de_status IS NULL                        THEN '1' ELSE tb_app_co.de_status END AS Expr6, CASE WHEN vl_benefit > 12 THEN vl_benefit ELSE NULL END AS Expr7,                        CASE WHEN vl_benefit <= 12 THEN vl_benefit ELSE NULL END AS Expr8, la.AGENTCODE  
FROM         dbo.TB_APPLICATION AS tb_app 
INNER JOIN dbo.TB_PARTICIPANT_Encrypt AS tb_p ON tb_app.CD_PARTICIPANT = tb_p.CD_PARTICIPANT AND tb_app.CD_ADMINISTRATOR = tb_p.CD_ADMINISTRATOR AND                        tb_app.CD_BRANCH = tb_p.CD_BRANCH AND tb_p.SRC_CD = tb_app.SRC_CD 
INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_co ON tb_app_co.CD_ADMINISTRATOR = tb_app.CD_ADMINISTRATOR AND                        tb_app_co.CD_BRANCH = tb_app.CD_BRANCH AND tb_app_co.CD_PRODUCT = tb_app.CD_PRODUCT AND                        tb_app_co.CD_APPLICATION = tb_app.CD_APPLICATION 
INNER JOIN dbo.TB_COVERAGE AS tb_cov ON tb_cov.CD_ADMINISTRATOR = tb_app_co.CD_ADMINISTRATOR AND tb_cov.CD_COVERAGE = tb_app_co.CD_COVERAGE 
INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND                        tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION 
INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE 
 WHERE     
(la.BRANCHTYPE = '1') 
and  substring(convert(char(25),tb_app.dt_createtime,0),8,4)='2005' and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
and (tb_cov.NM_COVERAGE_REDUCED <> 'DE0001') 
--AND ((tb_app.CD_POLICY_COMPLEMENT + tb_cov.NM_COVERAGE_REDUCED)
 --NOT IN (SELECT     dbo.ContNoMAPPing(CONTNO) + RISKCODE AS Expr1 FROM   dbo.MAP_LCPOL AS MAP_LCPOL_1)) 
) oldtable

set @iRecordCount_LCPol2005=@@rowcount
insert into PolFlushLog values('MAP_Lcpol_old-2005','innet',@iRecordCount_LCPol2005,getdate())
go

