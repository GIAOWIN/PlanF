CREATE FUNCTION [dbo].[ContNOBak]()
    RETURNS TABLE
as

return(select * from mcontno where mcontno.used='Y')

go

