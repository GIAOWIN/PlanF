



CREATE FUNCTION  [dbo].[ClientCountBe_Encrypt_forEZT](@CAGENTCODE VARCHAR(10),
                                           @TEMPBEGIN datetime,
                                           @TEMPEND datetime )
RETURNS NUMERIC(12,2)
------------------------------------------------------------------------
-- SQL UDF (Scalar)
-- 计算客户数
-- @author sinosoft
-- Create date:  2009-11-23
------------------------------------------------------------------------
as
BEGIN --7
declare @tpolno varchar(30);            --保单号

declare @count decimal(12,2) ;      --客户数累计
declare @num NUMERIC(12,2) ;--客户数

declare @tappntno varchar(100);            --身份证号
declare @tcvalidate datetime;               --投保日期
declare @ccvalidate datetime;               --投保日期(临时记忆变量)
declare @tnum integer ;        --判断180天内是否存在同一被保人同一险种的记录数
declare @tagentcode varchar(10);        --第一代理人
declare @tagentcode1 varchar(10);       --第二代理人
declare @tflag integer ;       --当前保单是否参与客户数统计的标志，1位参加统计，0为不参加统计

declare @mainpolno varchar(30); 
declare @riskcode varchar(30); 
declare @cvalidate varchar(30); 
declare @appntno varchar(30); 
declare @agentcode varchar(30); 
declare @agentcode1 varchar(30); 


declare @tanp varchar(100);            --身份证号

declare @anp varchar(100);            --身份证号

    set @ccvalidate=null;
    set @count=0.00;
    set @num=0.00;
    set @tnum=0;
    set @tflag=0;


    
	declare cur cursor for
      select sum(COMMCHARGE) anp,cvalidate,mainpolno,
       appntno ,
        agentcode,agentcode1 from lacommision where
        cvalidate<=@tempend and
        cvalidate>=@tempbegin and
        (agentcode=@cagentcode or agentcode1=@cagentcode)
        group by cvalidate,mainpolno,appntno, agentcode,agentcode1
        order by mainpolno,appntno,cvalidate
	open cur
      fetch next from cur into @anp,@cvalidate,@mainpolno,@appntno ,@agentcode,@agentcode1
	while(@@Fetch_Status=0 )
	begin--6

        set @tflag=0;
        
        
        set @tcvalidate = @cvalidate;
        set @tappntno = @appntno;
        set @tagentcode = @agentcode;
        set @tagentcode1 = @agentcode1;
        set @tanp = @anp;
        set @num=0.00;
        if @tanp > '1' 
         begin--5
              set @tflag =
              --select ( case when(select sum(COMMCHARGE) from lacommision la where la.appntno = @tappntno and cvalidate < @ccvalidate
              --and
              --  (agentcode=@cagentcode or agentcode1=@cagentcode)
              --)> 0 then 1 else 0 end )sumanp from sysvar where 1=1
         
         (select ( case when(select sum(COMMCHARGE) from lacommision la where la.appntno = @tappntno and cvalidate < @ccvalidate
              and
                (agentcode=@cagentcode or agentcode1=@cagentcode)
              )> 0 then 1 else 0 end )sumanp from msysvar where vartype='onerow')
              
              if @tflag=1 
                  begin --1
                  set @num = 0;
                  end
             else
                begin
                set @num = 1;
                end
              
              end
              
      set @count=@count+@num;
     fetch next from cur into  @anp,@cvalidate,@mainpolno,@appntno ,@agentcode,@agentcode1
     end --6
	--//关闭游标
	CLOSE cur;
	--//撤销游标
	DEALLOCATE cur;   
  return @count;
end--7

go

