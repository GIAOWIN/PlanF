--创建函数varbinary转varchar
create function BinToHexString(@Bin varbinary(500)) 
returns varchar(500) 
as
begin
  return '0x' + cast('' as xml).value('xs:hexBinary(sql:variable("@Bin") )', 'varchar(500)'); 
end
go

