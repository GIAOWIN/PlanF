

CREATE view [dbo].[LNPAppntTaxInfo_view] as
(
select lnt.ContNo,lnt.AppntId,lnt.AppntName,TaxCivilType,LastName,FirstName,BirthDate
,Country
,(select codename from lnpcode where codetype='provinceCity' and len(code)= '2' and lnpcode.code=lnt.Province) as Province
,(select codename from lnpcode where codetype='provinceCity' and len(code)= '4' and lnpcode.code=lnt.city) as City
, Address
,CountryEN
,(select comcode from lnpcode where codetype='provinceCity' and len(code)= '2' and lnpcode.code=lnt.ProvinceEN) as ProvinceEN
,(select comcode from lnpcode where codetype='provinceCity' and len(code)= '4' and lnpcode.code=lnt.cityEN) as CityEN
,AddressEN
,case NativeCountry when '-1' then 'NULL' else NativeCountry end as NativeCountry 
,case (select codename from lnpcode where codetype='provinceCity' and len(code)= '2' and lnpcode.code=lnt.NativeProvince) when '-1' then 'NULL' else (select codename from lnpcode where codetype='provinceCity' and len(code)= '2' and lnpcode.code=lnt.NativeProvince) end as NativeProvince 
,case (select codename from lnpcode where codetype='provinceCity' and len(code)= '4' and lnpcode.code=lnt.NativeCity) when '-1' then 'NULL' else (select codename from lnpcode where codetype='provinceCity' and len(code)= '4' and lnpcode.code=lnt.NativeCity) end as NativeCity
,NativeAddr
,case NativeContyEN when '-1' then 'NULL'  else NativeContyEN end as NativeContyEN
,case (select comcode from lnpcode where codetype='provinceCity' and len(code)= '2' and lnpcode.code=lnt.NativeProviEN) when '-1' then 'NULL' else (select comcode from lnpcode where codetype='provinceCity' and len(code)= '2' and lnpcode.code=lnt.NativeProviEN) end as NativeProviEN
,case (select comcode from lnpcode where codetype='provinceCity' and len(code)= '4' and lnpcode.code=lnt.NativeCityEN) when '-1' then 'NULL' else (select comcode from lnpcode where codetype='provinceCity' and len(code)= '4' and lnpcode.code=lnt.NativeCityEN) end as NativeCityEN
,NativeAddrEN
,case TaxRegion1 when '-1' then 'NULL' else TaxRegion1 end as TaxRegion1,TaxFileNo1
,case TaxRegion2 when '-1' then 'NULL' else TaxRegion2 end as TaxRegion2,TaxFileNo2
,case TaxRegion3 when '-1' then 'NULL' else TaxRegion3 end as TaxRegion3,TaxFileNo3
,NoTFNReason,FailGetTFN,lnt.MakeDate,lnt.MakeTime,lnt.ModifyDate,lnt.ModifyTime,Remark1,Remark2,Remark3,Remark4,Remark5
 from LNPAppntTaxInfo lnt , lnpcont lnpc where lnt.contno =lnpc.contno and lnpc.mainpolno is not null
)
go

