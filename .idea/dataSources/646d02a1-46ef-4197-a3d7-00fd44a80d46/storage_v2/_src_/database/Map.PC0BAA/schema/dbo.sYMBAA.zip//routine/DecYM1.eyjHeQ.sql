create function [dbo].[DecYM1](@CINDEXCALNO varchar(6),@TYPE varchar(1),@DECX INTEGER)
 returns varchar(6)
as

begin 
  declare @RETURNS varchar(6)
	set @RETURNS  = (
             select ( select convert(nvarchar(6),DateAdd(mm,@DECX,startdate),112) from lastatsegment  
where managecom ='8601' and stattype='1' and yearmonth=@CINDEXCALNO )
from msysvar where vartype='onerow'
          )
	return @RETURNS
end ;
go

