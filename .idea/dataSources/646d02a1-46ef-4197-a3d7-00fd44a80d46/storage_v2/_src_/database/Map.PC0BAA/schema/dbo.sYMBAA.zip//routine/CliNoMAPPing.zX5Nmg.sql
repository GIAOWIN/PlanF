CREATE FUNCTION [dbo].[CliNoMAPPing]( @CliNo VARCHAR(20))
    RETURNS VARCHAR(100)

as
begin 
declare @RETURNS varchar(50)
declare @RETURNS1 varchar(50)
	
	set @RETURNS1 = ( select OLDCLNTNUM from MAPPING_CLNTNO where CLNTNUM = @CliNo)

    if @RETURNS1 is not null 
		set @RETURNS = @RETURNS1
	else
		set @RETURNS = @CliNo
return @RETURNS
end
go

