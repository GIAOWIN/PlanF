CREATE FUNCTION [dbo].[NULLSWITCHTo0]( @cValue decimal(20,2))
    RETURNS VARCHAR(100)

as

begin 
declare @RETURNS varchar(50)
declare @RETURNS1 varchar(50)

      set @RETURNS1 = cast(@cValue as nvarchar)

        if @RETURNS1 is not null 
			set @RETURNS = @RETURNS1
		else
			
			set @RETURNS = '0'
return @RETURNS
end;
go

