--drop function [dbo].[ClientCountBe_Encrypt_temp]

CREATE FUNCTION  [dbo].[ClientCountBe_Encrypt_temp](@AHCode varchar(10),
                                           @BeginTime datetime,
                                           @EndTime datetime )
RETURNS int

as
begin 

	declare @agentcode varchar(30); 
	declare @mainpolno varchar(30); 
	declare @cvalidate varchar(30); 
	declare @appntno varchar(30); 
	declare @anp varchar(20); 
	declare @count int;
	declare @mainpolnoinner varchar(30); 
	declare @anpinner varchar(20); 
	declare @flag int;
	
	set @flag = 0;  
	declare cur cursor for
        select agentCode, mainpolno, cvalidate, appntno, sum(COMMCHARGE) as anp from lacommision
		where cvalidate <= @EndTime
		and cvalidate >= @BeginTime
		and substring(agentcode,0,5) = @AHCode
		group by agentcode, mainpolno, cvalidate, appntno
   	open cur
      fetch next from cur into @agentcode,@mainpolno, @cvalidate, @appntno ,@anp;
	while(@@Fetch_Status=0 )
	begin
		if (@anp > 0)
			begin
				declare curinner cursor for
					select mainpolno, sum(COMMCHARGE) from lacommision 
					where cvalidate < @cvalidate
					and appntno = @appntno
					group by mainpolno
				open curinner
				    fetch next from curinner into @mainpolnoinner,@anpinner;
				while(@@Fetch_Status=0)
				begin
					if(@anpinner >0 )
						begin
						set @flag = 1;
						break;
						end
					 fetch next from curinner into @mainpolnoinner,@anpinner;
				end
					--//关闭游标
	            CLOSE curinner;
	            --//撤销游标
	            DEALLOCATE curinner;
			 if(@flag = 0)
				begin
				
					set @count = @count + 1;
					set @flag = 0;
				end
			 
			end     
		fetch next from cur into @agentcode,@mainpolno,@cvalidate,@appntno ,@anp;
    end
	--//关闭游标
	CLOSE cur;
	--//撤销游标
	DEALLOCATE cur; 
	  
  return @count;
end--7


go

