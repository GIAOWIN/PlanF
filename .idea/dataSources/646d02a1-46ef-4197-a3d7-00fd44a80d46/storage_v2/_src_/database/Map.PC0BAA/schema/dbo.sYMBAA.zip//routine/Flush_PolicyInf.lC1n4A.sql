


CREATE PROCEDURE [dbo].[Flush_PolicyInf] 
AS
--共刷新11张表
--MAP_LCBNF_V
--MAP_LCCont_V
--MAP_LCINSURED_V
--MAP_LCPOL_V
--MAP_LJAPAY_V
--MAP_LJAPAYPERSON_V
--MAP_LJSPAY_V
--MAP_LLCLAIM_V
--MAP_LLCLAIMDETAIL_V
--MAP_LPEDORAPP_V
--MAP_LPEDORITEM_V


--申请权限后执行该方案
--MAPPING_CLNTNO_ALL ---start
IF NOT EXISTS (select 1 from MAPPING_CLNTNO_ALL)
insert into MAPPING_CLNTNO_ALL select * from MAPPING_CLNTNO;
--MAPPING_CLNTNO_ALL ---end

--MAPPING_CLNTNO ---start
truncate table MAPPING_CLNTNO;
declare @iRecordCount_CLNTNO int 
insert into MAPPING_CLNTNO select * from MAPPING_CLNTNO_ALL a where exists(select 1 from MAP_LCINSURED where INSUREDNO=a.CLNTNUM) or exists(select 1 from MAP_LCCONT where APPNTNO=a.CLNTNUM) or exists(select 1 from MAP_LCBNF where CUSTOMERNO=a.CLNTNUM)
 set @iRecordCount_CLNTNO=@@rowcount  
insert into PolFlushLog values('MAPPING_CLNTNO','insert',@iRecordCount_CLNTNO,getdate())
--MAPPING_CLNTNO ---end

----临时方案
----MAP_LCBANK ---start
--IF NOT EXISTS (select 1 from MAP_LCBANK where ETL_DATATIME='9999-12-31')
--insert into MAP_LCBANK select CLNTNUM,cast (DOB as nvarchar),OLDCLNTNUM,SECUITYNO,CLNTNAME,SEX,'9999-12-31' from MAPPING_CLNTNO;
----MAPPING_CLNTNO_ALL ---end
--
----MAPPING_CLNTNO ---start
--truncate table MAPPING_CLNTNO;
--insert into MAPPING_CLNTNO select BANKNAME,BRANCHCODE,BANKENGNAME,BRANCHNAME,BANKFULLNAME,BANKCODE from MAP_LCBANK a where ETL_DATATIME='9999-12-31' and exists(select 1 from MAP_LCINSURED where INSUREDNO=a.BRANCHCODE) or exists(select 1 from MAP_LCCONT where APPNTNO=a.BRANCHCODE) or exists(select 1 from MAP_LCBNF where CUSTOMERNO=a.BRANCHCODE)
----MAPPING_CLNTNO ---end

--MAP_LCBNF_V ---start
--delete from MAP_LCBNF_V
truncate table  MAP_LCBNF_V
declare @iRecordCount int 
insert into MAP_LCBNF_V select * from (SELECT     PRTNO, dbo.ContNoMAPPing(CONTNO) AS CONTNO, EXECUTECOM, MANAGECOM, SALECHNL, dbo.CliNoMAPPing(INSUREDNO) AS INSUREDNO, BNFTYPE, BNFNO,                       RELATIONTOINSURED, BNFLOT, dbo.CliNoMAPPing(CUSTOMERNO) AS CUSTOMERNO, NAME, SEX, CAST(BIRTHDAY AS nvarchar) AS BIRTHDAY, IDTYPE, IDNO,                       PHONE,ETL_DATATYPE FROM         dbo.MAP_LCBNF 
--2014-02-17 modify by zxq 屏蔽ESEG/ILIFE数据
--UNION all SELECT     tb_app.CD_PREPRINTED_APPLICATION, tb_app.CD_POLICY_COMPLEMENT, '' AS Expr1, '' AS Expr2, '' AS Expr3, cast(tb_app.CD_PARTICIPANT as nvarchar),                       tb_app_ben.DV_BENEFIT_TYPE, tb_app_ben.CD_BENEFICIARY, tb_app_ben.DE_RELATIONSHIP, tb_app_ben.PE_PARTICIPATION, cast(tb_app_ben.CUST_ID as nvarchar),                       tb_app_ben.NM_BENEFICIARY, CASE WHEN tb_app_ben.DE_SEX = 'F' THEN '1' WHEN tb_app_ben.DE_SEX = 'M' THEN '0' END AS Expr5,                       CAST(tb_app_ben.DT_BIRTH AS datetime) AS Expr6, tb_app_ben.DE_TYPE_DOCUMENT, tb_app_ben.NR_DOCUMENT, '' AS Expr4 FROM         dbo.TB_APPLICATION_BENEFICIARY AS tb_app_ben INNER JOIN                      dbo.TB_APPLICATION AS tb_app ON tb_app.CD_ADMINISTRATOR = tb_app_ben.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_app_ben.CD_BRANCH AND                       tb_app.CD_PRODUCT = tb_app_ben.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_app_ben.CD_APPLICATION WHERE     not exists (select 1 from dbo.MAP_LCBNF 
	--where (NAME + CAST(BIRTHDAY AS nvarchar) + IDNO)=(tb_app_ben.NM_BENEFICIARY + CAST(tb_app_ben.DT_BIRTH AS nvarchar) + tb_app_ben.NR_DOCUMENT)))a
--where dbo.ContNoMAPPing(CONTNO)=tb_app.CD_POLICY_COMPLEMENT and NAME=tb_app_ben.NM_BENEFICIARY)
--2014-02-17 end
)a
   set @iRecordCount=@@rowcount  

insert into PolFlushLog values('MAP_LCBNF_V','insert',@iRecordCount,getdate())
--MAP_LCBNF_V ---end

--MAP_LCINSURED_V ---start
truncate table  MAP_LCINSURED_V
declare @iRecordCount_LCINSURED int
insert into MAP_LCINSURED_V select distinct * from (SELECT     dbo.ContNoMAPPing(CONTNO) AS CONTNO, PRTNO, EXECUTECOM, MANAGECOM, SALECHNL, dbo.CliNoMAPPing(INSUREDNO) AS INSUREDNO, NAME, SEX,BIRTHDAY, IDTYPE, IDNO, CAST(AGE AS nvarchar) AS AGE, NATIVEPLACE, COUNTRY, ADDRESS1, ZIPCODE, PHONE, MARRIAGE, RELATIONTOAPPNT,OCCUPATIONCODE, OCCUPATIONNAME, BUSINESS, '' AS NM_EMPLOYER, '' AS NM_OFFICE_ADDRESS1, '' AS NR_PHONE, '' AS NM_EMAIL, COMPANY, MOBILEPHONE FROM         dbo.MAP_LCINSURED 
--2014-02-17 modify by zxq 屏蔽ESEG/ILIFE数据
--UNION all SELECT     tb_app.CD_POLICY_COMPLEMENT, tb_app.CD_PREPRINTED_APPLICATION, '' AS Expr1, la.MANAGECOM, la.BRANCHTYPE, cast(tb_p.CD_PARTICIPANT as nvarchar),tb_p.NM_PARTICIPANT, CASE WHEN tb_p.DE_SEX = 'Female' THEN '1' WHEN tb_p.DE_SEX = 'Male' THEN '0' END AS Expr6, tb_p.DT_BIRTH,tb_p.DE_TYPE_DOCUMENT, tb_p.NR_DOCUMENT, '' AS Expr2, tb_p.CD_NATIONALITY, tb_p.NM_COUNTRY, tb_p.NM_ADDRESS, tb_p.NR_ZIP_CODE,tb_p.NR_PHONE, tb_p.DE_MARITAL_STATUS, tb_p.RELATIONSHIP_WITH_OWNER, CAST(tb_p.CD_OCCUPATION AS nvarchar) AS Expr3, tb_p.NM_OCCUPATION,tb_p.NM_OCCUPATION AS Expr4, tb_p.NM_EMPLOYER, tb_p.NM_OFFICE_ADDRESS1, tb_p.NR_PHONE AS Expr5, tb_p.NM_EMAIL FROM         dbo.TB_APPLICATION AS tb_app INNER JOIN dbo.TB_PARTICIPANT_Encrypt AS tb_p ON tb_p.CD_PARTICIPANT = tb_app.CD_PARTICIPANT AND tb_app.CD_ADMINISTRATOR = tb_p.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_p.CD_BRANCH AND tb_p.SRC_CD = tb_app.SRC_CD INNER JOIN dbo.TB_APPLICATION_BROKER AS tb_a_b ON tb_app.CD_ADMINISTRATOR = tb_a_b.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_a_b.CD_BRANCH AND tb_app.CD_PRODUCT = tb_a_b.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_a_b.CD_APPLICATION INNER JOIN dbo.LAAGENT AS la ON '86' + RIGHT('0' + LTRIM(STR(tb_a_b.CD_BRANCH)), 2) + RIGHT('00000' + LTRIM(STR(tb_a_b.CD_BROKER)), 6) = la.AGENTCODE WHERE     (la.BRANCHTYPE = '1') AND not exists(select 1 from MAPPING_CLNTNO di left join MMAPPING_CLNTNO m on di.OLDCLNTNUM=m.CLNTNO where m.OLDCLNTNO=CAST(tb_p.NR_FEDERAL_ID AS nvarchar) or di.OLDCLNTNUM=CAST(tb_p.NR_FEDERAL_ID AS nvarchar)) and ((tb_a_b.src_cd = 'ILIFE' and tb_a_b.rec_type='S') or (tb_a_b.src_cd = 'ESEG') )
--2014-02-17 end
) oldtable
 set @iRecordCount_LCINSURED=@@rowcount  
insert into PolFlushLog values('MAP_LCINSURED_V','insert',@iRecordCount_LCINSURED,getdate())
--MAP_LCINSURED_V ---end


--MAP_LJAPAY_V ---start
--按照DI新核心推数的逻辑实收总表中只存储实收信息，所以CONFDATE不会为空（即建立视图时排除原tb_collection表中DT_EXPIRATION为空的数据）
truncate table  MAP_LJAPAY_V
declare @iRecordCount_LJAPAY int 

insert into MAP_LJAPAY_V 
select *  from (   
    --modify by dj SELECT dbo.ContNoMAPPing(ljs.CONTNO) AS CONTNO, GETMONEY, ljs.DUEDATE, CONFDATE, ljs.PAYMODE,
    SELECT dbo.ContNoMAPPing(c.CONTNO) AS CONTNO, GETMONEY, c.DUEDATE, CONFDATE, c.PAYMODE,   --modify by Doreen
    CAST(CANCELDATE AS nvarchar) AS CANCELDATE, 
    (select top 1 UPLOADTIME from MAP_LCRETURNFROMBANKDETAIL where contno=c.contno order by serialno desc, serno desc) AS transDate, 
    CASE WHEN c.PAYMODE = 'D' THEN (SELECT BANKNAME FROM MAP_LCBANK WHERE BANKCODE = c.BANKCODE AND BRANCHCODE = c.MANAGECOM) ELSE '' END AS transbank,                        
    CASE WHEN c.PAYMODE = 'D' THEN c.BANKACCNO ELSE '' END AS BANKACCNO, 
    (case when c.CONFDATE is null then
    	         (select FAILREASON 
    	            from (select top 1 * from MAP_LCRETURNFROMBANKDETAIL where CONTNO=ljs.CONTNO and BANKSUCCFLAG='R' order by UPLOADTIME desc) temp
    	           where temp.UPLOADTIME>(select max(CONFDATE) from MAP_LJAPAY where CONTNO=ljs.CONTNO)
                   and temp.UPLOADTIME<=(select max(DUEDATE) from MAP_LJSPAY where CONTNO=ljs.CONTNO)
               ) 
          else '' 
     end) AS transResult, 
    (case when c.CONFDATE is null then 
    						(select FAILREASONDESC from (select top 1 * from MAP_LCRETURNFROMBANKDETAIL where CONTNO=ljs.CONTNO and BANKSUCCFLAG='R' order by UPLOADTIME desc) temp
    							where temp.UPLOADTIME>(select max(CONFDATE) from MAP_LJAPAY where CONTNO=ljs.CONTNO)
    								and temp.UPLOADTIME<=(select max(DUEDATE) from MAP_LJSPAY where CONTNO=ljs.CONTNO)
    						)
    		  else '' 
     end) AS transFailReason,
    '' as account_bak 
    --<< modify by dj
    /*
    FROM MAP_LJSPAY ljs 
    left join MAP_LJAPAY c 
    */
    FROM MAP_LJAPAY c 
    left join MAP_LJSPAY ljs
    -->> modify by dj
      on ljs.CONTNO = c.CONTNO 
     and ljs.DUEDATE = c.DUEDATE
   --2014-02-17 modify by zxq 屏蔽ESEG/ILIFE数据
UNION ALL
     select dbo.ContNoMAPPing(a.CONTNO) AS CONTNO,summoney,DUEPAYDATE,paydate,'','','','','','','','' from 
    (SELECT     CONTNO,DUEPAYDATE,paydate,sum(ACTUMONEY) as summoney 
    FROM MAP_LJAPAYPERSON b where   datasource in ('ESEG','ILIFE')
     group by CONTNO,DUEPAYDATE ,paydate) a
    --UNION ALL  SELECT     dbo.ContNoMAPPing(CONTNO) AS CONTNO,sum(ACTUMONEY),DUEPAYDATE,PAYDATE,'',''  FROM  dbo.MAP_LJAPAYPERSON where datasource in ('ESEG','ILIFE') group by CONTNO,DUEPAYDATE 
) oldtable
 set @iRecordCount_LJAPAY=@@rowcount  
insert into PolFlushLog values('MAP_LJAPAY_V','insert',@iRecordCount_LJAPAY,getdate())
--MAP_LJAPAY_V ---end


--MAP_LJAPAYPERSON_V ---start	
truncate table  MAP_LJAPAYPERSON_V
declare @iRecordCount_LJAPAYPERSON int 
insert into MAP_LJAPAYPERSON_V select * from (  SELECT     dbo.ContNoMAPPing(CONTNO) AS CONTNO, RISKCODE, RISKNAME, ACTUMONEY, DUEPAYDATE, PAYDATE, DATASOURCE, ETL_DATATYPE  FROM         dbo.MAP_LJAPAYPERSON  
--2014-02-17 modify by zxq 屏蔽ESEG/ILIFE数据
--UNION ALL  SELECT     tb_app.CD_POLICY_COMPLEMENT, tb_co.NM_COVERAGE_REDUCED, tb_co.NM_COVERAGE, tb_co_c.VL_COVERAGE, c.DT_EXPIRATION, c.DT_PAYMENT  FROM         dbo.TB_APPLICATION AS tb_app INNER JOIN                       dbo.TB_APPLICATION_COVERAGE AS tb_app_c ON tb_app.CD_ADMINISTRATOR = tb_app_c.CD_ADMINISTRATOR AND                        tb_app.CD_BRANCH = tb_app_c.CD_BRANCH AND tb_app.CD_PRODUCT = tb_app_c.CD_PRODUCT AND                        tb_app.CD_APPLICATION = tb_app_c.CD_APPLICATION INNER JOIN                       dbo.TB_COLLECTION AS c ON tb_app.CD_POLICY = c.CD_POLICY AND tb_app.CD_ADMINISTRATOR = c.CD_ADMINISTRATOR AND                        tb_app.CD_BRANCH = c.CD_BRANCH AND tb_app.CD_LINE_BUSINESS = c.CD_LINE_BUSINESS INNER JOIN                       dbo.TB_COLLECTION_COVERAGE AS tb_co_c ON c.CD_ADMINISTRATOR = tb_co_c.CD_ADMINISTRATOR AND c.CD_BRANCH = tb_co_c.CD_BRANCH AND                        c.CD_POLICY = tb_co_c.CD_POLICY AND c.NR_ENDORSEMENT = tb_co_c.NR_ENDORSEMENT AND tb_co_c.CD_COVERAGE = tb_app_c.CD_COVERAGE INNER JOIN                       dbo.TB_COVERAGE AS tb_co ON tb_co.CD_COVERAGE = tb_app_c.CD_COVERAGE where c.DT_PAYMENT is not null and c.DT_PAYMENT<>''
--2014-02-17 end
) oldtable
 set @iRecordCount_LJAPAYPERSON=@@rowcount  
insert into PolFlushLog values('MAP_LJAPAYPERSON_V','insert',@iRecordCount_LJAPAYPERSON,getdate())
--MAP_LJAPAYPERSON_V ---end

--MAP_LJSPAY_V ---startvvvv
truncate table  MAP_LJSPAY_V
declare @iRecordCount_LJSPAY int 
insert into MAP_LJSPAY_V select * from ( 
SELECT    dbo.ContNoMAPPing(CONTNO) AS CONTNO, DUEMONEY, DUEDATE, PAYMODE,Account_back,CONVERT(DATETIME,CONVERT(VARCHAR(10),INSTFROM)) AS INSTFROM 
FROM dbo.MAP_LJSPAY 
--2014-02-17 modify by zxq 屏蔽ESEG/ILIFE数据 
--UNION ALL  
--SELECT     tb_app.CD_POLICY_COMPLEMENT, tb_co.VL_PARCEL, tb_co.DT_EXPIRATION,
--dbo.MCODETONAME('paymenttype', tb_co.de_type_payment) TBPAYMODE  
--FROM         dbo.TB_APPLICATION AS tb_app INNER JOIN                       
--dbo.TB_COLLECTION AS tb_co ON tb_app.CD_POLICY = tb_co.CD_POLICY 
--AND tb_app.CD_ADMINISTRATOR = tb_co.CD_ADMINISTRATOR 
--AND tb_app.CD_BRANCH = tb_co.CD_BRANCH AND tb_app.CD_LINE_BUSINESS = tb_co.CD_LINE_BUSINESS 
--where tb_co.DT_CANCELLING is null and tb_co.vl_parcel>0 and tb_co.DE_COLLECTION_TYPE='Planned'
-- and not exists (select 1 AS CONTNO from dbo.MAP_LJSPAY where 
--tb_app.CD_POLICY_COMPLEMENT=dbo.ContNoMAPPing(CONTNO) and tb_co.DT_EXPIRATION=DUEDATE) 
--2014-02-17 end
) oldtable
 set @iRecordCount_LJSPAY=@@rowcount  
insert into PolFlushLog values('MAP_LJSPAY_V','insert',@iRecordCount_LJSPAY,getdate())
--MAP_LJSPAY_V ---end

--MAP_LLCLAIM_V ---start
truncate table  MAP_LLCLAIM_V
declare @iRecordCount_LLCLAIM int 
insert into MAP_LLCLAIM_V select * from (  SELECT     MANAGECOM, SALECHNL, REPORTTIME, REPORTDES, REPORTNO, dbo.ContNoMAPPing(CONTNO) AS CONTNO, RGTNO, NAME, CASETIME, CASEDESC, HOSPITAL, DAYS, REASON, RPTMONEY,                        APPMAN, RELATION, APPPHONE, APPDATE, RGTTIME, SURVEYDES, SURVEYRESULT, SETTLETIME, CASESTATUS, CASEMONEY,                           (SELECT     SUM(REALPAY) AS Expr1                             FROM          dbo.MAP_LLCLAIMDETAIL                             WHERE      (CONTNO = a.CONTNO) AND (REPORTNO = a.REPORTNO)) AS RefundAmount  FROM         dbo.MAP_LLCLAIM AS a  
--2014-02-17 modify by zxq 屏蔽ESEG/ILIFE数据 
--UNION all  SELECT     crbo.F_Name, crbc.F_Name AS Expr1, crcc.F_REPORTTIME, CAST(crcc.F_HASREPORTINFO AS nvarchar) AS Expr2, crcc.F_REPORTCODE,                        tb_app.CD_POLICY_COMPLEMENT, crcc.F_REGISTERCODE, crcc.F_INSURANTNAME, crcc.F_OCCURTIME, crcc.F_CLAIMCOMMENT, crcc.F_HOSPITALNAME,                        crcc.F_HOSPITALIZATIONDAYS, crbhr.F_Name AS Expr3, crcc.F_CLAIMAMOUNT, crcc.F_APPLICATIONPERSON, crbrw.F_Name AS Expr4,                        crcc.F_APPLICATIONPERSONTEL, crcc.F_APPLICATIONTIME, crcc.F_REGISTERTIME, CAST(crcc.F_HASINVESTIGATIONINFO AS nvarchar) AS Expr5,                        crcc.F_INVESTIGATIONRESULT, crcc.F_PASSCONFIRMTIME, crccs.F_NAME AS Expr6, crcc.F_PAYMENTAMOUNT, crcc.F_REFUNDAMOUNT  FROM         dbo.CR_C_CLAIM AS crcc INNER JOIN                       dbo.CR_C_INSURANCEDETAIL AS crci ON crcc.F_KEY = crci.F_CLAIM INNER JOIN                       dbo.CR_B_Organization AS crbo ON crbo.F_Key = crcc.F_ORGANIZATION INNER JOIN                       dbo.CR_B_Channel AS crbc ON crbc.F_Key = crci.F_CHANNEL INNER JOIN                       dbo.TB_APPLICATION AS tb_app ON crci.F_CODE = tb_app.CD_POLICY_COMPLEMENT LEFT OUTER JOIN                       dbo.CR_B_HospitalizationReason AS crbhr ON crbhr.F_Key = crcc.F_HOSPITALIZATIONREASON LEFT OUTER JOIN                       dbo.CR_B_RelationshipWithInsurant AS crbrw ON crbrw.F_Key = crcc.F_RELATIONSHIPWITHINSURANT INNER JOIN                       dbo.CR_C_CLAIMSTATUS AS crccs ON crccs.F_KEY = crcc.F_STATUS  UNION  SELECT     mdic.OrganizationName, mdic.Branchtype, mdic.ReportTime, mdic.HasReportInfo, mdic.RegisterCode, mdic.MainpolNo, mdic.RegisterCode AS Expr1,                        mdic.Nm_participant, mdic.OccurTime, mdic.ClaimComment, mdic.HospitalName, mdic.HospitalizationDays, mdic.HospitalizationReason, mdic.ClaimAmount,                        mdic.ApplicationPerson, mdic.RelationshipWithInsurant, mdic.ApplicationPersonTel, mdic.ApplicationTime, mdic.RegisterTime, mdic.HasInvestigationInfo,                        mdic.InvestigationResult, mdic.PassConfirmTime, mdic.Claim_Status, mdicc.PaymentAmount, mdic.RefundAmount  FROM         dbo.MDIClaiminfo AS mdic INNER JOIN                       dbo.MDIClaimCovarage AS mdicc ON mdic.MainpolNo = mdicc.MainpolNo AND mdic.RegisterCode = mdicc.RegisterCode
--2014-02-17 end
) oldtable
 set @iRecordCount_LLCLAIM=@@rowcount  
insert into PolFlushLog values('MAP_LCClaim_V','insert',@iRecordCount_LLCLAIM,getdate())
--MAP_LLCLAIM_V ---end

--MAP_LLCLAIMDETAIL_V ---start
truncate table  MAP_LLCLAIMDETAIL_V
declare @iRecordCount_LLCLAIMDETAIL int 
insert into MAP_LLCLAIMDETAIL_V(REPORTNO, RGTNO, CONTNO, RISKCODE, CLAIMTYPE, REALPAY, COLLECTPAY_CODE, RiskName, CLAIMSTATUS, SETTLETIME, MANAGECOM, SALECHNL, [NAME], HOSPITAL, DAYS, REASON, RGTTIME, GIVETYPE,TABFEEMONEY ) select * from ( SELECT REPORTNO, RGTNO, dbo.ContNoMAPPing(CONTNO) AS CONTNO, RISKCODE, CLAIMTYPE, REALPAY, COLLECTPAY_CODE,(SELECT TOP (1) RiskName FROM dbo.MAP_DIRisk WHERE (RiskShortName = a.RISKCODE)) AS RiskName, CLAIMSTATUS, SETTLETIME, MANAGECOM, SALECHNL,(SELECT CONVERT(NVARCHAR, DECRYPTBYPASSPHRASE(N'METLIFE', NAME)) AS Expr1 FROM dbo.MAP_LCINSURED WHERE (INSUREDNO = a.CUSTOMERNO) AND (CONTNO = a.CONTNO)) AS NAME, HOSPITAL, DAYS, REASON, RGTTIME, GIVETYPE,TABFEEMONEY  FROM dbo.MAP_LLCLAIMDETAIL AS a 
--2014-02-17 modify by zxq 屏蔽ESEG/ILIFE数据 
--UNION all SELECT crcc.F_REPORTCODE, crcc.F_REGISTERCODE, tb_app.CD_POLICY_COMPLEMENT, crbc.F_CODE, crbp.F_Name, CAST(CAST(crccd.F_PaymentAmount AS decimal(12,2)) AS nvarchar) AS Expr1, crbpm.F_Name AS Expr2, crbc.F_NAME AS Expr3, crccs.F_NAME AS Expr4, crcc.F_PASSCONFIRMTIME, crbo.F_Name AS Expr5,crbch.F_Name AS Expr6, crcc.F_INSURANTNAME, crcc.F_HOSPITALNAME, crcc.F_HOSPITALIZATIONDAYS, crbhr.F_Name AS Expr7, crcc.F_REGISTERTIME FROM dbo.CR_C_CLAIM AS crcc INNER JOIN dbo.CR_C_INSURANCEDETAIL AS crci ON crcc.F_KEY = crci.F_CLAIM INNER JOIN dbo.CR_C_COVERAGEDETAIL AS crccd ON crccd.F_INSURANCEDETAIL = crci.F_KEY INNER JOIN dbo.CR_B_COVERAGE AS crbc ON crbc.F_KEY = crccd.F_COVERAGE INNER JOIN dbo.CR_B_PaymentDuty AS crbp ON crbp.F_Key = crcc.F_PAYMENTDUTY LEFT OUTER JOIN dbo.CR_B_PaymentMode AS crbpm ON crbpm.F_Key = crcc.F_PAYMENTMODE INNER JOIN dbo.TB_APPLICATION AS tb_app ON crci.F_CODE = tb_app.CD_POLICY_COMPLEMENT INNER JOIN dbo.CR_C_CLAIMSTATUS AS crccs ON crccs.F_KEY = crcc.F_STATUS   INNER JOIN dbo.CR_B_Organization AS crbo ON crbo.F_Key = crcc.F_ORGANIZATION INNER JOIN dbo.CR_B_Channel AS crbch ON crbch.F_Key = crci.F_CHANNEL LEFT OUTER JOIN dbo.CR_B_HospitalizationReason AS crbhr ON crbhr.F_Key = crcc.F_HOSPITALIZATIONREASON WHERE (crccs.F_NAME IN ('结案', '签批通过')) UNION all SELECT mdic.RegisterCode, mdic.RegisterCode AS Expr2, tb_app.CD_POLICY_COMPLEMENT, mdicc.ClaimRiskCode, mdic.PaymentDuty,CAST(mdicc.PaymentAmount AS nvarchar) AS Expr1, mdic.PaymentMode, tb_co.NM_BASIC_COVERAGE, mdic.Claim_Status, mdic.PassConfirmTime,mdic.OrganizationName, mdic.Branchtype, mdic.Nm_participant, mdic.HospitalName, mdic.HospitalizationDays, mdic.HospitalizationReason,mdic.RegisterTime FROM dbo.MDIClaiminfo AS mdic INNER JOIN dbo.MDIClaimCovarage AS mdicc ON mdic.MainpolNo = mdicc.MainpolNo AND mdic.RegisterCode = mdicc.RegisterCode INNER JOIN dbo.TB_APPLICATION AS tb_app ON mdic.MainpolNo = tb_app.CD_POLICY_COMPLEMENT INNER JOIN dbo.TB_APPLICATION_COVERAGE AS tb_app_c ON tb_app.CD_ADMINISTRATOR = tb_app_c.CD_ADMINISTRATOR AND tb_app.CD_BRANCH = tb_app_c.CD_BRANCH AND tb_app.CD_PRODUCT = tb_app_c.CD_PRODUCT AND tb_app.CD_APPLICATION = tb_app_c.CD_APPLICATION INNER JOIN dbo.TB_COVERAGE AS tb_co ON tb_app_c.CD_COVERAGE = tb_co.CD_COVERAGE AND tb_co.NM_COVERAGE_REDUCED = mdicc.ClaimRiskCode WHERE (mdic.Claim_Status IN ('非死亡索赔-拒赔', '非死亡索赔-已批核', '拒赔-保单注销', '死亡索赔-拒赔', '死亡索赔-已批核')) 
--2014-02-17 end 
) oldtable
 set @iRecordCount_LLCLAIMDETAIL=@@rowcount  
insert into PolFlushLog values('MAP_LLCLAIMDETAIL_V','insert',@iRecordCount_LLCLAIMDETAIL,getdate())
--MAP_LLCLAIMDETAIL_V ---end

--MAP_LPEDORAPP_V ---start
truncate table  MAP_LPEDORAPP_V
declare @iRecordCount_LPEDORAPP int 
insert into MAP_LPEDORAPP_V select * from (  SELECT     EDORACCEPTNO, EDORAPPNAME, AGENTCODE, CAGENTCODE, APPDATE, EDORSTATE,                           (SELECT     codename                             FROM          dbo.MAP_DICode                             WHERE      (a.EDORSTATE = code) AND (codetype = 'TN789')) AS EDORSTATENAME,Account_back  FROM         dbo.MAP_LPEDORAPP AS a  
--2014-02-17 modify by zxq 屏蔽ESEG/ILIFE数据 
--UNION ALL  SELECT     EndorseNo, '', Agentcode, NULL AS Expr1, AppDate, Status,                           (SELECT     CodeName                             FROM          dbo.MDICode                             WHERE      (a.Status = Code) AND (CodeType = 'Status')) AS EDORSTATENAME  FROM         dbo.MDIEndorseinfo AS a
--2014-02-17 end
) oldtable
 set @iRecordCount_LPEDORAPP=@@rowcount  
insert into PolFlushLog values('MAP_LPEDORAPP_V','insert',@iRecordCount_LPEDORAPP,getdate())
--MAP_LPEDORAPP_V ---end

--MAP_LPEDORITEM_V ---start
truncate table  MAP_LPEDORITEM_V
declare @iRecordCount_LPEDORITEM int 
insert into MAP_LPEDORITEM_V select * from ( SELECT     EDORACCEPTNO, EDORTYPE, EDORNAME, dbo.ContNoMAPPing(CONTNO) AS CONTNO, EDORSTATE, LASTUPDATTIME FROM         dbo.MAP_LPEDORITEM 
--2014-02-17 modify by zxq 屏蔽ESEG/ILIFE数据 
--UNION ALL SELECT     a.EndorseNo, b.ChangeType,                           (SELECT     CodeName                             FROM          dbo.MDICode                             WHERE      (CodeType = 'ChangeType') AND (b.ChangeType = Code)) AS Expr1, a.MainpolNo, a.Status, a.LastModifyDate FROM         dbo.MDIEndorseinfo AS a INNER JOIN                       dbo.MDIEndorseDetail AS b ON a.APP_No = b.APP_NO AND a.EndorseNo = b.POS_NO                       
--2014-02-17 end
) oldtable
 set @iRecordCount_LPEDORITEM=@@rowcount  
insert into PolFlushLog values('MAP_LPEDORITEM_V','insert',@iRecordCount_LPEDORITEM,getdate())
--MAP_LPEDORITEM_V ---end

--MAP_LCCont_V NEW---start
--policy from LA

--update _ lccontnew
declare @iRecordCount_lccontnew int; 

declare @maxtime_lccont datetime;
set @maxtime_lccont=(select case when max(ETL_DATATIME) is null then '1911-01-01' else max(ETL_DATATIME) end from MAP_LCCont_V);

declare my_cursor cursor for select distinct(substring(convert(char(25),SIGNDATE,0),8,4)) from MAP_LCCont group by SIGNDATE;
declare @SIGNDATE_TEMP char(25);
open my_cursor;

FETCH NEXT FROM my_cursor into @SIGNDATE_TEMP

while(@@fetch_status=0)
begin

truncate table MAP_LCCont_Temp;
insert into MAP_LCCont_Temp select * from (
select temp.* from (SELECT     dbo.ContNoMAPPing(CONTNO) AS CONTNO, PRTNO, EXECUTECOM, MANAGECOM, AGENTCOM, AGENTCODE, 
BXSCODE, BXSNAME, AGENTGROUP, ISNULL(CAGENTCODE,'') AS CAGENTCODE, CAGENTGROUP, SALECHNL, STATE, dbo.CliNoMAPPing(APPNTNO) AS APPNTNO, APPNTNAME,
 APPNTSEX, APPNTBIRTHDAY, IDTYPE, IDNO,RELATIONWITHINSURED, NATIVEPLACE,
 COUNTRY, ADDRESS1, ADDRESS2, ADDRESS3, ZIPCODE, PHONE, POSTADDRESS1, POSTADDRESS2, POSTADDRESS3,                        
 POSTADDRESS, POSTZIPCODE, CHARGEADDRESS, CHARGEPHONE, CUSTCOLLECTADDR, COMPANY, MARRIAGE, OCCUPATIONTYPE, OCCUPATIONCODE,                        OCCUPATIONNAME, COCCUPATIONTYPE, COMPANYADDRESS, CUSTOFFICEPOST, CUSTOFFICEPHONE, MOBILEPHONE, EMAIL, PAYINTV, NEWPAYMODE,                        NEWBANKCODE, NEWBANKACCNO, PAYMODE, BANKCODE, BANKACCNO, POLAPPLYDATE, ACCEPTDATE, SIGNDATE, CVALIDATE, MATDATE, CUSTOMGETPOLDATE,                        RECEIVEDATE, WITHDRAWDATE, LASTRVALIDATE, ETL_DATATIME, 
ENCRYPT_FLAG, MONTH(APPNTBIRTHDAY) AS month, DAY(APPNTBIRTHDAY) AS day,DUEDAY,APL_FLAG,APL_AMT 
FROM  dbo.MAP_LCCONT where substring(convert(char(25),SIGNDATE,0),8,4)=@SIGNDATE_TEMP 
and ETL_DATATIME>@maxtime_lccont) temp where dbo.ContNoMAPPing(CONTNO) in (SELECT contno from MAP_LCCont_V) ) a;

update a set 
a.PRTNO = oldtable.prtno ,
a.EXECUTECOM = oldtable.executecom,
a.MANAGECOM = oldtable.managecom,
a.AGENTCOM = oldtable.agentcom,
a.AGENTCODE = oldtable.agentcode,
a.BXSCODE = oldtable.bxscode,
a.BXSNAME= oldtable.bxsname,
a.AGENTGROUP= oldtable.agentgroup,
a.CAGENTCODE= oldtable.cagentcode,
a.CAGENTGROUP= oldtable.cagentgroup,
a.SALECHNL= oldtable.salechnl,
a.STATE= oldtable.state,
a.APPNTNO= oldtable.appntno,
a.APPNTNAME= oldtable.appntname,
a.APPNTSEX= oldtable.appntsex,
a.APPNTBIRTHDAY= oldtable.appntbirthday,
a.IDTYPE= oldtable.idtype,
a.IDNO= oldtable.idno,
a.RELATIONWITHINSURED= oldtable.relationwithinsured,
a.NATIVEPLACE= oldtable.nativeplace,
a.COUNTRY= oldtable.country,
a.ADDRESS1= oldtable.address1,
a.ADDRESS2= oldtable.address2,
a.ADDRESS3= oldtable.address3,
a.ZIPCODE= oldtable.zipcode,
a.PHONE= oldtable.phone,
a.POSTADDRESS1= oldtable.postaddress1,
a.POSTADDRESS2= oldtable.postaddress2,
a.POSTADDRESS3= oldtable.postaddress3,
a.POSTADDRESS= oldtable.postaddress,
a.POSTZIPCODE= oldtable.postzipcode,
a.CHARGEADDRESS= oldtable.chargeaddress,
a.CHARGEPHONE= oldtable.chargephone,
a.CUSTCOLLECTADDR= oldtable.custcollectaddr,
a.COMPANY= oldtable.company,
a.MARRIAGE= oldtable.marriage,
a.OCCUPATIONTYPE= oldtable.occupationtype,
a.OCCUPATIONCODE= oldtable.occupationcode,
a.OCCUPATIONNAME= oldtable.occupationname,
a.COCCUPATIONTYPE= oldtable.coccupationtype,
a.COMPANYADDRESS= oldtable.companyaddress,
a.CUSTOFFICEPOST= oldtable.custofficepost,
a.CUSTOFFICEPHONE= oldtable.custofficephone,
a.MOBILEPHONE= oldtable.mobilephone,
a.EMAIL= oldtable.email,
a.PAYINTV= oldtable.payintv,
a.NEWPAYMODE= oldtable.newpaymode,
a.NEWBANKCODE= oldtable.newbankcode,
a.NEWBANKACCNO= oldtable.newbankaccno,
a.PAYMODE= oldtable.paymode,
a.BANKCODE= oldtable.bankcode,
a.BANKACCNO= oldtable.bankaccno,
a.POLAPPLYDATE= oldtable.polapplydate,
a.ACCEPTDATE= oldtable.acceptdate,
a.SIGNDATE= oldtable.signdate,
a.CVALIDATE= oldtable.cvalidate,
a.MATDATE= oldtable.matdate,
a.CUSTOMGETPOLDATE= oldtable.customgetpoldate,
a.RECEIVEDATE= oldtable.receivedate,
a.WITHDRAWDATE= oldtable.withdrawdate,
a.LASTRVALIDATE= oldtable.lastrvalidate,
a.ETL_DATATIME= oldtable.etl_datatime,
a.ENCRYPT_FLAG= oldtable.encrypt_flag,
a.month= oldtable.month,
a.day= oldtable.day,
a.DUEDAY = oldtable.DUEDAY,
a.APL_FLAG = oldtable.APL_FLAG,
a.APL_AMT = oldtable.APL_AMT
from  MAP_LCCont_V a ,MAP_LCCont_Temp oldtable
where a.contno = oldtable.contno 
--孤儿单处理
--and a.AGENTCODE = oldtable.agentcode and a.CAGENTCODE= oldtable.cagentcode 
--modify by zxq 2013-12-16游标应取Temp表中
--and substring(convert(char(25),a.SIGNDATE,0),8,4)=@SIGNDATE_TEMP;
and substring(convert(char(25),oldtable.SIGNDATE,0),8,4)=@SIGNDATE_TEMP;

set @iRecordCount_lccontnew=@@rowcount  
insert into PolFlushLog values('MAP_LCCont_V_NEW','update',@iRecordCount_lccontnew,getdate())

FETCH NEXT FROM my_cursor into @SIGNDATE_TEMP

end;
close my_cursor;
deallocate my_cursor; 


--customerinfo&customeraddress表更新--xiaodi--begin
---客户信息表存储----
	--select * from EverydayUpdate
truncate table EverydayUpdate
---选出MAP_LCCont_V的新数据放入临时表

  --投保人信息
declare @currentIndex int
declare @totalRows int
declare @contno NVARCHAR(20)
declare @tCustomerName NVARCHAR(1000)
declare @tAgentCode NVARCHAR(40)
declare @tGender NVARCHAR(1)
declare @tBithDate DATETIME
declare @tRELATIONTOAPPNT NVARCHAR(4) 
declare @tCustomerCode NVARCHAR(2000)


--declare @maxtime_lccont datetime;
--set @maxtime_lccont=(select max(ETL_DATATIME) from MAP_LCCont_V);

insert into EverydayUpdate(CONTNO,APPNTNAME,APPNTBIRTHDAY,agentcode,APPNTSEX)
SELECT  dbo.ContNoMAPPing(CONTNO) AS CONTNO, APPNTNAME,APPNTBIRTHDAY, agentcode,APPNTSEX FROM  dbo.MAP_LCCONT a 
        where not exists (select 1 from MAP_LCCont_V where contno=dbo.ContNoMAPPing(a.CONTNO)) 
        --and ETL_DATATIME>@maxtime_lccont 
--select * from EverydayUpdate

set    @totalRows=(select count(1) from EverydayUpdate)
set    @currentIndex=1
set    @contno = null
set    @tCustomerName =null
set    @tAgentCode =null
set    @tGender =null
set    @tBithDate =null
set    @tRELATIONTOAPPNT = null
set    @tCustomerCode = null

   --被保人信息
declare @tNAME NVARCHAR(1000)
declare @tSEX NVARCHAR(1)
declare @tBIRTHDAY DATETIME
declare @tCustomerCodein NVARCHAR(2000)
 
set     @tNAME = null
set     @tSEX = null
set     @tBIRTHDAY = null
set     @tCustomerCodein = null 

---while循环数据


while (@currentIndex<=@totalRows)
begin
---选出新数据中的姓名，性别年龄
set @contno = (select CONTNO from EverydayUpdate where id = @currentIndex )
--set @tCustomerName = (select APPNTNAME from EverydayUpdate where id = @currentIndex )
set @tCustomerName = (select CONVERT(NVARCHAR, DECRYPTBYPASSPHRASE(N'METLIFE',APPNTNAME)) from EverydayUpdate where id = @currentIndex )
set @tBithDate = (select APPNTBIRTHDAY from EverydayUpdate where id = @currentIndex )       
set @tAgentCode =(select agentcode from EverydayUpdate where id = @currentIndex )
set @tGender = (select APPNTSEX from EverydayUpdate where id = @currentIndex )
 

--选出姓名、性别、年龄相同的infor表的CustomerCode

set @tCustomerCode = (select max(CustomerCode) from [dbo].[CustomerInfo]
where CustomerName=@tCustomerName and AgentCode=@tAgentCode and Gender=@tGender and BirthDate=@tBithDate) ;


---更新Info表的数据 (投保人)    
if EXISTS (select 1 from CustomerInfo where CustomerName=@tCustomerName and AgentCode=@tAgentCode and Gender=@tGender and BirthDate=@tBithDate)
   update CustomerInfo 
   set CustomerType='AIC',LACustomerNo=a.appntno,
   ModifyDate=getdate(), ModifyTime=(select CONVERT(varchar(12) , getdate(), 108 )) ,ModifySource='LA',
   ModifyType='U'
   from MAP_LCCONT a 
   where a.contno=@contno and CustomerInfo.CustomerCode=@tCustomerCode;
  
  --被保人
  
 
 
  set @tRELATIONTOAPPNT = (select RELATIONTOAPPNT from MAP_LCINSURED where contno=@contno );
  if @tRELATIONTOAPPNT <>'00'
    --set @tNAME = (select NAME from MAP_LCINSURED_V where contno = @contno )
	set @tNAME = (select CONVERT(NVARCHAR, DECRYPTBYPASSPHRASE(N'METLIFE',NAME)) from MAP_LCINSURED where contno = @contno )
	set @tBIRTHDAY = (select BIRTHDAY from MAP_LCINSURED where contno = @contno )       
	set @tSEX = (select SEX from MAP_LCINSURED where contno = @contno )   
 
  set @tCustomerCodein = (select max(CustomerCode) from CustomerInfo 
  where CustomerName=@tNAME and AgentCode=@tAgentCode and Gender=@tSEX and BirthDate=@tBIRTHDAY );
 
 
  if  EXISTS (select 1 from CustomerInfo where CustomerName=@tNAME and AgentCode=@tAgentCode and Gender=@tSEX and BirthDate=@tBIRTHDAY )
   update CustomerInfo 
   set CustomerType='AIC',LACustomerNo=d.insuredno,
   ModifyDate=getdate(), ModifyTime=(select CONVERT(varchar(12) , getdate(), 108 )) ,ModifySource='LA',
   ModifyType='U'
   from MAP_LCINSURED d
   where CustomerInfo.CustomerCode=@tCustomerCodein and d.contno=@contno;
 
 
 ---更新地址表的数据 (投保人)  
 if EXISTS (select 1 from CustomerAddress where CustomerCode=@tCustomerCode and DataSource='LA' and AddressType='HA' )
  begin
   update CustomerAddress 
   set CustomerAddress.AddressDoor=b.ADDRESS1,CustomerAddress.PostCode=b.ZIPCODE,CustomerAddress.IsPostAD='N',
   
   CustomerAddress.AddressPro = '',	CustomerAddress.AddressCity='',	CustomerAddress.AddressCounty='',CustomerAddress.addressWay='',--wenhe
   
   CustomerAddress.ModifyDate = getdate(),
   CustomerAddress.ModifyTime=(select CONVERT(varchar(12) , getdate(), 108 )),
   CustomerAddress.ModifySource='LA',
   CustomerAddress.ModifyType='U'
   from MAP_LCCONT b,CustomerAddress  
   where b.contno=@contno and CustomerAddress.CustomerCode=@tCustomerCode and CustomerAddress.DataSource='LA' 
   and CustomerAddress.AddressType='HA'
 end
else
 begin
   insert into CustomerAddress
   select b.agentcode as 营销员编号, a.CustomerCode as 客户编号, 'HA' as 地址类型,'' as 地址_省,
   '' as 地址_市,'' as 地址_区县,'' as 地址_镇路,b.ADDRESS1 as 详细地址,b.ZIPCODE as 邮编, 'N' as 是否邮寄地址,
   'LA' as 数据来源,b.CVALIDATE as 入机日期,'' as 入机时间,getdate() as 更新日期,
   (select CONVERT(varchar(12) , getdate(), 108 )) as 更新时间,
   'MAP' as 最后操作源,'A' as 最后操作,'' as 备用字段1, '' as 备用字段2, ''as 备用字段3, '' as 备用字段4,
   '' as 备用字段5
   from MAP_LCCONT b ,CustomerInfo a 
   where b.contno=@contno and a.CustomerCode=@tCustomerCode
  end ;
	
if EXISTS (select 1 from CustomerAddress where CustomerCode=@tCustomerCode and DataSource='LA' and AddressType='OA' )
  begin
   update CustomerAddress 
   set CustomerAddress.AddressDoor=CONVERT(NVARCHAR(300), DECRYPTBYPASSPHRASE(N'METLIFE',b.CHARGEADDRESS)) ,
   CustomerAddress.PostCode=b.CUSTCOLLECTADDR,CustomerAddress.ModifyDate = getdate(),
   CustomerAddress.AddressPro = '',	CustomerAddress.AddressCity='',	CustomerAddress.AddressCounty='',
   CustomerAddress.addressWay='',--wenhe
   CustomerAddress.ModifyTime=(select CONVERT(varchar(12) , getdate(), 108 )),
   CustomerAddress.ModifySource='LA',
   CustomerAddress.ModifyType='U'
   from MAP_LCCONT b,CustomerAddress  
   where b.contno=@contno and CustomerAddress.CustomerCode=@tCustomerCode and CustomerAddress.DataSource='LA' 
   and CustomerAddress.AddressType='OA'
 end
else
 begin	 
   insert into CustomerAddress
   select  b.agentcode as 营销员编号, a.CustomerCode as 客户编号, 'OA' as 地址类型,'' as 地址_省,
   '' as 地址_市,'' as 地址_区县,'' as 地址_镇路,CONVERT(NVARCHAR(300), DECRYPTBYPASSPHRASE(N'METLIFE',b.CHARGEADDRESS)) as 详细地址,
   b.CUSTCOLLECTADDR as 邮编,'Y' as 是否邮寄地址,'LA' as 数据来源,b.CVALIDATE as 入机日期,'' as 入机时间,
   getdate() as 更新日期,(select CONVERT(varchar(12) , getdate(), 108 )) as 更新时间,
   'MAP' as 最后操作源,'A' as 最后操作,'' as 备用字段1, '' as 备用字段2, ''as 备用字段3, '' as 备用字段4,
   '' as 备用字段5
   from MAP_LCCONT b ,CustomerInfo a 
   where b.contno=@contno and a.CustomerCode=@tCustomerCode
 end;
 
 ---更新地址表的数据 (被保人)  
if @tRELATIONTOAPPNT <>'00' 
  begin 
    if EXISTS (select 1 from CustomerAddress where CustomerCode=@tCustomerCodein and DataSource='LA' and AddressType='HA'  )
		  begin
		   update CustomerAddress 
		   set CustomerAddress.AddressDoor=CONVERT(NVARCHAR(300), DECRYPTBYPASSPHRASE(N'METLIFE',b.ADDRESS1)) ,
		   CustomerAddress.PostCode=b.ZIPCODE,CustomerAddress.ModifyDate = getdate(),
		   CustomerAddress.AddressPro = '',	CustomerAddress.AddressCity='',	CustomerAddress.AddressCounty='',
		   CustomerAddress.addressWay='',--wenhe
		   CustomerAddress.ModifyTime=(select CONVERT(varchar(12) , getdate(), 108 )),
		   CustomerAddress.ModifySource='LA',
		   CustomerAddress.ModifyType='U'
		   from MAP_LCINSURED b,CustomerAddress  
		   where b.contno=@contno  and CustomerAddress.CustomerCode=@tCustomerCodein and CustomerAddress.DataSource='LA' 
		   and CustomerAddress.AddressType='HA' and dbo.MAP_DICODETONAME(N'T5666',b.RELATIONTOAPPNT) <>'本人'
		 end
		else
		 begin
		   insert into CustomerAddress
		   select  c.agentcode as 营销员编号, a.CustomerCode as 客户编号, 'HA' as 地址类型,'' as 地址_省,
		   '' as 地址_市,'' as 地址_区县,'' as 地址_镇路,CONVERT(NVARCHAR(300), DECRYPTBYPASSPHRASE(N'METLIFE',b.ADDRESS1)) as 详细地址,
		   b.ZIPCODE as 邮编, 'Y' as 是否邮寄地址,'LA' as 数据来源,c.CVALIDATE as 入机日期,'' as 入机时间,getdate() as 更新日期,
		   (select CONVERT(varchar(12) , getdate(), 108 )) as 更新时间,'MAP' as 最后操作源,'A' as 最后操作,'' as 备用字段1, 
		   '' as 备用字段2, ''as 备用字段3, '' as 备用字段4,'' as 备用字段5
		   from MAP_LCINSURED b ,CustomerInfo a ,MAP_LCCONT c
		   where b.contno=c.contno and b.contno=@contno
		   and a.CustomerCode=@tCustomerCodein
		   and dbo.MAP_DICODETONAME(N'T5666',b.RELATIONTOAPPNT) <>'本人'
		 end
 end;

 ---更新保单查询表Policy
   insert into Policy(AgentCode,LACode,CustomerName,BirthDate,Phone,PolicyNum,InsuranceType,InsuranceName
   ,PaymentMethod,Premium,Amount,FirstPayment,RenewalFee,CushionCondition,InsureDate,PolicyStatus)
   select 
   lcc.agentcode as 营销员编号,  
   lcc.appntno as 客户编号,
   CONVERT(NVARCHAR, DECRYPTBYPASSPHRASE(N'METLIFE',lcc.APPNTNAME)) as 客户姓名,
   CONVERT(NVARCHAR,lcc.APPNTBIRTHDAY,23) as 出生日期,
   lcc.mobilephone as 手机号,
   lcc.contno as 保单,
   lcp.RISKCODE as 主险险种, 
   lcp.MAINRISKNAME as 主险名称, 
   dbo.MAP_DICODETONAME('T3590',lcc.PAYINTV) as 交费频率,
   dbo.NULLSWITCH( cast ( 
   (case when lcc.STATE='1' and (select count(*) from MAP_LJSPAY_V where contno=lcc.contno)>0 
   then (select max(ljs.DUEMONEY) from MAP_LJSPAY_V ljs where ljs.CONTNO=lcc.contno and ljs.DUEMONEY>0     
   and ljs.DUEDATE=(     select max(a.DUEDATE) from MAP_LJSPAY_V a where a.CONTNO=lcc.contno and a.DUEMONEY>0     )   
    )else (select max(a.GETMONEY) from MAP_LJAPAY_V a where a.CONTNO=lcc.contno and a.GETMONEY>0    
    and a.DUEDATE=(     select max(a.DUEDATE) from MAP_LJAPAY_V a  where a.CONTNO=lcc.contno 
    and (a.CANCELDATE is null or a.CANCELDATE='') and a.GETMONEY>0 and a.CONFDATE is not null    )
    and a.confdate=(select max(a.confdate) from MAP_LJAPAY_V a  where a.CONTNO=lcc.contno )    
    )end ) as decimal(12,2))) as 期交保费,
   (case when (lcp.AMNT is not null and lcp.AMNT>0.00) then cast(lcp.AMNT as nvarchar)   when (lcp.MULT is not null and lcp.MULT<>'')
    then cast (lcp.MULT as nvarchar ) +'份' else '' end) as 保险金额, 
   dbo.MAP_DICODETONAME('T3620', lcc.NEWPAYMODE) as 首期交费方式, 
   dbo.MAP_DICODETONAME('T3620', lcc.PAYMODE) as 续期交费方式, 
   (case  when lcc.APL_FLAG = 'Y' then '有自垫'  when lcc.APL_FLAG = 'N' then '无自垫' end) 垫交情况 ,
   substring(CONVERT(varchar(24), lcc.SIGNDATE, 23),0,11) as 保单承保日期,
   ( case when lcc.STATE = '0' then '失效' when lcc.STATE = '1'   then '有效' when lcc.STATE = '3' then  '犹豫期撤单' 
    when lcc.STATE = '5' then '退保'  else  '' end) as 保单状态
   from  MAP_LCCONT lcc  
        ,MAP_LCPOL lcp  
   where 1=1 
        and lcc.CONTNO = lcp.CONTNO 
        and lcp.SUBRISKFLAG='Y'   
        and lcc.CONTNO=@contno
        and lcc.SIGNDATE is not null ;
        
 set @currentIndex=@currentIndex+1; 
   
 end;
  
   

--exec sp_help 'CustomerInfo'

--customerinfo&customeraddress表更新--xiaodi--end

--insert
declare @iRecordCount_lccontnew_insert int 

insert into MAP_LCCont_V select * from(
SELECT     dbo.ContNoMAPPing(CONTNO) AS CONTNO, PRTNO, EXECUTECOM, MANAGECOM, AGENTCOM, AGENTCODE, BXSCODE, BXSNAME, AGENTGROUP, CAGENTCODE,                        
CAGENTGROUP, SALECHNL, STATE, dbo.CliNoMAPPing(APPNTNO) AS APPNTNO, APPNTNAME, APPNTSEX, APPNTBIRTHDAY, IDTYPE, IDNO,                        
RELATIONWITHINSURED, NATIVEPLACE, COUNTRY, ADDRESS1, ADDRESS2, ADDRESS3, ZIPCODE, PHONE, POSTADDRESS1, POSTADDRESS2, POSTADDRESS3,                        
POSTADDRESS, POSTZIPCODE, CHARGEADDRESS, CHARGEPHONE, CUSTCOLLECTADDR, COMPANY, MARRIAGE, OCCUPATIONTYPE, OCCUPATIONCODE,                        
OCCUPATIONNAME, COCCUPATIONTYPE, COMPANYADDRESS, CUSTOFFICEPOST, CUSTOFFICEPHONE, MOBILEPHONE, EMAIL, PAYINTV, NEWPAYMODE,                        
NEWBANKCODE, NEWBANKACCNO, PAYMODE, BANKCODE, BANKACCNO, POLAPPLYDATE, ACCEPTDATE, SIGNDATE, CVALIDATE, MATDATE, CUSTOMGETPOLDATE,                       
RECEIVEDATE, WITHDRAWDATE, LASTRVALIDATE, ETL_DATATIME, ENCRYPT_FLAG, MONTH(APPNTBIRTHDAY) AS month, DAY(APPNTBIRTHDAY) AS day ,DUEDAY,
Account_back,NewAccount_back,APL_FLAG,APL_AMT,STATELAORG
--FROM         dbo.MAP_LCCONT where dbo.ContNoMAPPing(CONTNO) not in (SELECT CONTNO from MAP_LCCont_V )
FROM         dbo.MAP_LCCONT a 
where not exists (select 1 from MAP_LCCont_V where contno=dbo.ContNoMAPPing(a.CONTNO))
and ETL_DATATIME>@maxtime_lccont) oldtable
 set @iRecordCount_lccontnew_insert=@@rowcount  
insert into PolFlushLog values('MAP_LCCont_V_NEW','insert',@iRecordCount_lccontnew_insert,getdate())

--MAP_LCCont_V ---end

--MAP_LCPOL_V NEW---start
-- policy detail from LA
--update
declare @iRecordCount_polnew_update int 

declare @maxtime_lcpol datetime;
set @maxtime_lcpol=(select case when max(OperatorDate) is null then '1911-01-01' else max(OperatorDate) end from PolFlushLog where OperatorName like 'MAP_LCPOL_V%');

declare my_cursor cursor for select distinct(substring(convert(char(25),CVALIDATE,0),8,4)) from MAP_LCPOL group by CVALIDATE;
declare @CVALIDATE_TEMP char(25);
open my_cursor;

FETCH NEXT FROM my_cursor into @CVALIDATE_TEMP

while(@@fetch_status=0)
begin

truncate table MAP_LCPol_Temp;
INSERT INTO MAP_LCPol_Temp select * from (
SELECT temp.* from (SELECT case when polno like '%020001000' and subriskflag='Y' then 'N' else SUBRISKFLAG end as SUBRISKFLAG, PRTNO, dbo.ContNoMAPPing(CONTNO) AS CONTNO, MAINRISKNAME, dbo.CliNoMAPPing(INSUREDNO) AS INSUREDNO, RISKCODE, RISKNAME,CVALIDATE, PAYYEARS, PAYAGES, INSUYEARBYYEAR, INSUYEARBYAGE, POLSTATE, AMNT, MULT, AGENTCODE  
FROM dbo.MAP_LCPOL 
where ETL_DATATIME>@maxtime_lcpol and substring(convert(char(25),CVALIDATE,0),8,4)=@CVALIDATE_TEMP) temp where dbo.ContNoMAPPing(CONTNO)+RISKCODE+SUBRISKFLAG in (select distinct CONTNO+RISKCODE+SUBRISKFLAG from MAP_LCPOL_V)) a; 

update a set
a.SUBRISKFLAG= oldtable.SUBRISKFLAG ,
a.PRTNO= oldtable.PRTNO ,
a.CONTNO= oldtable.CONTNO ,
a.MAINRISKNAME= oldtable.MAINRISKNAME ,
a.INSUREDNO= oldtable.INSUREDNO ,
a.RISKCODE= oldtable.RISKCODE ,
a.RISKNAME= oldtable.RISKNAME ,
a.CVALIDATE= oldtable.CVALIDATE ,
a.PAYYEARS= oldtable.PAYYEARS ,
a.PAYAGES= oldtable.PAYAGES ,
a.INSUYEARBYYEAR= oldtable.INSUYEARBYYEAR ,
a.INSUYEARBYAGE= oldtable.INSUYEARBYAGE ,
a.POLSTATE= oldtable.POLSTATE ,
a.AMNT= oldtable.AMNT ,
a.MULT= oldtable.MULT ,
a.AGENTCODE =oldtable.AGENTCODE
from MAP_LCPOL_V a, MAP_LCPol_Temp oldtable
where a.CONTNO = oldtable.CONTNO and a.RISKCODE = oldtable.RISKCODE and a.SUBRISKFLAG=oldtable.SUBRISKFLAG 
--modify by zxq 2013-12-16 游标判断应同select中，取Temp表中CVALIDATE
--and substring(convert(char(25),a.CVALIDATE,0),8,4)=@CVALIDATE_TEMP;
and substring(convert(char(25),oldtable.CVALIDATE,0),8,4)=@CVALIDATE_TEMP;

set @iRecordCount_polnew_update=@@rowcount  

insert into PolFlushLog values('MAP_LCPOL_V_NEW','update',@iRecordCount_polnew_update,getdate())

FETCH NEXT FROM my_cursor into @CVALIDATE_TEMP;

end;
close my_cursor;
deallocate my_cursor;

--insert
declare @iRecordCount_polnew_insert int 

--insert into MAP_LCPOL_V select * from (SELECT     SUBRISKFLAG, PRTNO, dbo.ContNoMAPPing(CONTNO) AS CONTNO, MAINRISKNAME, dbo.CliNoMAPPing(INSUREDNO) AS INSUREDNO, RISKCODE, RISKNAME,CVALIDATE, PAYYEARS, PAYAGES, INSUYEARBYYEAR, INSUYEARBYAGE, POLSTATE, AMNT, MULT, AGENTCODE  
--FROM dbo.MAP_LCPOL a
--where not exists (select 1 from MAP_LCPOL_V where CONTNO+RISKCODE=dbo.ContNoMAPPing(a.CONTNO)+a.RISKCODE)
----where  dbo.ContNoMAPPing(CONTNO)+RISKCODE not in (select distinct CONTNO+RISKCODE from MAP_LCPOL_V) 
----where  CONTNO+RISKCODE not in (select distinct CONTNO+RISKCODE from MAP_LCPOL_V) 
--AND ETL_DATATIME>@maxtime_lcpol) oldtable 

insert into MAP_LCPOL_V select * from (select * from (SELECT case when polno like '%020001000' and subriskflag='Y' then 'N' else SUBRISKFLAG end as SUBRISKFLAG, PRTNO, dbo.ContNoMAPPing(CONTNO) AS CONTNO1, MAINRISKNAME, dbo.CliNoMAPPing(INSUREDNO) AS INSUREDNO, RISKCODE, RISKNAME,CVALIDATE, PAYYEARS, PAYAGES, INSUYEARBYYEAR, INSUYEARBYAGE, POLSTATE, AMNT, MULT, AGENTCODE  
FROM dbo.MAP_LCPOL a
where ETL_DATATIME>@maxtime_lcpol)b
--where  dbo.ContNoMAPPing(CONTNO)+RISKCODE not in (select distinct CONTNO+RISKCODE from MAP_LCPOL_V) 
--where  CONTNO+RISKCODE not in (select distinct CONTNO+RISKCODE from MAP_LCPOL_V) 
where not exists (select 1 from MAP_LCPOL_V where CONTNO=b.CONTNO1 and RISKCODE=b.RISKCODE and SUBRISKFLAG=b.SUBRISKFLAG)) oldtable 
 set @iRecordCount_polnew_insert=@@rowcount  

insert into PolFlushLog values('MAP_LCPOL_V_NEW','insert',@iRecordCount_polnew_insert,getdate())

--MAP_LCPOL_V ---end

update lnpsysvar set sysvarvalue=CONVERT(varchar(100), GETDATE(), 23) where sysvar='policySyncComplete' ;

--删除原建议书客户证件类型
delete from SUGLDCode where codeType='idtype';
--添加建议书客户证件类型
INSERT INTO SUGLDCode VALUES ('idtype','1',N'身份证',NULL,NULL,NULL);
INSERT INTO SUGLDCode VALUES ('idtype','2',N'护照',NULL,NULL,NULL);
INSERT INTO SUGLDCode VALUES ('idtype','3',N'其他（出生证）',NULL,NULL,NULL);
INSERT INTO SUGLDCode VALUES ('idtype','4',N'军人证',NULL,NULL,NULL);
INSERT INTO SUGLDCode VALUES ('idtype','5',N'台胞证',NULL,NULL,NULL);
INSERT INTO SUGLDCode VALUES ('idtype','6',N'港澳通行证',NULL,NULL,NULL);
--删除原建议书客户证件类型
delete from LDCode where codeType='idtype';
--添加建议书客户证件类型
INSERT INTO LDCode VALUES ('idtype','1',N'身份证',NULL,NULL,NULL);
INSERT INTO LDCode VALUES ('idtype','2',N'护照',NULL,NULL,NULL);
INSERT INTO LDCode VALUES ('idtype','3',N'其他（出生证）',NULL,NULL,NULL);
INSERT INTO LDCode VALUES ('idtype','4',N'军人证',NULL,NULL,NULL);
INSERT INTO LDCode VALUES ('idtype','5',N'台胞证',NULL,NULL,NULL);
INSERT INTO LDCode VALUES ('idtype','6',N'港澳通行证',NULL,NULL,NULL);
--删除建议书国籍code
delete from SUGLDCode where CodeType='countryareacode';
--添加建议书国籍code
insert into SUGLDCode (CodeType,Code,CodeName,CodeAlias,ComCode,OtherSign)
 select 'countryareacode' as CodeType,Code,CodeName,CodeAlias,NULL as ComCode,NULL as OtherSign 
 from LNPCode where CodeType='countryareacodenew'
--删除建议书国籍code
delete from ldcode where CodeType='countryareacode';
--添加建议书国籍code
 insert into LDCode (CodeType,Code,CodeName,CodeAlias,ComCode,OtherSign)
 select 'countryareacode' as CodeType,Code,CodeName,CodeAlias,NULL as ComCode,NULL as OtherSign 
 from LNPCode where CodeType='countryareacodenew';
--------------------------------------------------------------------------------------

delete from ldcode where CodeType='provinceCity';
 insert into ldcode
 select * from lnpcode where codetype='provinceCity' and othersign is  null;
 
delete from sugldcode where CodeType='provinceCity';
 insert into sugldcode
 select * from lnpcode where codetype='provinceCity' and othersign is  null;



go

