CREATE PROCEDURE [dbo].[chinaPayBankPZh]
  @amanagecom AS nvarchar ,
  @abankcode AS nvarchar ,
  @abankname AS nvarchar ,
  @acpcode AS nvarchar ,
  @acpname AS nvarchar 
AS
BEGIN
select count(1)  from mbank where MANAGECOM=@amanagecom and p4  in ('2','3')

END
go

