CREATE PROCEDURE [dbo].[xiaoditest] 
AS
--customerinfo&customeraddress表更新--xiaodi--begin
---客户信息表存储----
	--select * from EverydayUpdate
truncate table EverydayUpdate
---选出MAP_LCCont_V的新数据放入临时表

  --投保人信息
declare @currentIndex int
declare @totalRows int
declare @contno NVARCHAR(20)
declare @tCustomerName NVARCHAR(1000)
declare @tAgentCode NVARCHAR(40)
declare @tGender NVARCHAR(1)
declare @tBithDate DATETIME
declare @tRELATIONTOAPPNT NVARCHAR(4) 
declare @tCustomerCode NVARCHAR(2000)


--declare @maxtime_lccont datetime;
--set @maxtime_lccont=(select max(ETL_DATATIME) from MAP_LCCont_V);

insert into EverydayUpdate(CONTNO,APPNTNAME,APPNTBIRTHDAY,agentcode,APPNTSEX)
SELECT  dbo.ContNoMAPPing(CONTNO) AS CONTNO, APPNTNAME,APPNTBIRTHDAY, agentcode,APPNTSEX FROM  dbo.MAP_LCCONT a 
        where a.contno='00955721'
        --and ETL_DATATIME>@maxtime_lccont 
--select * from EverydayUpdate

set    @totalRows=(select count(1) from EverydayUpdate)
set    @currentIndex=1
set    @contno = null
set    @tCustomerName =null
set    @tAgentCode =null
set    @tGender =null
set    @tBithDate =null
set    @tRELATIONTOAPPNT = null
set    @tCustomerCode = null

   --被保人信息
declare @tNAME NVARCHAR(1000)
declare @tSEX NVARCHAR(1)
declare @tBIRTHDAY DATETIME
declare @tCustomerCodein NVARCHAR(2000)
 
set     @tNAME = null
set     @tSEX = null
set     @tBIRTHDAY = null
set     @tCustomerCodein = null 

---while循环数据


while (@currentIndex<=@totalRows)
begin
---选出新数据中的姓名，性别年龄
set @contno = (select CONTNO from EverydayUpdate where id = @currentIndex )
--set @tCustomerName = (select APPNTNAME from EverydayUpdate where id = @currentIndex )
set @tCustomerName = (select CONVERT(NVARCHAR, DECRYPTBYPASSPHRASE(N'METLIFE',APPNTNAME)) from EverydayUpdate where id = @currentIndex )
set @tBithDate = (select APPNTBIRTHDAY from EverydayUpdate where id = @currentIndex )       
set @tAgentCode =(select agentcode from EverydayUpdate where id = @currentIndex )
set @tGender = (select APPNTSEX from EverydayUpdate where id = @currentIndex )
 

--选出姓名、性别、年龄相同的infor表的CustomerCode

set @tCustomerCode = (select max(CustomerCode) from [dbo].[CustomerInfo]
where CustomerName=@tCustomerName and AgentCode=@tAgentCode and Gender=@tGender and BirthDate=@tBithDate) ;


---更新Info表的数据 (投保人)    
if EXISTS (select 1 from CustomerInfo where CustomerName=@tCustomerName and AgentCode=@tAgentCode and Gender=@tGender and BirthDate=@tBithDate)
   update CustomerInfo 
   set CustomerType='AIC',LACustomerNo=a.appntno,
   ModifyDate=getdate(), ModifyTime=(select CONVERT(varchar(12) , getdate(), 108 )) ,ModifySource='LA',
   ModifyType='U'
   from MAP_LCCONT a 
   where a.contno=@contno and CustomerInfo.CustomerCode=@tCustomerCode;
  
  --被保人
  
 
 
  set @tRELATIONTOAPPNT = (select RELATIONTOAPPNT from MAP_LCINSURED where contno=@contno );
  if @tRELATIONTOAPPNT <>'00'
    --set @tNAME = (select NAME from MAP_LCINSURED_V where contno = @contno )
	set @tNAME = (select CONVERT(NVARCHAR, DECRYPTBYPASSPHRASE(N'METLIFE',NAME)) from MAP_LCINSURED where contno = @contno )
	set @tBIRTHDAY = (select BIRTHDAY from MAP_LCINSURED where contno = @contno )       
	set @tSEX = (select SEX from MAP_LCINSURED where contno = @contno )   
 
  set @tCustomerCodein = (select max(CustomerCode) from CustomerInfo 
  where CustomerName=@tNAME and AgentCode=@tAgentCode and Gender=@tSEX and BirthDate=@tBIRTHDAY );
 
 
  if  EXISTS (select 1 from CustomerInfo where CustomerName=@tNAME and AgentCode=@tAgentCode and Gender=@tSEX and BirthDate=@tBIRTHDAY )
   update CustomerInfo 
   set CustomerType='AIC',LACustomerNo=d.insuredno,
   ModifyDate=getdate(), ModifyTime=(select CONVERT(varchar(12) , getdate(), 108 )) ,ModifySource='LA',
   ModifyType='U'
   from MAP_LCINSURED d
   where CustomerInfo.CustomerCode=@tCustomerCodein and d.contno=@contno;
 
 
 ---更新地址表的数据 (投保人)  
 if EXISTS (select 1 from CustomerAddress where CustomerCode=@tCustomerCode and DataSource='LA' and AddressType='HA' )
  begin
   update CustomerAddress 
   set CustomerAddress.AddressDoor=b.ADDRESS1,CustomerAddress.PostCode=b.ZIPCODE,CustomerAddress.IsPostAD='N',
   CustomerAddress.ModifyDate = getdate(),
   CustomerAddress.ModifyTime=(select CONVERT(varchar(12) , getdate(), 108 )),
   CustomerAddress.ModifySource='LA',
   CustomerAddress.ModifyType='U'
   from MAP_LCCONT b,CustomerAddress  
   where b.contno=@contno and CustomerAddress.CustomerCode=@tCustomerCode and CustomerAddress.DataSource='LA' 
   and CustomerAddress.AddressType='HA'
 end
else
 begin
   insert into CustomerAddress
   select b.agentcode as 营销员编号, a.CustomerCode as 客户编号, 'HA' as 地址类型,'' as 地址_省,
   '' as 地址_市,'' as 地址_区县,'' as 地址_镇路,b.ADDRESS1 as 详细地址,b.ZIPCODE as 邮编, 'N' as 是否邮寄地址,
   'LA' as 数据来源,b.CVALIDATE as 入机日期,'' as 入机时间,getdate() as 更新日期,
   (select CONVERT(varchar(12) , getdate(), 108 )) as 更新时间,
   'MAP' as 最后操作源,'A' as 最后操作,'' as 备用字段1, '' as 备用字段2, ''as 备用字段3, '' as 备用字段4,
   '' as 备用字段5
   from MAP_LCCONT b ,CustomerInfo a 
   where b.contno=@contno and a.CustomerCode=@tCustomerCode
  end ;
	
if EXISTS (select 1 from CustomerAddress where CustomerCode=@tCustomerCode and DataSource='LA' and AddressType='OA' )
  begin
   update CustomerAddress 
   set CustomerAddress.AddressDoor=CONVERT(NVARCHAR, DECRYPTBYPASSPHRASE(N'METLIFE',b.CHARGEADDRESS)) ,
   CustomerAddress.PostCode=b.CUSTCOLLECTADDR,CustomerAddress.ModifyDate = getdate(),
   CustomerAddress.ModifyTime=(select CONVERT(varchar(12) , getdate(), 108 )),
   CustomerAddress.ModifySource='LA',
   CustomerAddress.ModifyType='U'
   from MAP_LCCONT b,CustomerAddress  
   where b.contno=@contno and CustomerAddress.CustomerCode=@tCustomerCode and CustomerAddress.DataSource='LA' 
   and CustomerAddress.AddressType='OA'
 end
else
 begin	 
   insert into CustomerAddress
   select  b.agentcode as 营销员编号, a.CustomerCode as 客户编号, 'OA' as 地址类型,'' as 地址_省,
   '' as 地址_市,'' as 地址_区县,'' as 地址_镇路,CONVERT(NVARCHAR, DECRYPTBYPASSPHRASE(N'METLIFE',b.CHARGEADDRESS)) as 详细地址,
   b.CUSTCOLLECTADDR as 邮编,'Y' as 是否邮寄地址,'LA' as 数据来源,b.CVALIDATE as 入机日期,'' as 入机时间,
   getdate() as 更新日期,(select CONVERT(varchar(12) , getdate(), 108 )) as 更新时间,
   'MAP' as 最后操作源,'A' as 最后操作,'' as 备用字段1, '' as 备用字段2, ''as 备用字段3, '' as 备用字段4,
   '' as 备用字段5
   from MAP_LCCONT b ,CustomerInfo a 
   where b.contno=@contno and a.CustomerCode=@tCustomerCode
 end;
 
 ---更新地址表的数据 (被保人)  
if @tRELATIONTOAPPNT <>'00' 
  begin 
    if EXISTS (select 1 from CustomerAddress where CustomerCode=@tCustomerCodein and DataSource='LA' and AddressType='HA'  )
		  begin
		   update CustomerAddress 
		   set CustomerAddress.AddressDoor=CONVERT(NVARCHAR, DECRYPTBYPASSPHRASE(N'METLIFE',b.ADDRESS1)) ,
		   CustomerAddress.PostCode=b.ZIPCODE,CustomerAddress.ModifyDate = getdate(),
		   CustomerAddress.ModifyTime=(select CONVERT(varchar(12) , getdate(), 108 )),
		   CustomerAddress.ModifySource='LA',
		   CustomerAddress.ModifyType='U'
		   from MAP_LCINSURED b,CustomerAddress  
		   where b.contno=@contno  and CustomerAddress.CustomerCode=@tCustomerCodein and CustomerAddress.DataSource='LA' 
		   and CustomerAddress.AddressType='HA' and dbo.MAP_DICODETONAME(N'T5666',b.RELATIONTOAPPNT) <>'本人'
		 end
		else
		 begin
		   insert into CustomerAddress
		   select  c.agentcode as 营销员编号, a.CustomerCode as 客户编号, 'HA' as 地址类型,'' as 地址_省,
		   '' as 地址_市,'' as 地址_区县,'' as 地址_镇路,CONVERT(NVARCHAR, DECRYPTBYPASSPHRASE(N'METLIFE',b.ADDRESS1)) as 详细地址,
		   b.ZIPCODE as 邮编, 'Y' as 是否邮寄地址,'LA' as 数据来源,c.CVALIDATE as 入机日期,'' as 入机时间,getdate() as 更新日期,
		   (select CONVERT(varchar(12) , getdate(), 108 )) as 更新时间,'MAP' as 最后操作源,'A' as 最后操作,'' as 备用字段1, 
		   '' as 备用字段2, ''as 备用字段3, '' as 备用字段4,'' as 备用字段5
		   from MAP_LCINSURED b ,CustomerInfo a ,MAP_LCCONT c
		   where b.contno=c.contno and b.contno=@contno
		   and a.CustomerCode=@tCustomerCodein
		   and dbo.MAP_DICODETONAME(N'T5666',b.RELATIONTOAPPNT) <>'本人'
		 end
 end;

 ---更新保单查询表Policy
   insert into Policy(AgentCode,LACode,CustomerName,BirthDate,Phone,PolicyNum,InsuranceType,InsuranceName
   ,PaymentMethod,Premium,Amount,FirstPayment,RenewalFee,CushionCondition,InsureDate,PolicyStatus)
   select 
   lcc.agentcode as 营销员编号,  
   lcc.appntno as 客户编号,
   CONVERT(NVARCHAR, DECRYPTBYPASSPHRASE(N'METLIFE',lcc.APPNTNAME)) as 客户姓名,
   CONVERT(NVARCHAR,lcc.APPNTBIRTHDAY,23) as 出生日期,
   lcc.mobilephone as 手机号,
   lcc.contno as 保单,
   lcp.RISKCODE as 主险险种, 
   lcp.MAINRISKNAME as 主险名称, 
   dbo.MAP_DICODETONAME('T3590',lcc.PAYINTV) as 交费频率,
   dbo.NULLSWITCH( cast ( 
   (case when lcc.STATE='1' and (select count(*) from MAP_LJSPAY_V where contno=lcc.contno)>0 
   then (select max(ljs.DUEMONEY) from MAP_LJSPAY_V ljs where ljs.CONTNO=lcc.contno and ljs.DUEMONEY>0     
   and ljs.DUEDATE=(     select max(a.DUEDATE) from MAP_LJSPAY_V a where a.CONTNO=lcc.contno and a.DUEMONEY>0     )   
    )else (select max(a.GETMONEY) from MAP_LJAPAY_V a where a.CONTNO=lcc.contno and a.GETMONEY>0    
    and a.DUEDATE=(     select max(a.DUEDATE) from MAP_LJAPAY_V a  where a.CONTNO=lcc.contno 
    and (a.CANCELDATE is null or a.CANCELDATE='') and a.GETMONEY>0 and a.CONFDATE is not null    )
    and a.confdate=(select max(a.confdate) from MAP_LJAPAY_V a  where a.CONTNO=lcc.contno )    
    )end ) as decimal(12,2))) as 期交保费,
   (case when (lcp.AMNT is not null and lcp.AMNT>0.00) then cast(lcp.AMNT as nvarchar)   when (lcp.MULT is not null and lcp.MULT<>'')
    then cast (lcp.MULT as nvarchar ) +'份' else '' end) as 保险金额, 
   dbo.MAP_DICODETONAME('T3620', lcc.NEWPAYMODE) as 首期交费方式, 
   dbo.MAP_DICODETONAME('T3620', lcc.PAYMODE) as 续期交费方式, 
   (case  when lcc.APL_FLAG = 'Y' then '有自垫'  when lcc.APL_FLAG = 'N' then '无自垫' end) 垫交情况 ,
   substring(CONVERT(varchar(24), lcc.SIGNDATE, 23),0,11) as 保单承保日期,
   ( case when lcc.STATE = '0' then '失效' when lcc.STATE = '1'   then '有效' when lcc.STATE = '3' then  '犹豫期撤单' 
    when lcc.STATE = '5' then '退保'  else  '' end) as 保单状态
   from  MAP_LCCONT lcc  
        ,MAP_LCPOL lcp  
   where 1=1 
        and lcc.CONTNO = lcp.CONTNO 
        and lcp.SUBRISKFLAG='Y'   
        and lcc.CONTNO=@contno
        and lcc.SIGNDATE is not null ;
        
 set @currentIndex=@currentIndex+1; 
   
 end;
  
   

--exec sp_help 'CustomerInfo'

--customerinfo&customeraddress表更新--xiaodi--end
go

